import { computeRecoveryUntil } from '../shared/bloodCompatibility.ts';
import { HYDERABAD_HOSPITALS, HYDERABAD_LOCALITIES } from '../shared/hyderabadData.ts';
import type { BloodGroup } from '../shared/types.ts';
import { hashPassword } from './auth.ts';
import { type SqliteDb, writeAuditLog } from './db.ts';

interface SeedDonorSpec {
  name: string;
  email: string;
  bloodGroup: BloodGroup;
  localityIndex: number;
  availability: 'available' | 'unavailable' | 'in_recovery';
  daysSinceLastDonation: number | null;
  verified: boolean;
  consentCoords: boolean;
  phone: string;
}

const DEMO_DONORS: SeedDonorSpec[] = [
  // Primary Demo O+ Donor (for Hackathon Demo Scenario)
  { name: 'Karthik Reddy', email: 'donor.oplus@redrelay.demo', bloodGroup: 'O+', localityIndex: 0, availability: 'available', daysSinceLastDonation: 140, verified: true, consentCoords: true, phone: '+91-90000-10001' },
  // Primary Demo O- Universal Donor
  { name: 'Ananya Sharma', email: 'donor.ominus@redrelay.demo', bloodGroup: 'O-', localityIndex: 1, availability: 'available', daysSinceLastDonation: 180, verified: true, consentCoords: true, phone: '+91-90000-10002' },
  // 28 more Hyderabad voluntary demonstration donors covering all 8 blood groups
  { name: 'Vikram Rao', email: 'vikram.rao@redrelay.demo', bloodGroup: 'B+', localityIndex: 0, availability: 'available', daysSinceLastDonation: 120, verified: true, consentCoords: true, phone: '+91-90000-10003' },
  { name: 'Sneha Nair', email: 'sneha.nair@redrelay.demo', bloodGroup: 'B-', localityIndex: 2, availability: 'available', daysSinceLastDonation: 200, verified: true, consentCoords: true, phone: '+91-90000-10004' },
  { name: 'Arjun Deshmukh', email: 'arjun.d@redrelay.demo', bloodGroup: 'A+', localityIndex: 1, availability: 'available', daysSinceLastDonation: 150, verified: true, consentCoords: true, phone: '+91-90000-10005' },
  { name: 'Meera Krishnan', email: 'meera.k@redrelay.demo', bloodGroup: 'A-', localityIndex: 3, availability: 'available', daysSinceLastDonation: null, verified: true, consentCoords: true, phone: '+91-90000-10006' },
  { name: 'Rohan Kulkarni', email: 'rohan.k@redrelay.demo', bloodGroup: 'AB+', localityIndex: 4, availability: 'available', daysSinceLastDonation: 110, verified: true, consentCoords: true, phone: '+91-90000-10007' },
  { name: 'Priya Menon', email: 'priya.m@redrelay.demo', bloodGroup: 'AB-', localityIndex: 5, availability: 'available', daysSinceLastDonation: 195, verified: true, consentCoords: true, phone: '+91-90000-10008' },
  { name: 'Siddharth Varma', email: 'siddharth.v@redrelay.demo', bloodGroup: 'O+', localityIndex: 2, availability: 'available', daysSinceLastDonation: 105, verified: true, consentCoords: true, phone: '+91-90000-10009' },
  { name: 'Divya Chary', email: 'divya.c@redrelay.demo', bloodGroup: 'O+', localityIndex: 6, availability: 'in_recovery', daysSinceLastDonation: 25, verified: true, consentCoords: true, phone: '+91-90000-10010' },
  { name: 'Nikhil Goud', email: 'nikhil.g@redrelay.demo', bloodGroup: 'B+', localityIndex: 7, availability: 'available', daysSinceLastDonation: 130, verified: true, consentCoords: true, phone: '+91-90000-10011' },
  { name: 'Kavya Joshi', email: 'kavya.j@redrelay.demo', bloodGroup: 'A+', localityIndex: 8, availability: 'available', daysSinceLastDonation: 160, verified: true, consentCoords: true, phone: '+91-90000-10012' },
  { name: 'Harsha Vardhan', email: 'harsha.v@redrelay.demo', bloodGroup: 'O-', localityIndex: 3, availability: 'in_recovery', daysSinceLastDonation: 40, verified: true, consentCoords: true, phone: '+91-90000-10013' },
  { name: 'Pooja Agarwal', email: 'pooja.a@redrelay.demo', bloodGroup: 'B+', localityIndex: 9, availability: 'unavailable', daysSinceLastDonation: 175, verified: true, consentCoords: false, phone: '+91-90000-10014' },
  { name: 'Rahul Teja', email: 'rahul.t@redrelay.demo', bloodGroup: 'A+', localityIndex: 10, availability: 'available', daysSinceLastDonation: null, verified: true, consentCoords: true, phone: '+91-90000-10015' },
  { name: 'Neha Sultana', email: 'neha.s@redrelay.demo', bloodGroup: 'O+', localityIndex: 11, availability: 'available', daysSinceLastDonation: 210, verified: true, consentCoords: false, phone: '+91-90000-10016' },
  { name: 'Aditya Patnaik', email: 'aditya.p@redrelay.demo', bloodGroup: 'B-', localityIndex: 0, availability: 'available', daysSinceLastDonation: 145, verified: true, consentCoords: true, phone: '+91-90000-10017' },
  { name: 'Swathi Murthy', email: 'swathi.m@redrelay.demo', bloodGroup: 'AB+', localityIndex: 6, availability: 'available', daysSinceLastDonation: 125, verified: true, consentCoords: true, phone: '+91-90000-10018' },
  { name: 'Tarun Kumar', email: 'tarun.k@redrelay.demo', bloodGroup: 'A-', localityIndex: 7, availability: 'unavailable', daysSinceLastDonation: 300, verified: true, consentCoords: true, phone: '+91-90000-10019' },
  { name: 'Shreya Banerjee', email: 'shreya.b@redrelay.demo', bloodGroup: 'O+', localityIndex: 4, availability: 'available', daysSinceLastDonation: 115, verified: true, consentCoords: true, phone: '+91-90000-10020' },
  { name: 'Manish Chowdary', email: 'manish.c@redrelay.demo', bloodGroup: 'B+', localityIndex: 5, availability: 'available', daysSinceLastDonation: 98, verified: true, consentCoords: true, phone: '+91-90000-10021' },
  { name: 'Lakshmi Prasad', email: 'lakshmi.p@redrelay.demo', bloodGroup: 'A+', localityIndex: 2, availability: 'in_recovery', daysSinceLastDonation: 15, verified: true, consentCoords: true, phone: '+91-90000-10022' },
  { name: 'Farhan Ali', email: 'farhan.a@redrelay.demo', bloodGroup: 'O-', localityIndex: 8, availability: 'available', daysSinceLastDonation: 220, verified: true, consentCoords: true, phone: '+91-90000-10023' },
  { name: 'Deepika Iyer', email: 'deepika.i@redrelay.demo', bloodGroup: 'AB-', localityIndex: 1, availability: 'available', daysSinceLastDonation: null, verified: false, consentCoords: true, phone: '+91-90000-10024' },
  { name: 'Varun Reddy', email: 'varun.r@redrelay.demo', bloodGroup: 'B+', localityIndex: 3, availability: 'available', daysSinceLastDonation: 190, verified: true, consentCoords: true, phone: '+91-90000-10025' },
  { name: 'Anjali Verma', email: 'anjali.v@redrelay.demo', bloodGroup: 'O+', localityIndex: 7, availability: 'available', daysSinceLastDonation: 132, verified: true, consentCoords: false, phone: '+91-90000-10026' },
  { name: 'Suresh Babu', email: 'suresh.b@redrelay.demo', bloodGroup: 'A+', localityIndex: 5, availability: 'available', daysSinceLastDonation: 240, verified: true, consentCoords: true, phone: '+91-90000-10027' },
  { name: 'Keerthi Nanda', email: 'keerthi.n@redrelay.demo', bloodGroup: 'B-', localityIndex: 8, availability: 'unavailable', daysSinceLastDonation: 150, verified: true, consentCoords: true, phone: '+91-90000-10028' },
  { name: 'Pranav Hegde', email: 'pranav.h@redrelay.demo', bloodGroup: 'AB+', localityIndex: 9, availability: 'available', daysSinceLastDonation: 108, verified: true, consentCoords: true, phone: '+91-90000-10029' },
  { name: 'Ritu Saxena', email: 'ritu.s@redrelay.demo', bloodGroup: 'O+', localityIndex: 10, availability: 'available', daysSinceLastDonation: 168, verified: false, consentCoords: true, phone: '+91-90000-10030' },
];

export function seedDatabase(db: SqliteDb, options: { forceReset?: boolean } = {}): {
  seeded: boolean;
  donorCount: number;
  requestCount: number;
} {
  const existingUsers = (
    db.prepare(`SELECT COUNT(*) AS count FROM users`).get() as { count: number }
  ).count;

  if (existingUsers > 0 && !options.forceReset) {
    const donorCount = (
      db.prepare(`SELECT COUNT(*) AS count FROM donors`).get() as { count: number }
    ).count;
    const requestCount = (
      db.prepare(`SELECT COUNT(*) AS count FROM blood_requests`).get() as { count: number }
    ).count;
    return { seeded: false, donorCount, requestCount };
  }

  const now = new Date();
  const nowIso = now.toISOString();
  const demoPasswordHash = hashPassword('DemoPass@2026');

  const tx = db.transaction(() => {
    if (options.forceReset) {
      db.exec(`
        DELETE FROM certificates;
        DELETE FROM fulfillment_transactions;
        DELETE FROM donation_history;
        DELETE FROM relay_messages;
        DELETE FROM hospital_verifications;
        DELETE FROM notifications;
        DELETE FROM responses;
        DELETE FROM audit_logs;
        DELETE FROM blood_requests;
        DELETE FROM donors;
        DELETE FROM users;
      `);
    }

    const insertUser = db.prepare(
      `INSERT INTO users (name, email, password_hash, role, is_demo, created_at, updated_at)
       VALUES (?, ?, ?, ?, 1, ?, ?)`
    );

    const adminId = Number(
      insertUser.run(
        'Dr. Kavitha Rao (Demo Admin)',
        'admin@redrelay.demo',
        demoPasswordHash,
        'admin',
        nowIso,
        nowIso
      ).lastInsertRowid
    );

    const requesterId = Number(
      insertUser.run(
        'Srinivas Rao (Demo Requester)',
        'requester@redrelay.demo',
        demoPasswordHash,
        'requester',
        nowIso,
        nowIso
      ).lastInsertRowid
    );

    const secondRequesterId = Number(
      insertUser.run(
        'Padma Lakshmi (Demo Coordinator)',
        'coordinator@redrelay.demo',
        demoPasswordHash,
        'requester',
        nowIso,
        nowIso
      ).lastInsertRowid
    );

    const insertDonor = db.prepare(
      `INSERT INTO donors (
        user_id, blood_group, city, locality, latitude, longitude,
        availability_status, last_donation_date, recovery_until,
        phone_private, verification_status, consent_status, is_demo, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
    );

    const insertHistory = db.prepare(
      `INSERT INTO donation_history (
        donor_id, request_id, hospital_name, blood_group, units_donated, donated_at, verified_by_user_id
      ) VALUES (?, NULL, ?, ?, 1, ?, ?)`
    );

    const donorIds: number[] = [];

    DEMO_DONORS.forEach((spec, idx) => {
      const userId = Number(
        insertUser.run(spec.name, spec.email, demoPasswordHash, 'donor', nowIso, nowIso)
          .lastInsertRowid
      );

      const loc = HYDERABAD_LOCALITIES[spec.localityIndex % HYDERABAD_LOCALITIES.length];
      // Deterministic tiny coordinate offset so pins don't overlap on the map
      const offsetLat = ((idx % 5) - 2) * 0.0028;
      const offsetLon = ((idx % 7) - 3) * 0.0028;

      const lastDonationIso =
        spec.daysSinceLastDonation !== null
          ? new Date(now.getTime() - spec.daysSinceLastDonation * 24 * 60 * 60 * 1000).toISOString()
          : null;

      const recoveryUntil =
        lastDonationIso !== null && spec.availability === 'in_recovery'
          ? computeRecoveryUntil(lastDonationIso, 90)
          : null;

      const donorId = Number(
        insertDonor.run(
          userId,
          spec.bloodGroup,
          loc.city,
          loc.locality,
          spec.consentCoords ? Number((loc.latitude + offsetLat).toFixed(5)) : null,
          spec.consentCoords ? Number((loc.longitude + offsetLon).toFixed(5)) : null,
          spec.availability,
          lastDonationIso,
          recoveryUntil,
          spec.phone,
          spec.verified ? 'verified' : 'pending',
          spec.consentCoords ? 1 : 0,
          nowIso
        ).lastInsertRowid
      );
      donorIds.push(donorId);

      if (lastDonationIso) {
        const refHospital = HYDERABAD_HOSPITALS[idx % HYDERABAD_HOSPITALS.length];
        insertHistory.run(donorId, refHospital.name, spec.bloodGroup, lastDonationIso, adminId);
      }
    });

    // Seed 5 active demonstration emergency hospital requests
    const insertReq = db.prepare(
      `INSERT INTO blood_requests (
        request_code, requester_id, patient_name, hospital_name, hospital_location,
        latitude, longitude, city, locality, blood_group, units_required, units_committed,
        urgency_deadline, doctor_verification_contact, additional_info,
        verification_status, lifecycle_status, is_demo, created_at, expires_at, closed_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, NULL)`
    );

    const hoursFromNow = (h: number) =>
      new Date(now.getTime() + h * 60 * 60 * 1000).toISOString();

    const demoRequests = [
      {
        code: 'REQ-HYD-1001',
        reqUserId: requesterId,
        patient: 'Ramesh Babu (Demo)',
        hospital: HYDERABAD_HOSPITALS[0],
        bloodGroup: 'A+' as BloodGroup,
        unitsRequired: 2,
        unitsCommitted: 1,
        deadline: hoursFromNow(3.5),
        doctor: 'Dr. M. Venkatesh · Apollo Blood Bank Ext 4412',
        info: 'Demo emergency orthopedic trauma surgery scheduled at OT-3.',
        verification: 'verified',
        lifecycle: 'donors_responded',
      },
      {
        code: 'REQ-HYD-1002',
        reqUserId: secondRequesterId,
        patient: 'Lakshmi Devi (Demo)',
        hospital: HYDERABAD_HOSPITALS[1],
        bloodGroup: 'O-' as BloodGroup,
        unitsRequired: 2,
        unitsCommitted: 0,
        deadline: hoursFromNow(2.5),
        doctor: 'Dr. A. Padmavathi · CARE Cardiac ICU Desk',
        info: 'Demo urgent O- red-cell support for emergency valve replacement.',
        verification: 'verified',
        lifecycle: 'open',
      },
      {
        code: 'REQ-HYD-1003',
        reqUserId: secondRequesterId,
        patient: 'Suresh Verma (Demo)',
        hospital: HYDERABAD_HOSPITALS[2],
        bloodGroup: 'B-' as BloodGroup,
        unitsRequired: 3,
        unitsCommitted: 1,
        deadline: hoursFromNow(6),
        doctor: 'Dr. R. Subramanian · Yashoda Transfusion Unit',
        info: 'Demo post-operative surgical recovery support.',
        verification: 'verified',
        lifecycle: 'donors_responded',
      },
      {
        code: 'REQ-HYD-1004',
        reqUserId: requesterId,
        patient: 'Fatima Begum (Demo)',
        hospital: HYDERABAD_HOSPITALS[3],
        bloodGroup: 'AB+' as BloodGroup,
        unitsRequired: 2,
        unitsCommitted: 2,
        deadline: hoursFromNow(5),
        doctor: 'Dr. K. Madhuri · KIMS Blood Center',
        info: 'Demo childbirth complication support; committed donors en route.',
        verification: 'verified',
        lifecycle: 'fulfilled_in_transit',
      },
      {
        code: 'REQ-HYD-1005',
        reqUserId: secondRequesterId,
        patient: 'Chaitanya N. (Demo)',
        hospital: HYDERABAD_HOSPITALS[4],
        bloodGroup: 'O+' as BloodGroup,
        unitsRequired: 2,
        unitsCommitted: 0,
        deadline: hoursFromNow(10),
        doctor: 'Dr. V. Rajasekhar · AIG Critical Care',
        info: 'Demo GI surgical prep awaiting admin doctor-contact verification.',
        verification: 'pending',
        lifecycle: 'open',
      },
    ];

    const reqIds: number[] = [];
    for (const item of demoRequests) {
      const rId = Number(
        insertReq.run(
          item.code,
          item.reqUserId,
          item.patient,
          item.hospital.name,
          item.hospital.location,
          item.hospital.latitude,
          item.hospital.longitude,
          item.hospital.city,
          item.hospital.locality,
          item.bloodGroup,
          item.unitsRequired,
          item.unitsCommitted,
          item.deadline,
          item.doctor,
          item.info,
          item.verification,
          item.lifecycle,
          nowIso,
          hoursFromNow(24)
        ).lastInsertRowid
      );
      reqIds.push(rId);

      db.prepare(
        `INSERT INTO hospital_verifications (request_id, doctor_contact, verified_by_user_id, status, notes, checked_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(
        rId,
        item.doctor,
        item.verification === 'verified' ? adminId : null,
        item.verification,
        item.verification === 'verified'
          ? 'Demonstration hospital blood bank extension verified.'
          : 'Awaiting administrator verification review.',
        nowIso
      );
    }

    // Seed initial donor responses matching committed counts on REQ-HYD-1001, 1003, 1004
    const insertResp = db.prepare(
      `INSERT INTO responses (request_id, donor_id, units_offered, response_status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`
    );
    // Arjun Deshmukh (A+, donorIds[4]) responded to REQ-HYD-1001
    insertResp.run(reqIds[0], donorIds[4], 1, 'committed', nowIso, nowIso);
    // Sneha Nair (B-, donorIds[3]) responded to REQ-HYD-1003
    insertResp.run(reqIds[2], donorIds[3], 1, 'committed', nowIso, nowIso);
    // Rohan Kulkarni (AB+, donorIds[6]) and Swathi Murthy (AB+, donorIds[17]) en route for REQ-HYD-1004
    insertResp.run(reqIds[3], donorIds[6], 1, 'en_route', nowIso, nowIso);
    insertResp.run(reqIds[3], donorIds[17], 1, 'en_route', nowIso, nowIso);

    // Seed one historical closed request with a verified FulfillmentTransaction and Certificate
    const pastIso = new Date(now.getTime() - 140 * 24 * 60 * 60 * 1000).toISOString();
    const pastReqId = Number(
      db
        .prepare(
          `INSERT INTO blood_requests (
            request_code, requester_id, patient_name, hospital_name, hospital_location,
            latitude, longitude, city, locality, blood_group, units_required, units_committed,
            urgency_deadline, doctor_verification_contact, additional_info,
            verification_status, lifecycle_status, is_demo, created_at, expires_at, closed_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'verified', 'closed', 1, ?, ?, ?)`
        )
        .run(
          'REQ-HYD-0998',
          requesterId,
          'Anitha M. (Historical Demo)',
          HYDERABAD_HOSPITALS[0].name,
          HYDERABAD_HOSPITALS[0].location,
          HYDERABAD_HOSPITALS[0].latitude,
          HYDERABAD_HOSPITALS[0].longitude,
          'Hyderabad',
          'Jubilee Hills',
          'O+',
          1,
          1,
          pastIso,
          'Dr. M. Venkatesh · Apollo Blood Bank',
          'Historical closed demonstration case.',
          pastIso,
          pastIso,
          pastIso
        ).lastInsertRowid
    );

    db.prepare(
      `INSERT INTO responses (request_id, donor_id, units_offered, response_status, created_at, updated_at)
       VALUES (?, ?, 1, 'fulfilled', ?, ?)`
    ).run(pastReqId, donorIds[0], pastIso, pastIso);

    const pastFulfillmentId = Number(
      db
        .prepare(
          `INSERT INTO fulfillment_transactions (request_id, donor_id, units_fulfilled, confirmation_status, confirmed_by_user_id, confirmed_at)
           VALUES (?, ?, 1, 'confirmed', ?, ?)`
        )
        .run(pastReqId, donorIds[0], adminId, pastIso).lastInsertRowid
    );

    db.prepare(
      `INSERT INTO certificates (
        certificate_code, donor_id, fulfillment_id, donor_display_name, blood_group,
        request_code, hospital_name, units_donated, donation_date, issued_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
    ).run(
      'CERT-RR-2026-0001',
      donorIds[0],
      pastFulfillmentId,
      'Karthik Reddy',
      'O+',
      'REQ-HYD-0998',
      HYDERABAD_HOSPITALS[0].name,
      pastIso,
      pastIso
    );

    // Seed initial masked relay message on REQ-HYD-1001
    db.prepare(
      `INSERT INTO relay_messages (request_id, sender_user_id, sender_label, sender_role, message, created_at)
       VALUES (?, ?, ?, 'donor', ?, ?)`
    ).run(
      reqIds[0],
      requesterId,
      'Requester (S. R.)',
      'Blood bank counter at Apollo Jubilee Hills Ground Floor is ready for donor check-in.',
      nowIso
    );

    writeAuditLog(db, {
      actorUserId: adminId,
      actorName: 'System Seed',
      actorRole: 'system',
      action: 'DEMO_DATASET_SEEDED',
      entityType: 'system',
      entityId: 'hyderabad-demo',
      details:
        'Seeded 30 Hyderabad demonstration voluntary donors across all 8 ABO/Rh groups and 5 active demonstration hospital requests.',
      createdAt: nowIso,
    });
  });

  tx();
  return {
    seeded: true,
    donorCount: DEMO_DONORS.length,
    requestCount: 5,
  };
}
