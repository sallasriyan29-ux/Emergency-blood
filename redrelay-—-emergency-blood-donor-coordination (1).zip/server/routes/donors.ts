import { Router } from 'express';
import type { Server as SocketIOServer } from 'socket.io';
import {
  calculateHaversineKm,
  getCompatibleDonorGroups,
  isCompatibleDonor,
  isRecoveryEligible,
  isValidBloodGroup,
  maskDisplayName,
  matchEligibleDonors,
} from '../../shared/bloodCompatibility.ts';
import { findLocalityCoordinates } from '../../shared/hyderabadData.ts';
import {
  BLOOD_GROUPS,
  type BloodGroup,
  type BloodGroupSupplySummary,
  type DirectoryDonorRecord,
  type DonorPrivateProfile,
} from '../../shared/types.ts';
import {
  type AuthenticatedRequest,
  createAuthMiddleware,
  sensitiveActionRateLimiter,
} from '../auth.ts';
import {
  getAllMaskedDonors,
  mapBloodRequestRow,
  restoreExpiredRecoveries,
  runExpirationSweep,
  type SqliteDb,
  writeAuditLog,
} from '../db.ts';

export function createDonorsRouter(
  getDb: () => SqliteDb,
  getIo: () => SocketIOServer | null = () => null
): Router {
  const router = Router();
  const { requireAuth, requireRole } = createAuthMiddleware(getDb);

  // Public privacy-masked voluntary donor directory (search by blood group, city, locality, proximity)
  router.get('/directory', (req, res) => {
    const db = getDb();
    restoreExpiredRecoveries(db);

    const bloodGroupRaw = typeof req.query.bloodGroup === 'string' ? req.query.bloodGroup.trim() : '';
    const matchMode = req.query.matchMode === 'compatible' ? 'compatible' : 'exact';
    const city = typeof req.query.city === 'string' ? req.query.city.trim() : '';
    const locality = typeof req.query.locality === 'string' ? req.query.locality.trim() : '';
    const search = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
    const availability = req.query.availability === 'all' ? 'all' : 'available';
    const nearLocality =
      typeof req.query.nearLocality === 'string' ? req.query.nearLocality.trim() : '';

    if (bloodGroupRaw && !isValidBloodGroup(bloodGroupRaw)) {
      res.status(400).json({ error: 'Invalid bloodGroup query parameter.' });
      return;
    }

    const allDonors = getAllMaskedDonors(db).filter((d) => d.verificationStatus !== 'rejected');

    const historyRows = db
      .prepare(`SELECT donor_id, COUNT(*) AS count FROM donation_history GROUP BY donor_id`)
      .all() as Array<{ donor_id: number; count: number }>;
    const donationCounts = new Map(historyRows.map((row) => [row.donor_id, row.count]));

    const nearCoords = nearLocality
      ? findLocalityCoordinates(city || 'Hyderabad', nearLocality)
      : null;

    // Apply location, search, and availability filters before blood group filtering so counts stay accurate
    const baseFiltered: DirectoryDonorRecord[] = allDonors
      .filter((donor) => {
        if (availability === 'available' && donor.effectiveAvailability !== 'available') {
          return false;
        }
        if (city && donor.city.toLowerCase() !== city.toLowerCase()) {
          return false;
        }
        if (locality && donor.locality.toLowerCase() !== locality.toLowerCase()) {
          return false;
        }
        if (search) {
          const haystack =
            `${donor.locality} ${donor.city} ${donor.donorInitials} ${donor.bloodGroup}`.toLowerCase();
          if (!haystack.includes(search)) return false;
        }
        return true;
      })
      .map((donor) => {
        let distanceKm = donor.distanceKm;
        if (
          nearCoords &&
          donor.consentStatus &&
          donor.latitude != null &&
          donor.longitude != null
        ) {
          distanceKm = calculateHaversineKm(
            nearCoords.latitude,
            nearCoords.longitude,
            donor.latitude,
            donor.longitude
          );
        }
        return {
          ...donor,
          distanceKm,
          confirmedDonationsCount: donationCounts.get(donor.id) ?? 0,
        };
      });

    const exactCountsByGroup: Record<BloodGroup, number> = {
      'A+': 0,
      'A-': 0,
      'B+': 0,
      'B-': 0,
      'AB+': 0,
      'AB-': 0,
      'O+': 0,
      'O-': 0,
    };
    for (const d of baseFiltered) {
      exactCountsByGroup[d.bloodGroup] = (exactCountsByGroup[d.bloodGroup] ?? 0) + 1;
    }

    let donors = baseFiltered;
    if (bloodGroupRaw && isValidBloodGroup(bloodGroupRaw)) {
      const allowedGroups =
        matchMode === 'compatible' ? getCompatibleDonorGroups(bloodGroupRaw) : [bloodGroupRaw];
      donors = baseFiltered.filter((d) => allowedGroups.includes(d.bloodGroup));
    }

    const availabilityRank: Record<string, number> = {
      available: 0,
      in_recovery: 1,
      unavailable: 2,
    };

    donors.sort((a, b) => {
      const availDiff =
        (availabilityRank[a.effectiveAvailability] ?? 2) -
        (availabilityRank[b.effectiveAvailability] ?? 2);
      if (availDiff !== 0) return availDiff;

      if (nearCoords) {
        if (a.distanceKm !== null && b.distanceKm !== null && a.distanceKm !== b.distanceKm) {
          return a.distanceKm - b.distanceKm;
        }
        if (a.distanceKm !== null && b.distanceKm === null) return -1;
        if (a.distanceKm === null && b.distanceKm !== null) return 1;
      }

      if (a.verificationStatus === 'verified' && b.verificationStatus !== 'verified') return -1;
      if (a.verificationStatus !== 'verified' && b.verificationStatus === 'verified') return 1;

      if (b.confirmedDonationsCount !== a.confirmedDonationsCount) {
        return b.confirmedDonationsCount - a.confirmedDonationsCount;
      }
      return a.id - b.id;
    });

    res.json({
      total: donors.length,
      totalInScope: baseFiltered.length,
      exactCountsByGroup,
      donors,
    });
  });

  // Public/Requester/Donor privacy-masked compatibility matching endpoint
  router.get('/match', (req, res) => {
    const db = getDb();
    const bloodGroupRaw = String(req.query.bloodGroup || '').trim();
    const city = typeof req.query.city === 'string' ? req.query.city : undefined;
    const locality = typeof req.query.locality === 'string' ? req.query.locality : undefined;
    const radiusKm = req.query.radiusKm ? Number(req.query.radiusKm) : null;
    const lat = req.query.lat ? Number(req.query.lat) : null;
    const lon = req.query.lon ? Number(req.query.lon) : null;

    if (!isValidBloodGroup(bloodGroupRaw)) {
      res.status(400).json({ error: 'Valid bloodGroup query parameter is required.' });
      return;
    }

    const allDonors = getAllMaskedDonors(db);
    const matched = matchEligibleDonors(allDonors, {
      recipientBloodGroup: bloodGroupRaw,
      city,
      locality,
      targetLatitude: Number.isFinite(lat) ? lat : null,
      targetLongitude: Number.isFinite(lon) ? lon : null,
      maxRadiusKm: Number.isFinite(radiusKm) && (radiusKm as number) > 0 ? radiusKm : null,
    });

    res.json({
      bloodGroup: bloodGroupRaw,
      totalMatched: matched.length,
      donors: matched,
    });
  });

  // Live blood supply vs active demand summary across all 8 ABO/Rh groups
  router.get('/supply-summary', (_req, res) => {
    const db = getDb();
    runExpirationSweep(db);
    restoreExpiredRecoveries(db);

    const allDonors = getAllMaskedDonors(db);
    const activeRequests = db
      .prepare(
        `SELECT blood_group, units_required, units_committed
         FROM blood_requests
         WHERE lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')`
      )
      .all() as Array<{
      blood_group: BloodGroup;
      units_required: number;
      units_committed: number;
    }>;

    const groups: BloodGroupSupplySummary[] = BLOOD_GROUPS.map((group) => {
      const compatibleList = getCompatibleDonorGroups(group);
      const exactTotal = allDonors.filter((d) => d.bloodGroup === group).length;
      const exactAvailable = allDonors.filter(
        (d) => d.bloodGroup === group && d.effectiveAvailability === 'available'
      ).length;
      const compatibleAvailable = allDonors.filter(
        (d) =>
          compatibleList.includes(d.bloodGroup) && d.effectiveAvailability === 'available'
      ).length;

      const groupRequests = activeRequests.filter((r) => r.blood_group === group);
      const activeUnitsNeeded = groupRequests.reduce(
        (sum, r) => sum + Math.max(0, r.units_required - r.units_committed),
        0
      );

      return {
        bloodGroup: group,
        availableDonors: exactAvailable,
        compatibleDonors: compatibleAvailable,
        totalDonors: exactTotal,
        activeRequestsCount: groupRequests.length,
        activeUnitsNeeded,
      };
    });

    const totalAvailableDonors = groups.reduce((acc, g) => acc + g.availableDonors, 0);
    const totalActiveUnitsNeeded = groups.reduce((acc, g) => acc + g.activeUnitsNeeded, 0);
    const totalRegisteredDonors = allDonors.length;
    const totalVerifiedDonors = allDonors.filter((d) => d.verificationStatus === 'verified').length;
    const totalConfirmedDonations = (
      db.prepare(`SELECT COUNT(*) AS count FROM donation_history`).get() as { count: number }
    ).count;
    const totalPartnerHospitals = (
      db.prepare(`SELECT COUNT(DISTINCT hospital_name) AS count FROM blood_requests`).get() as {
        count: number;
      }
    ).count;
    const totalClosedRequests = (
      db
        .prepare(`SELECT COUNT(*) AS count FROM blood_requests WHERE lifecycle_status = 'closed'`)
        .get() as { count: number }
    ).count;

    res.json({
      groups,
      totalAvailableDonors,
      totalActiveUnitsNeeded,
      totalRegisteredDonors,
      totalVerifiedDonors,
      totalConfirmedDonations,
      totalPartnerHospitals,
      totalActiveRequests: activeRequests.length,
      totalClosedRequests,
    });
  });

  // Register or complete donor profile for authenticated user
  router.post('/register', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const user = req.authUser!;
    const { bloodGroup, city, locality, phone, consentLocation, latitude, longitude } =
      req.body ?? {};

    if (!bloodGroup || !isValidBloodGroup(String(bloodGroup))) {
      res.status(400).json({ error: 'Valid ABO/Rh blood group is required.' });
      return;
    }
    if (!city || typeof city !== 'string' || city.trim().length < 2) {
      res.status(400).json({ error: 'City is required.' });
      return;
    }
    if (!locality || typeof locality !== 'string' || locality.trim().length < 2) {
      res.status(400).json({ error: 'Locality is required.' });
      return;
    }
    if (!phone || typeof phone !== 'string' || phone.trim().length < 7) {
      res.status(400).json({ error: 'Private contact number is required.' });
      return;
    }

    const existing = db
      .prepare(`SELECT id FROM donors WHERE user_id = ?`)
      .get(user.id) as { id: number } | undefined;

    if (existing) {
      res.status(409).json({ error: 'Donor profile already registered for this account.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const consent = consentLocation !== false;
    const knownCoords = consent
      ? findLocalityCoordinates(String(city), String(locality))
      : null;
    const resolvedLat =
      consent && typeof latitude === 'number' ? latitude : knownCoords?.latitude ?? null;
    const resolvedLon =
      consent && typeof longitude === 'number' ? longitude : knownCoords?.longitude ?? null;

    const tx = db.transaction(() => {
      if (user.role === 'requester') {
        db.prepare(`UPDATE users SET role = 'donor', updated_at = ? WHERE id = ?`).run(
          nowIso,
          user.id
        );
      }

      const donorId = Number(
        db
          .prepare(
            `INSERT INTO donors (
              user_id, blood_group, city, locality, latitude, longitude,
              availability_status, phone_private, verification_status, consent_status, is_demo, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'available', ?, 'pending', ?, ?, ?)`
          )
          .run(
            user.id,
            bloodGroup,
            city.trim(),
            locality.trim(),
            resolvedLat,
            resolvedLon,
            phone.trim(),
            consent ? 1 : 0,
            user.isDemo ? 1 : 0,
            nowIso
          ).lastInsertRowid
      );

      writeAuditLog(db, {
        actorUserId: user.id,
        actorName: user.name,
        actorRole: 'donor',
        action: 'DONOR_PROFILE_CREATED',
        entityType: 'donor',
        entityId: donorId,
        details: `Registered ${bloodGroup} donor profile in ${locality.trim()}, ${city.trim()}.`,
        createdAt: nowIso,
      });

      return donorId;
    });

    const donorId = tx();
    res.status(201).json({ donorId, message: 'Donor profile registered.' });
  });

  // Authenticated donor's own private profile (includes their own phone + recovery info)
  router.get('/profile', requireAuth, requireRole('donor'), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    restoreExpiredRecoveries(db);

    const row = db
      .prepare(
        `SELECT d.*, u.name AS user_name
         FROM donors d
         JOIN users u ON u.id = d.user_id
         WHERE d.user_id = ?`
      )
      .get(req.authUser!.id) as
      | {
          id: number;
          user_id: number;
          user_name: string;
          blood_group: BloodGroup;
          city: string;
          locality: string;
          latitude: number | null;
          longitude: number | null;
          availability_status: 'available' | 'unavailable' | 'in_recovery';
          last_donation_date: string | null;
          recovery_until: string | null;
          phone_private: string;
          verification_status: 'pending' | 'verified' | 'rejected';
          consent_status: number;
          is_demo: number;
          created_at: string;
        }
      | undefined;

    if (!row) {
      res.status(404).json({ error: 'Donor profile not found.' });
      return;
    }

    const totalConfirmedDonations = (
      db
        .prepare(`SELECT COUNT(*) AS count FROM donation_history WHERE donor_id = ?`)
        .get(row.id) as { count: number }
    ).count;

    const now = new Date();
    const inRecovery = !isRecoveryEligible(row.recovery_until, now);
    const effectiveAvailability = inRecovery ? 'in_recovery' : row.availability_status;

    const profile: DonorPrivateProfile = {
      id: row.id,
      userId: row.user_id,
      fullName: row.user_name,
      donorInitials: maskDisplayName(row.user_name),
      bloodGroup: row.blood_group,
      city: row.city,
      locality: row.locality,
      latitude: row.consent_status ? row.latitude : null,
      longitude: row.consent_status ? row.longitude : null,
      consentStatus: Boolean(row.consent_status),
      availabilityStatus: row.availability_status,
      effectiveAvailability,
      lastDonationDate: row.last_donation_date,
      recoveryUntil: row.recovery_until,
      nextEligibleDate: inRecovery ? row.recovery_until : null,
      verificationStatus: row.verification_status,
      phone: row.phone_private,
      totalConfirmedDonations,
      distanceKm: null,
      isDemo: Boolean(row.is_demo),
      createdAt: row.created_at,
    };

    res.json({ profile });
  });

  router.patch('/availability', requireAuth, requireRole('donor'), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    restoreExpiredRecoveries(db);

    const donor = db
      .prepare(`SELECT * FROM donors WHERE user_id = ?`)
      .get(req.authUser!.id) as
      | {
          id: number;
          availability_status: string;
          recovery_until: string | null;
          city: string;
          locality: string;
          consent_status: number;
          latitude: number | null;
          longitude: number | null;
        }
      | undefined;

    if (!donor) {
      res.status(404).json({ error: 'Donor profile not found.' });
      return;
    }

    const { availabilityStatus, city, locality, consentStatus } = req.body ?? {};
    const now = new Date();

    if (availabilityStatus !== undefined) {
      if (availabilityStatus !== 'available' && availabilityStatus !== 'unavailable') {
        res.status(400).json({ error: 'availabilityStatus must be available or unavailable.' });
        return;
      }
      if (availabilityStatus === 'available' && !isRecoveryEligible(donor.recovery_until, now)) {
        res.status(409).json({
          error: `Post-donation 90-day recovery restriction is active until ${new Date(
            donor.recovery_until!
          ).toLocaleDateString()}.`,
        });
        return;
      }
    }

    const nextCity = typeof city === 'string' && city.trim() ? city.trim() : donor.city;
    const nextLocality =
      typeof locality === 'string' && locality.trim() ? locality.trim() : donor.locality;
    const nextConsent =
      typeof consentStatus === 'boolean' ? (consentStatus ? 1 : 0) : donor.consent_status;

    const coords = nextConsent ? findLocalityCoordinates(nextCity, nextLocality) : null;
    const nextLat = nextConsent ? coords?.latitude ?? donor.latitude : null;
    const nextLon = nextConsent ? coords?.longitude ?? donor.longitude : null;
    const nextStatus = availabilityStatus ?? donor.availability_status;

    db.prepare(
      `UPDATE donors
       SET availability_status = ?, city = ?, locality = ?, consent_status = ?, latitude = ?, longitude = ?
       WHERE id = ?`
    ).run(nextStatus, nextCity, nextLocality, nextConsent, nextLat, nextLon, donor.id);

    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: 'donor',
      action: 'DONOR_AVAILABILITY_UPDATED',
      entityType: 'donor',
      entityId: donor.id,
      details: `Updated status to ${nextStatus} in ${nextLocality}, ${nextCity}.`,
    });

    res.json({ ok: true, availabilityStatus: nextStatus, city: nextCity, locality: nextLocality });
  });

  router.get(
    '/compatible-requests',
    requireAuth,
    requireRole('donor'),
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      runExpirationSweep(db);
      restoreExpiredRecoveries(db);

      const donor = db
        .prepare(`SELECT * FROM donors WHERE user_id = ?`)
        .get(req.authUser!.id) as
        | {
            id: number;
            blood_group: BloodGroup;
            city: string;
            locality: string;
            latitude: number | null;
            longitude: number | null;
            consent_status: number;
            availability_status: string;
            recovery_until: string | null;
          }
        | undefined;

      if (!donor) {
        res.status(404).json({ error: 'Donor profile not found.' });
        return;
      }

      const rows = db
        .prepare(
          `SELECT r.*, u.name AS requester_name
           FROM blood_requests r
           JOIN users u ON u.id = r.requester_id
           WHERE r.lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')
           ORDER BY r.urgency_deadline ASC`
        )
        .all() as Array<Parameters<typeof mapBloodRequestRow>[0]>;

      const myResponses = db
        .prepare(`SELECT request_id, response_status, units_offered FROM responses WHERE donor_id = ?`)
        .all(donor.id) as Array<{
        request_id: number;
        response_status: string;
        units_offered: number;
      }>;
      const responseMap = new Map(myResponses.map((r) => [r.request_id, r]));

      const compatible = rows
        .filter((r) => isCompatibleDonor(r.blood_group, donor.blood_group))
        .map((r) => {
          const mapped = mapBloodRequestRow(r);
          let distanceKm: number | null = null;
          if (
            donor.consent_status &&
            donor.latitude != null &&
            donor.longitude != null &&
            mapped.latitude != null &&
            mapped.longitude != null
          ) {
            distanceKm = calculateHaversineKm(
              donor.latitude,
              donor.longitude,
              mapped.latitude,
              mapped.longitude
            );
          }
          return {
            ...mapped,
            distanceKm,
            myResponse: responseMap.get(mapped.id) || null,
          };
        });

      res.json({
        donorBloodGroup: donor.blood_group,
        recoveryEligible: isRecoveryEligible(donor.recovery_until),
        recoveryUntil: donor.recovery_until,
        requests: compatible,
      });
    }
  );

  router.get('/history', requireAuth, requireRole('donor'), (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const donor = db
      .prepare(`SELECT id FROM donors WHERE user_id = ?`)
      .get(req.authUser!.id) as { id: number } | undefined;

    if (!donor) {
      res.status(404).json({ error: 'Donor profile not found.' });
      return;
    }

    const donations = db
      .prepare(
        `SELECT dh.*, br.request_code
         FROM donation_history dh
         LEFT JOIN blood_requests br ON br.id = dh.request_id
         WHERE dh.donor_id = ?
         ORDER BY dh.donated_at DESC`
      )
      .all(donor.id);

    const commitments = db
      .prepare(
        `SELECT resp.*, br.request_code, br.hospital_name, br.hospital_location, br.locality,
                br.blood_group, br.lifecycle_status, br.urgency_deadline
         FROM responses resp
         JOIN blood_requests br ON br.id = resp.request_id
         WHERE resp.donor_id = ?
         ORDER BY resp.created_at DESC`
      )
      .all(donor.id);

    const certificates = db
      .prepare(
        `SELECT id, certificate_code AS certificateCode, donor_id AS donorId,
                donor_display_name AS donorDisplayName, blood_group AS bloodGroup,
                request_code AS requestCode, hospital_name AS hospitalName,
                units_donated AS unitsDonated, donation_date AS donationDate,
                issued_at AS issuedAt
         FROM certificates
         WHERE donor_id = ?
         ORDER BY issued_at DESC`
      )
      .all(donor.id);

    res.json({ donations, commitments, certificates });
  });

  // Privacy-masked direct donor ping (dispatches an in-app alert without exposing donor phone/email)
  router.post(
    '/:id/ping',
    requireAuth,
    sensitiveActionRateLimiter,
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      restoreExpiredRecoveries(db);

      const donorId = Number(req.params.id);
      if (!Number.isInteger(donorId) || donorId <= 0) {
        res.status(400).json({ error: 'Invalid donor ID.' });
        return;
      }

      const donor = db
        .prepare(
          `SELECT d.id, d.user_id, d.blood_group, d.city, d.locality,
                  d.availability_status, d.recovery_until, d.verification_status,
                  u.name AS user_name
           FROM donors d
           JOIN users u ON u.id = d.user_id
           WHERE d.id = ?`
        )
        .get(donorId) as
        | {
            id: number;
            user_id: number;
            blood_group: BloodGroup;
            city: string;
            locality: string;
            availability_status: 'available' | 'unavailable' | 'in_recovery';
            recovery_until: string | null;
            verification_status: 'pending' | 'verified' | 'rejected';
            user_name: string;
          }
        | undefined;

      if (!donor || donor.verification_status === 'rejected') {
        res.status(404).json({ error: 'Donor profile not found.' });
        return;
      }

      const sender = req.authUser!;
      if (donor.user_id === sender.id) {
        res.status(400).json({ error: 'You cannot send a direct alert to your own donor profile.' });
        return;
      }

      if (!isRecoveryEligible(donor.recovery_until)) {
        res.status(409).json({
          error: 'This donor is currently in a mandatory 90-day post-donation recovery period.',
        });
        return;
      }

      if (donor.availability_status !== 'available') {
        res.status(409).json({
          error: 'This donor is currently marked unavailable.',
        });
        return;
      }

      const body = req.body ?? {};
      const requestIdRaw =
        body.requestId !== undefined && body.requestId !== null && body.requestId !== ''
          ? Number(body.requestId)
          : null;
      const hospitalNameInput =
        typeof body.hospitalName === 'string' ? body.hospitalName.trim().slice(0, 120) : '';
      const messageInput =
        typeof body.message === 'string' ? body.message.trim().slice(0, 300) : '';

      let linkedRequest: {
        id: number;
        request_code: string;
        hospital_name: string;
        locality: string;
        blood_group: BloodGroup;
        lifecycle_status: string;
      } | null = null;

      if (requestIdRaw !== null) {
        if (!Number.isInteger(requestIdRaw) || requestIdRaw <= 0) {
          res.status(400).json({ error: 'Invalid requestId.' });
          return;
        }
        const reqRow = db
          .prepare(
            `SELECT id, request_code, hospital_name, locality, blood_group, lifecycle_status
             FROM blood_requests
             WHERE id = ?`
          )
          .get(requestIdRaw) as
          | {
              id: number;
              request_code: string;
              hospital_name: string;
              locality: string;
              blood_group: BloodGroup;
              lifecycle_status: string;
            }
          | undefined;

        if (!reqRow) {
          res.status(404).json({ error: 'Linked SOS request not found.' });
          return;
        }
        if (['closed', 'expired', 'cancelled'].includes(reqRow.lifecycle_status)) {
          res.status(409).json({ error: 'Linked SOS request is no longer active.' });
          return;
        }
        if (!isCompatibleDonor(reqRow.blood_group, donor.blood_group)) {
          res.status(400).json({
            error: `Donor blood group ${donor.blood_group} is not red-cell compatible with ${reqRow.blood_group}.`,
          });
          return;
        }
        linkedRequest = reqRow;
      }

      if (!linkedRequest && messageInput.length < 5 && hospitalNameInput.length < 3) {
        res.status(400).json({
          error: 'Link an active SOS request or enter a brief hospital coordination note (min 5 characters).',
        });
        return;
      }

      const nowIso = new Date().toISOString();
      const senderMasked = maskDisplayName(sender.name);
      const donorMasked = maskDisplayName(donor.user_name);

      const title = linkedRequest
        ? `Direct Donor Alert · ${linkedRequest.request_code} (${linkedRequest.blood_group})`
        : `Direct ${donor.blood_group} Donor Inquiry${hospitalNameInput ? ` · ${hospitalNameInput}` : ''}`;

      const notifBodyParts: string[] = [];
      if (linkedRequest) {
        notifBodyParts.push(
          `${senderMasked} alerted you for ${linkedRequest.request_code} at ${linkedRequest.hospital_name} (${linkedRequest.locality}).`
        );
      } else {
        notifBodyParts.push(
          `${senderMasked} (${sender.role}) sent an urgent ${donor.blood_group} inquiry${
            hospitalNameInput ? ` for ${hospitalNameInput}` : ''
          }.`
        );
      }
      if (messageInput) {
        notifBodyParts.push(`Note: "${messageInput}"`);
      }

      const notifId = Number(
        db
          .prepare(
            `INSERT INTO notifications (user_id, request_id, channel, delivery_status, title, message, is_read, created_at)
             VALUES (?, ?, 'in_app', 'delivered', ?, ?, 0, ?)`
          )
          .run(
            donor.user_id,
            linkedRequest?.id ?? null,
            title,
            notifBodyParts.join(' '),
            nowIso
          ).lastInsertRowid
      );

      writeAuditLog(db, {
        actorUserId: sender.id,
        actorName: senderMasked,
        actorRole: sender.role,
        action: 'DONOR_DIRECT_PING',
        entityType: 'donor',
        entityId: donor.id,
        details: `Dispatched privacy-masked direct alert to ${donor.blood_group} donor (${donorMasked})${
          linkedRequest ? ` for ${linkedRequest.request_code}` : ''
        }.`,
        createdAt: nowIso,
      });

      getIo()?.emit('notification:created', {
        targetUserId: donor.user_id,
        requestId: linkedRequest?.id ?? null,
      });

      res.status(201).json({
        ok: true,
        notificationId: notifId,
        donorInitials: donorMasked,
        message: 'Privacy-masked alert dispatched to donor.',
      });
    }
  );

  return router;
}
