import { Router } from 'express';
import type { Server as SocketIOServer } from 'socket.io';
import {
  calculateHaversineKm,
  getCompatibleRecipientGroups,
  isCompatibleDonor,
  isRecoveryEligible,
  isValidBloodGroup,
  maskDisplayName,
  matchEligibleDonors,
  validateSosRequestInput,
} from '../../shared/bloodCompatibility.ts';
import { findLocalityCoordinates, HYDERABAD_HOSPITALS } from '../../shared/hyderabadData.ts';
import type { BloodGroup } from '../../shared/types.ts';
import { type AuthenticatedRequest, createAuthMiddleware, sensitiveActionRateLimiter } from '../auth.ts';
import {
  getAllMaskedDonors,
  getSystemConfigNumber,
  mapBloodRequestRow,
  mapMaskedResponseRow,
  restoreExpiredRecoveries,
  runExpirationSweep,
  type SqliteDb,
  writeAuditLog,
} from '../db.ts';

function generateRequestCode(city: string): string {
  const prefix = city.trim().slice(0, 3).toUpperCase() || 'SOS';
  const rand = Math.floor(1000 + Math.random() * 9000);
  const stamp = Date.now().toString().slice(-3);
  return `REQ-${prefix}-${rand}${stamp}`;
}

export function createRequestsRouter(
  getDb: () => SqliteDb,
  getIo: () => SocketIOServer | null
): Router {
  const router = Router();
  const { optionalAuth, requireAuth, requireRole } = createAuthMiddleware(getDb);

  // Create Emergency Blood SOS Request
  router.post(
    '/',
    requireAuth,
    sensitiveActionRateLimiter,
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      const user = req.authUser!;
      const body = req.body ?? {};
      const unitsNum = Number(body.unitsRequired);

      const validation = validateSosRequestInput({
        patientName: String(body.patientName || ''),
        hospitalName: String(body.hospitalName || ''),
        hospitalLocation: String(body.hospitalLocation || ''),
        city: String(body.city || ''),
        locality: String(body.locality || ''),
        bloodGroup: String(body.bloodGroup || ''),
        unitsRequired: unitsNum,
        urgencyDeadline: String(body.urgencyDeadline || ''),
        doctorVerificationContact: String(body.doctorVerificationContact || ''),
        additionalInfo: String(body.additionalInfo || ''),
      });

      if (!validation.valid) {
        res.status(400).json({ error: 'Validation failed.', fieldErrors: validation.errors });
        return;
      }

      const now = new Date();
      const nowIso = now.toISOString();
      const expHours = getSystemConfigNumber(db, 'default_expiration_hours', 24);
      const deadlineDate = new Date(String(body.urgencyDeadline));
      const defaultExpiry = new Date(now.getTime() + expHours * 60 * 60 * 1000);
      // Request expires at the configured expiration window (at least as long as deadline up to 72h, or default 24h)
      const expiresAt =
        deadlineDate.getTime() > defaultExpiry.getTime()
          ? new Date(Math.min(deadlineDate.getTime(), now.getTime() + 72 * 60 * 60 * 1000)).toISOString()
          : defaultExpiry.toISOString();

      const city = String(body.city).trim();
      const locality = String(body.locality).trim();
      const hospitalName = String(body.hospitalName).trim();
      const matchedHospital = HYDERABAD_HOSPITALS.find(
        (h) => h.name.toLowerCase() === hospitalName.toLowerCase()
      );
      const locCoords = findLocalityCoordinates(city, locality);
      const latitude =
        typeof body.latitude === 'number'
          ? body.latitude
          : matchedHospital?.latitude ?? locCoords?.latitude ?? null;
      const longitude =
        typeof body.longitude === 'number'
          ? body.longitude
          : matchedHospital?.longitude ?? locCoords?.longitude ?? null;

      const requestCode = generateRequestCode(city);
      // Requests must NOT be publicly marked medically verified until an admin actually verifies
      const initialVerificationStatus = 'pending';

      const tx = db.transaction(() => {
        const requestId = Number(
          db
            .prepare(
              `INSERT INTO blood_requests (
                request_code, requester_id, patient_name, hospital_name, hospital_location,
                latitude, longitude, city, locality, blood_group, units_required, units_committed,
                urgency_deadline, doctor_verification_contact, additional_info,
                verification_status, lifecycle_status, is_demo, created_at, expires_at, closed_at
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, 'open', ?, ?, ?, NULL)`
            )
            .run(
              requestCode,
              user.id,
              String(body.patientName).trim(),
              hospitalName,
              String(body.hospitalLocation).trim(),
              latitude,
              longitude,
              city,
              locality,
              String(body.bloodGroup),
              unitsNum,
              deadlineDate.toISOString(),
              String(body.doctorVerificationContact).trim(),
              String(body.additionalInfo || '').trim(),
              initialVerificationStatus,
              user.isDemo ? 1 : 0,
              nowIso,
              expiresAt
            ).lastInsertRowid
        );

        db.prepare(
          `INSERT INTO hospital_verifications (request_id, doctor_contact, verified_by_user_id, status, notes, checked_at)
           VALUES (?, ?, NULL, 'pending', 'Awaiting administrator verification of doctor/blood-bank contact.', ?)`
        ).run(requestId, String(body.doctorVerificationContact).trim(), nowIso);

        writeAuditLog(db, {
          actorUserId: user.id,
          actorName: user.name,
          actorRole: user.role,
          action: 'REQUEST_CREATED',
          entityType: 'blood_request',
          entityId: requestId,
          details: `Created ${requestCode} for ${unitsNum} unit(s) of ${body.bloodGroup} at ${hospitalName}.`,
          createdAt: nowIso,
        });

        return requestId;
      });

      const requestId = tx();
      const row = db
        .prepare(
          `SELECT r.*, u.name AS requester_name
           FROM blood_requests r
           JOIN users u ON u.id = r.requester_id
           WHERE r.id = ?`
        )
        .get(requestId) as Parameters<typeof mapBloodRequestRow>[0];

      const requestRecord = mapBloodRequestRow(row);
      const maskedDonors = getAllMaskedDonors(db);
      const matched = matchEligibleDonors(maskedDonors, {
        recipientBloodGroup: requestRecord.bloodGroup,
        city: requestRecord.city,
        targetLatitude: requestRecord.latitude,
        targetLongitude: requestRecord.longitude,
      });

      requestRecord.compatibleDonorCount = matched.length;

      getIo()?.emit('request:created', requestRecord);

      res.status(201).json({
        request: requestRecord,
        compatibleDonorCount: matched.length,
      });
    }
  );

  // List Emergency Blood Requests (Active broadcast feed or historical/mine)
  router.get('/', optionalAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const { expiredIds } = runExpirationSweep(db);
    if (expiredIds.length > 0) {
      getIo()?.emit('request:expired', { expiredIds });
    }

    const scope = String(req.query.scope || 'active');
    const bloodGroup = typeof req.query.bloodGroup === 'string' ? req.query.bloodGroup.trim() : '';
    const compatibleFor =
      typeof req.query.compatibleFor === 'string' ? req.query.compatibleFor.trim() : '';
    const searchQuery = typeof req.query.q === 'string' ? req.query.q.trim() : '';
    const city = typeof req.query.city === 'string' ? req.query.city.trim() : '';
    const locality = typeof req.query.locality === 'string' ? req.query.locality.trim() : '';
    const urgency = typeof req.query.urgency === 'string' ? req.query.urgency.trim() : '';
    const lifecycleStatus =
      typeof req.query.lifecycleStatus === 'string' ? req.query.lifecycleStatus.trim() : '';
    const verificationStatus =
      typeof req.query.verificationStatus === 'string'
        ? req.query.verificationStatus.trim()
        : '';

    const where: string[] = [];
    const params: unknown[] = [];

    if (scope === 'active') {
      where.push(`r.lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')`);
    } else if (scope === 'history') {
      where.push(`r.lifecycle_status IN ('closed', 'expired', 'cancelled')`);
    } else if (scope === 'mine') {
      if (!req.authUser) {
        res.status(401).json({ error: 'Authentication required to view your requests.' });
        return;
      }
      where.push(`r.requester_id = ?`);
      params.push(req.authUser.id);
    }

    if (bloodGroup && isValidBloodGroup(bloodGroup)) {
      where.push(`r.blood_group = ?`);
      params.push(bloodGroup);
    }
    if (compatibleFor && isValidBloodGroup(compatibleFor)) {
      const recipients = getCompatibleRecipientGroups(compatibleFor);
      if (recipients.length > 0) {
        where.push(`r.blood_group IN (${recipients.map(() => '?').join(', ')})`);
        params.push(...recipients);
      }
    }
    if (searchQuery) {
      const like = `%${searchQuery.toLowerCase()}%`;
      where.push(
        `(LOWER(r.request_code) LIKE ? OR LOWER(r.hospital_name) LIKE ? OR LOWER(r.locality) LIKE ? OR LOWER(r.patient_name) LIKE ? OR LOWER(r.hospital_location) LIKE ?)`
      );
      params.push(like, like, like, like, like);
    }
    if (city) {
      where.push(`LOWER(r.city) = LOWER(?)`);
      params.push(city);
    }
    if (locality) {
      where.push(`LOWER(r.locality) = LOWER(?)`);
      params.push(locality);
    }
    if (lifecycleStatus) {
      where.push(`r.lifecycle_status = ?`);
      params.push(lifecycleStatus);
    }
    if (verificationStatus) {
      where.push(`r.verification_status = ?`);
      params.push(verificationStatus);
    }
    if (urgency === 'critical') {
      const cutoff = new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString();
      where.push(`r.urgency_deadline <= ?`);
      params.push(cutoff);
    } else if (urgency === 'urgent') {
      const cutoff = new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString();
      where.push(`r.urgency_deadline <= ?`);
      params.push(cutoff);
    }

    const whereClause = where.length > 0 ? `WHERE ${where.join(' AND ')}` : '';
    const rows = db
      .prepare(
        `SELECT r.*, u.name AS requester_name
         FROM blood_requests r
         JOIN users u ON u.id = r.requester_id
         ${whereClause}
         ORDER BY
           CASE r.lifecycle_status
             WHEN 'open' THEN 1
             WHEN 'donors_responded' THEN 2
             WHEN 'fulfilled_in_transit' THEN 3
             ELSE 4
           END,
           r.urgency_deadline ASC`
      )
      .all(...params) as Array<Parameters<typeof mapBloodRequestRow>[0]>;

    const maskedDonors = getAllMaskedDonors(db);
    const requests = rows.map((row) => {
      const record = mapBloodRequestRow(row);
      const matched = matchEligibleDonors(maskedDonors, {
        recipientBloodGroup: record.bloodGroup,
        city: record.city,
        targetLatitude: record.latitude,
        targetLongitude: record.longitude,
      });
      return {
        ...record,
        compatibleDonorCount: matched.length,
      };
    });

    res.json({ requests });
  });

  // Get single request with privacy-masked compatible donors, responses, relay messages, and audit history
  router.get('/:id', optionalAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    runExpirationSweep(db);

    const reqId = Number(req.params.id);
    if (!Number.isInteger(reqId) || reqId <= 0) {
      res.status(400).json({ error: 'Invalid request ID.' });
      return;
    }

    const row = db
      .prepare(
        `SELECT r.*, u.name AS requester_name
         FROM blood_requests r
         JOIN users u ON u.id = r.requester_id
         WHERE r.id = ?`
      )
      .get(reqId) as Parameters<typeof mapBloodRequestRow>[0] | undefined;

    if (!row) {
      res.status(404).json({ error: 'Blood request not found.' });
      return;
    }

    const requestRecord = mapBloodRequestRow(row);
    const radiusKm = req.query.radiusKm ? Number(req.query.radiusKm) : null;
    const localityFilter =
      typeof req.query.locality === 'string' && req.query.locality.trim()
        ? req.query.locality.trim()
        : undefined;

    const maskedDonors = getAllMaskedDonors(db);
    const compatibleDonors = matchEligibleDonors(maskedDonors, {
      recipientBloodGroup: requestRecord.bloodGroup,
      city: requestRecord.city,
      locality: localityFilter,
      targetLatitude: requestRecord.latitude,
      targetLongitude: requestRecord.longitude,
      maxRadiusKm: Number.isFinite(radiusKm) && (radiusKm as number) > 0 ? radiusKm : null,
    });

    const responseRows = db
      .prepare(
        `SELECT resp.*, u.name AS donor_name, d.blood_group AS donor_blood_group,
                d.city AS donor_city, d.locality AS donor_locality,
                d.latitude AS donor_lat, d.longitude AS donor_lon, d.consent_status AS donor_consent
         FROM responses resp
         JOIN donors d ON d.id = resp.donor_id
         JOIN users u ON u.id = d.user_id
         WHERE resp.request_id = ?
         ORDER BY resp.created_at DESC`
      )
      .all(reqId) as Array<
      Parameters<typeof mapMaskedResponseRow>[0] & {
        donor_lat: number | null;
        donor_lon: number | null;
        donor_consent: number;
      }
    >;

    const responses = responseRows.map((resp) => {
      const mapped = mapMaskedResponseRow(resp);
      if (
        resp.donor_consent &&
        resp.donor_lat != null &&
        resp.donor_lon != null &&
        requestRecord.latitude != null &&
        requestRecord.longitude != null
      ) {
        mapped.distanceKm = calculateHaversineKm(
          requestRecord.latitude,
          requestRecord.longitude,
          resp.donor_lat,
          resp.donor_lon
        );
      }
      return mapped;
    });

    const fulfillments = db
      .prepare(
        `SELECT ft.id, ft.request_id AS requestId, ft.donor_id AS donorId,
                ft.units_fulfilled AS unitsFulfilled, ft.confirmation_status AS confirmationStatus,
                ft.confirmed_at AS confirmedAt, du.name AS donor_name, d.blood_group AS donorBloodGroup,
                cu.name AS confirmedByName
         FROM fulfillment_transactions ft
         JOIN donors d ON d.id = ft.donor_id
         JOIN users du ON du.id = d.user_id
         JOIN users cu ON cu.id = ft.confirmed_by_user_id
         WHERE ft.request_id = ?
         ORDER BY ft.confirmed_at DESC`
      )
      .all(reqId)
      .map((f: unknown) => {
        const item = f as {
          id: number;
          requestId: number;
          donorId: number;
          unitsFulfilled: number;
          confirmationStatus: 'confirmed' | 'pending';
          confirmedAt: string;
          donor_name: string;
          donorBloodGroup: BloodGroup;
          confirmedByName: string;
        };
        return {
          id: item.id,
          requestId: item.requestId,
          donorId: item.donorId,
          donorInitials: maskDisplayName(item.donor_name),
          donorBloodGroup: item.donorBloodGroup,
          unitsFulfilled: item.unitsFulfilled,
          confirmationStatus: item.confirmationStatus,
          confirmedByName: item.confirmedByName,
          confirmedAt: item.confirmedAt,
        };
      });

    const auditLogs = db
      .prepare(
        `SELECT id, actor_user_id AS actorUserId, actor_name AS actorName,
                actor_role AS actorRole, action, entity_type AS entityType,
                entity_id AS entityId, details, created_at AS createdAt
         FROM audit_logs
         WHERE entity_type = 'blood_request' AND entity_id = ?
         ORDER BY created_at ASC`
      )
      .all(String(reqId));

    const simulatedSmsCount = (
      db
        .prepare(
          `SELECT COUNT(*) AS count FROM notifications
           WHERE request_id = ? AND channel = 'simulated_sms'`
        )
        .get(reqId) as { count: number }
    ).count;

    res.json({
      request: {
        ...requestRecord,
        compatibleDonorCount: compatibleDonors.length,
      },
      compatibleDonors,
      responses,
      fulfillments,
      auditLogs,
      simulatedSmsCount,
    });
  });

  // Update request details (owner or admin)
  router.patch('/:id', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const reqId = Number(req.params.id);
    const existing = db
      .prepare(`SELECT * FROM blood_requests WHERE id = ?`)
      .get(reqId) as { id: number; requester_id: number; lifecycle_status: string } | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Blood request not found.' });
      return;
    }
    if (req.authUser!.role !== 'admin' && existing.requester_id !== req.authUser!.id) {
      res.status(403).json({ error: 'Only the requester or an administrator can modify this request.' });
      return;
    }
    if (['closed', 'expired', 'cancelled'].includes(existing.lifecycle_status)) {
      res.status(409).json({ error: 'Closed or expired requests cannot be edited.' });
      return;
    }

    const { additionalInfo, urgencyDeadline } = req.body ?? {};
    if (urgencyDeadline) {
      const parsed = new Date(String(urgencyDeadline));
      if (Number.isNaN(parsed.getTime()) || parsed.getTime() <= Date.now()) {
        res.status(400).json({ error: 'Urgency deadline must be a valid future timestamp.' });
        return;
      }
      db.prepare(`UPDATE blood_requests SET urgency_deadline = ? WHERE id = ?`).run(
        parsed.toISOString(),
        reqId
      );
    }
    if (typeof additionalInfo === 'string') {
      db.prepare(`UPDATE blood_requests SET additional_info = ? WHERE id = ?`).run(
        additionalInfo.trim(),
        reqId
      );
    }

    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: req.authUser!.role,
      action: 'REQUEST_UPDATED',
      entityType: 'blood_request',
      entityId: reqId,
      details: 'Updated emergency request notes or deadline.',
    });

    getIo()?.emit('request:updated', { id: reqId });
    res.json({ ok: true });
  });

  // Admin verification of emergency request (+ optional simulated SMS dispatch)
  router.post(
    '/:id/verify',
    requireAuth,
    requireRole('admin'),
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      const reqId = Number(req.params.id);
      const { status, notes } = req.body ?? {};

      if (status !== 'verified' && status !== 'rejected') {
        res.status(400).json({ error: 'status must be verified or rejected.' });
        return;
      }

      const row = db
        .prepare(
          `SELECT r.*, u.name AS requester_name
           FROM blood_requests r
           JOIN users u ON u.id = r.requester_id
           WHERE r.id = ?`
        )
        .get(reqId) as Parameters<typeof mapBloodRequestRow>[0] | undefined;

      if (!row) {
        res.status(404).json({ error: 'Blood request not found.' });
        return;
      }

      const nowIso = new Date().toISOString();
      let simulatedCount = 0;

      const tx = db.transaction(() => {
        db.prepare(`UPDATE blood_requests SET verification_status = ? WHERE id = ?`).run(
          status,
          reqId
        );

        db.prepare(
          `INSERT INTO hospital_verifications (request_id, doctor_contact, verified_by_user_id, status, notes, checked_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).run(
          reqId,
          row.doctor_verification_contact,
          req.authUser!.id,
          status,
          typeof notes === 'string' && notes.trim()
            ? notes.trim()
            : `Hospital contact ${status} by administrator.`,
          nowIso
        );

        writeAuditLog(db, {
          actorUserId: req.authUser!.id,
          actorName: req.authUser!.name,
          actorRole: 'admin',
          action: status === 'verified' ? 'REQUEST_VERIFIED' : 'REQUEST_REJECTED',
          entityType: 'blood_request',
          entityId: reqId,
          details: `Request ${row.request_code} marked ${status}.`,
          createdAt: nowIso,
        });

        // When verified, trigger SMS SOS Dispatch Simulator for compatible nearby donors
        if (status === 'verified') {
          const maskedDonors = getAllMaskedDonors(db);
          const matched = matchEligibleDonors(maskedDonors, {
            recipientBloodGroup: row.blood_group,
            city: row.city,
            targetLatitude: row.latitude,
            targetLongitude: row.longitude,
            maxRadiusKm: 25,
          });

          const insertNotif = db.prepare(
            `INSERT INTO notifications (user_id, request_id, channel, delivery_status, title, message, is_read, created_at)
             VALUES (?, ?, 'simulated_sms', 'simulated_sent', ?, ?, 0, ?)`
          );

          for (const d of matched) {
            const donorUser = db
              .prepare(`SELECT user_id FROM donors WHERE id = ?`)
              .get(d.id) as { user_id: number } | undefined;
            if (donorUser) {
              insertNotif.run(
                donorUser.user_id,
                reqId,
                `[SIMULATED SMS] Urgent ${row.blood_group} Needed`,
                `Simulated SOS alert for ${row.request_code}: ${row.units_required} unit(s) of ${row.blood_group} needed at ${row.hospital_name} (${row.locality}).`,
                nowIso
              );
              simulatedCount++;
            }
          }
        }
      });

      tx();
      getIo()?.emit('request:verified', { id: reqId, verificationStatus: status });
      if (simulatedCount > 0) {
        getIo()?.emit('notification:created', { requestId: reqId });
      }

      res.json({
        ok: true,
        verificationStatus: status,
        simulatedSmsTargeted: simulatedCount,
      });
    }
  );

  // Close or cancel request (requester owner or admin)
  router.post('/:id/close', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const reqId = Number(req.params.id);
    const action = req.body?.action === 'cancel' ? 'cancelled' : 'closed';

    const existing = db
      .prepare(`SELECT * FROM blood_requests WHERE id = ?`)
      .get(reqId) as
      | { id: number; requester_id: number; request_code: string; lifecycle_status: string }
      | undefined;

    if (!existing) {
      res.status(404).json({ error: 'Blood request not found.' });
      return;
    }
    if (req.authUser!.role !== 'admin' && existing.requester_id !== req.authUser!.id) {
      res.status(403).json({ error: 'Only the requester or an administrator can close this request.' });
      return;
    }
    if (['closed', 'expired', 'cancelled'].includes(existing.lifecycle_status)) {
      res.status(409).json({ error: `Request is already ${existing.lifecycle_status}.` });
      return;
    }

    const nowIso = new Date().toISOString();
    db.prepare(
      `UPDATE blood_requests SET lifecycle_status = ?, closed_at = ? WHERE id = ?`
    ).run(action, nowIso, reqId);

    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: req.authUser!.role,
      action: action === 'cancelled' ? 'REQUEST_CANCELLED' : 'REQUEST_CLOSED',
      entityType: 'blood_request',
      entityId: reqId,
      details: `Request ${existing.request_code} marked ${action}.`,
      createdAt: nowIso,
    });

    getIo()?.emit('request:updated', { id: reqId, lifecycleStatus: action });
    res.json({ ok: true, lifecycleStatus: action });
  });

  // Donor clicks "I Can Donate"
  router.post(
    '/:id/respond',
    requireAuth,
    requireRole('donor'),
    sensitiveActionRateLimiter,
    (req: AuthenticatedRequest, res) => {
      const db = getDb();
      runExpirationSweep(db);
      restoreExpiredRecoveries(db);

      const reqId = Number(req.params.id);
      const unitsOffered = req.body?.unitsOffered !== undefined ? Number(req.body.unitsOffered) : 1;

      if (!Number.isInteger(unitsOffered) || unitsOffered < 1 || unitsOffered > 2) {
        res.status(400).json({ error: 'unitsOffered must be an integer (1 or 2).' });
        return;
      }

      const donor = db
        .prepare(
          `SELECT d.*, u.name AS donor_name
           FROM donors d
           JOIN users u ON u.id = d.user_id
           WHERE d.user_id = ?`
        )
        .get(req.authUser!.id) as
        | {
            id: number;
            user_id: number;
            donor_name: string;
            blood_group: BloodGroup;
            availability_status: string;
            recovery_until: string | null;
          }
        | undefined;

      if (!donor) {
        res.status(404).json({ error: 'Donor profile not found for this user.' });
        return;
      }

      if (!isRecoveryEligible(donor.recovery_until)) {
        res.status(409).json({
          error: `You are currently in a post-donation recovery period until ${new Date(
            donor.recovery_until!
          ).toLocaleDateString()}.`,
        });
        return;
      }

      if (donor.availability_status !== 'available') {
        res.status(409).json({
          error: 'Set your donor availability to Available before responding to an SOS.',
        });
        return;
      }

      const nowIso = new Date().toISOString();

      try {
        const result = db.transaction(() => {
          const requestRow = db
            .prepare(`SELECT * FROM blood_requests WHERE id = ?`)
            .get(reqId) as
            | {
                id: number;
                request_code: string;
                requester_id: number;
                blood_group: BloodGroup;
                units_required: number;
                units_committed: number;
                lifecycle_status: string;
                expires_at: string;
              }
            | undefined;

          if (!requestRow) {
            throw Object.assign(new Error('Blood request not found.'), { statusCode: 404 });
          }

          if (['closed', 'expired', 'cancelled'].includes(requestRow.lifecycle_status)) {
            throw Object.assign(
              new Error(`This request is ${requestRow.lifecycle_status} and no longer accepting donors.`),
              { statusCode: 409 }
            );
          }

          if (new Date(requestRow.expires_at).getTime() <= Date.now()) {
            throw Object.assign(new Error('This request has expired.'), { statusCode: 409 });
          }

          if (!isCompatibleDonor(requestRow.blood_group, donor.blood_group)) {
            throw Object.assign(
              new Error(
                `Blood group ${donor.blood_group} is not red-cell compatible with recipient ${requestRow.blood_group}.`
              ),
              { statusCode: 400 }
            );
          }

          const duplicate = db
            .prepare(`SELECT id FROM responses WHERE request_id = ? AND donor_id = ?`)
            .get(reqId, donor.id) as { id: number } | undefined;

          if (duplicate) {
            throw Object.assign(
              new Error('You have already responded to this emergency request.'),
              { statusCode: 409 }
            );
          }

          if (requestRow.units_committed + unitsOffered > requestRow.units_required) {
            throw Object.assign(
              new Error(
                `Over-allocation prevented: only ${
                  requestRow.units_required - requestRow.units_committed
                } unit(s) remain unallocated.`
              ),
              { statusCode: 409 }
            );
          }

          const responseId = Number(
            db
              .prepare(
                `INSERT INTO responses (request_id, donor_id, units_offered, response_status, created_at, updated_at)
                 VALUES (?, ?, ?, 'committed', ?, ?)`
              )
              .run(reqId, donor.id, unitsOffered, nowIso, nowIso).lastInsertRowid
          );

          const nextCommitted = requestRow.units_committed + unitsOffered;
          // Advance lifecycle: Stage 2 (donors_responded) or Stage 3 (fulfilled_in_transit) if target units committed.
          // Never auto-close! Delivery confirmation must happen via Mark Blood Received.
          const nextLifecycle =
            nextCommitted >= requestRow.units_required
              ? 'fulfilled_in_transit'
              : 'donors_responded';

          db.prepare(
            `UPDATE blood_requests
             SET units_committed = ?, lifecycle_status = ?
             WHERE id = ?`
          ).run(nextCommitted, nextLifecycle, reqId);

          const maskedInitials = maskDisplayName(donor.donor_name);

          db.prepare(
            `INSERT INTO notifications (user_id, request_id, channel, delivery_status, title, message, is_read, created_at)
             VALUES (?, ?, 'in_app', 'delivered', ?, ?, 0, ?)`
          ).run(
            requestRow.requester_id,
            reqId,
            `Donor Committed for ${requestRow.request_code}`,
            `${donor.blood_group} donor (${maskedInitials}) committed ${unitsOffered} unit(s). Total: ${nextCommitted}/${requestRow.units_required} units committed.`,
            nowIso
          );

          writeAuditLog(db, {
            actorUserId: req.authUser!.id,
            actorName: maskedInitials,
            actorRole: 'donor',
            action: 'DONOR_RESPONDED',
            entityType: 'blood_request',
            entityId: reqId,
            details: `${donor.blood_group} donor (${maskedInitials}) committed ${unitsOffered} unit(s). Lifecycle -> ${nextLifecycle}.`,
            createdAt: nowIso,
          });

          return {
            responseId,
            unitsCommitted: nextCommitted,
            unitsRequired: requestRow.units_required,
            lifecycleStatus: nextLifecycle,
            donorInitials: maskedInitials,
          };
        })();

        getIo()?.emit('response:created', {
          requestId: reqId,
          unitsCommitted: result.unitsCommitted,
          lifecycleStatus: result.lifecycleStatus,
        });
        getIo()?.emit('request:updated', {
          id: reqId,
          unitsCommitted: result.unitsCommitted,
          lifecycleStatus: result.lifecycleStatus,
        });
        getIo()?.emit('notification:created', { requestId: reqId });

        res.status(201).json(result);
      } catch (err: unknown) {
        const typed = err as Error & { statusCode?: number };
        res.status(typed.statusCode || 500).json({ error: typed.message });
      }
    }
  );

  // Get privacy-masked donor responses for a request
  router.get('/:id/responses', (req, res) => {
    const db = getDb();
    const reqId = Number(req.params.id);
    const rows = db
      .prepare(
        `SELECT resp.*, u.name AS donor_name, d.blood_group AS donor_blood_group,
                d.city AS donor_city, d.locality AS donor_locality
         FROM responses resp
         JOIN donors d ON d.id = resp.donor_id
         JOIN users u ON u.id = d.user_id
         WHERE resp.request_id = ?
         ORDER BY resp.created_at DESC`
      )
      .all(reqId) as Array<Parameters<typeof mapMaskedResponseRow>[0]>;

    res.json({ responses: rows.map(mapMaskedResponseRow) });
  });

  // Privacy-masked in-app relay messaging (never exposes phone numbers)
  router.get('/:id/relay', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const reqId = Number(req.params.id);
    const messages = db
      .prepare(
        `SELECT id, request_id AS requestId, sender_user_id AS senderUserId,
                sender_label AS senderLabel, sender_role AS senderRole,
                message, created_at AS createdAt
         FROM relay_messages
         WHERE request_id = ?
         ORDER BY created_at ASC`
      )
      .all(reqId);

    res.json({ messages });
  });

  router.post('/:id/relay', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const reqId = Number(req.params.id);
    const message = String(req.body?.message || '').trim();
    if (!message || message.length < 2 || message.length > 500) {
      res.status(400).json({ error: 'Relay message must be between 2 and 500 characters.' });
      return;
    }

    const requestRow = db
      .prepare(`SELECT id, requester_id FROM blood_requests WHERE id = ?`)
      .get(reqId) as { id: number; requester_id: number } | undefined;
    if (!requestRow) {
      res.status(404).json({ error: 'Request not found.' });
      return;
    }

    const user = req.authUser!;
    let senderLabel = `Coordinator (${maskDisplayName(user.name)})`;
    if (user.role === 'requester') {
      senderLabel = `Requester (${maskDisplayName(user.name)})`;
    } else if (user.role === 'donor') {
      const donor = db
        .prepare(`SELECT blood_group FROM donors WHERE user_id = ?`)
        .get(user.id) as { blood_group: string } | undefined;
      senderLabel = `Donor (${maskDisplayName(user.name)}${
        donor ? ` · ${donor.blood_group}` : ''
      })`;
    } else if (user.role === 'admin') {
      senderLabel = `LifeLine Admin`;
    }

    const nowIso = new Date().toISOString();
    const msgId = Number(
      db
        .prepare(
          `INSERT INTO relay_messages (request_id, sender_user_id, sender_label, sender_role, message, created_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        )
        .run(reqId, user.id, senderLabel, user.role, message, nowIso).lastInsertRowid
    );

    const created = {
      id: msgId,
      requestId: reqId,
      senderUserId: user.id,
      senderLabel,
      senderRole: user.role,
      message,
      createdAt: nowIso,
    };

    getIo()?.emit('relay:message', created);
    res.status(201).json({ message: created });
  });

  // Stretch Feature 7: SMS SOS Dispatch Simulator (explicitly labeled simulated)
  router.post('/:id/dispatch-sim', requireAuth, (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const reqId = Number(req.params.id);
    const radiusKm = req.body?.radiusKm ? Number(req.body.radiusKm) : 20;

    const reqRow = db
      .prepare(
        `SELECT r.*, u.name AS requester_name
         FROM blood_requests r
         JOIN users u ON u.id = r.requester_id
         WHERE r.id = ?`
      )
      .get(reqId) as Parameters<typeof mapBloodRequestRow>[0] | undefined;

    if (!reqRow) {
      res.status(404).json({ error: 'Request not found.' });
      return;
    }

    if (reqRow.verification_status !== 'verified') {
      res.status(409).json({
        error: 'Request must be verified by an administrator before running SMS SOS broadcast simulation.',
      });
      return;
    }

    const maskedDonors = getAllMaskedDonors(db);
    const targets = matchEligibleDonors(maskedDonors, {
      recipientBloodGroup: reqRow.blood_group,
      city: reqRow.city,
      targetLatitude: reqRow.latitude,
      targetLongitude: reqRow.longitude,
      maxRadiusKm: Number.isFinite(radiusKm) && radiusKm > 0 ? radiusKm : 20,
    });

    const nowIso = new Date().toISOString();
    const insertNotif = db.prepare(
      `INSERT INTO notifications (user_id, request_id, channel, delivery_status, title, message, is_read, created_at)
       VALUES (?, ?, 'simulated_sms', 'simulated_sent', ?, ?, 0, ?)`
    );

    const dispatches = targets.map((donor) => {
      const donorUser = db
        .prepare(`SELECT user_id FROM donors WHERE id = ?`)
        .get(donor.id) as { user_id: number } | undefined;
      if (donorUser) {
        insertNotif.run(
          donorUser.user_id,
          reqId,
          `[SIMULATED SMS] ${reqRow.request_code}`,
          `Simulated alert for ${reqRow.blood_group} at ${reqRow.hospital_name}.`,
          nowIso
        );
      }
      return {
        donorId: donor.id,
        donorInitials: donor.donorInitials,
        bloodGroup: donor.bloodGroup,
        locality: donor.locality,
        distanceKm: donor.distanceKm,
        deliveryStatus: 'simulated_sent',
      };
    });

    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: req.authUser!.role,
      action: 'SMS_SIMULATION_RUN',
      entityType: 'blood_request',
      entityId: reqId,
      details: `Simulated SOS SMS dispatch targeted ${dispatches.length} compatible donor(s) within ${radiusKm} km.`,
      createdAt: nowIso,
    });

    res.json({
      simulated: true,
      disclaimer:
        'Simulated SMS Dispatch only — no external SMS gateway is configured in this environment.',
      targetedCount: dispatches.length,
      radiusKm,
      dispatches,
    });
  });

  return router;
}
