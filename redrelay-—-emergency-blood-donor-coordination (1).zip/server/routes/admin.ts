import { Router } from 'express';
import type { Server as SocketIOServer } from 'socket.io';
import { type AuthenticatedRequest, createAuthMiddleware } from '../auth.ts';
import {
  getAllMaskedDonors,
  getSystemConfigNumber,
  mapBloodRequestRow,
  restoreExpiredRecoveries,
  runExpirationSweep,
  type SqliteDb,
  writeAuditLog,
} from '../db.ts';

export function createAdminRouter(
  getDb: () => SqliteDb,
  getIo: () => SocketIOServer | null
): Router {
  const router = Router();
  const { requireAuth, requireRole } = createAuthMiddleware(getDb);

  router.use(requireAuth, requireRole('admin'));

  router.get('/dashboard', (_req, res) => {
    const db = getDb();
    runExpirationSweep(db);
    restoreExpiredRecoveries(db);

    const activeRequestsCount = (
      db
        .prepare(
          `SELECT COUNT(*) AS count FROM blood_requests
           WHERE lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')`
        )
        .get() as { count: number }
    ).count;

    const pendingVerificationCount = (
      db
        .prepare(
          `SELECT COUNT(*) AS count FROM blood_requests
           WHERE verification_status = 'pending'
             AND lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')`
        )
        .get() as { count: number }
    ).count;

    const closedRequestsCount = (
      db
        .prepare(`SELECT COUNT(*) AS count FROM blood_requests WHERE lifecycle_status = 'closed'`)
        .get() as { count: number }
    ).count;

    const expiredRequestsCount = (
      db
        .prepare(`SELECT COUNT(*) AS count FROM blood_requests WHERE lifecycle_status = 'expired'`)
        .get() as { count: number }
    ).count;

    const totalDonorsCount = (
      db.prepare(`SELECT COUNT(*) AS count FROM donors`).get() as { count: number }
    ).count;

    const availableDonorsCount = (
      db
        .prepare(
          `SELECT COUNT(*) AS count FROM donors
           WHERE availability_status = 'available'
             AND (recovery_until IS NULL OR recovery_until <= ?)`
        )
        .get(new Date().toISOString()) as { count: number }
    ).count;

    const totalResponsesCount = (
      db.prepare(`SELECT COUNT(*) AS count FROM responses`).get() as { count: number }
    ).count;

    const auditLogs = db
      .prepare(
        `SELECT id, actor_user_id AS actorUserId, actor_name AS actorName,
                actor_role AS actorRole, action, entity_type AS entityType,
                entity_id AS entityId, details, created_at AS createdAt
         FROM audit_logs
         ORDER BY created_at DESC, id DESC
         LIMIT 50`
      )
      .all();

    const users = db
      .prepare(
        `SELECT id, name, email, role, is_demo AS isDemo, created_at AS createdAt
         FROM users
         ORDER BY created_at DESC`
      )
      .all()
      .map((u: unknown) => {
        const item = u as Record<string, unknown>;
        return { ...item, isDemo: Boolean(item.isDemo) };
      });

    res.json({
      summary: {
        activeRequestsCount,
        pendingVerificationCount,
        closedRequestsCount,
        expiredRequestsCount,
        totalDonorsCount,
        availableDonorsCount,
        totalResponsesCount,
      },
      config: {
        recoveryDays: getSystemConfigNumber(db, 'recovery_days', 90),
        defaultExpirationHours: getSystemConfigNumber(db, 'default_expiration_hours', 24),
      },
      auditLogs,
      users,
    });
  });

  router.get('/donors', (_req, res) => {
    const db = getDb();
    const donors = getAllMaskedDonors(db);
    res.json({ donors });
  });

  router.get('/requests', (_req, res) => {
    const db = getDb();
    runExpirationSweep(db);
    const rows = db
      .prepare(
        `SELECT r.*, u.name AS requester_name
         FROM blood_requests r
         JOIN users u ON u.id = r.requester_id
         ORDER BY r.created_at DESC`
      )
      .all() as Array<Parameters<typeof mapBloodRequestRow>[0]>;
    res.json({ requests: rows.map(mapBloodRequestRow) });
  });

  router.patch('/verification', (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const { entityType, entityId, status, notes } = req.body ?? {};

    if (status !== 'verified' && status !== 'rejected') {
      res.status(400).json({ error: 'status must be verified or rejected.' });
      return;
    }

    const idNum = Number(entityId);
    if (!Number.isInteger(idNum) || idNum <= 0) {
      res.status(400).json({ error: 'Valid entityId is required.' });
      return;
    }

    const nowIso = new Date().toISOString();

    if (entityType === 'donor') {
      const result = db
        .prepare(`UPDATE donors SET verification_status = ? WHERE id = ?`)
        .run(status, idNum);
      if (result.changes === 0) {
        res.status(404).json({ error: 'Donor not found.' });
        return;
      }
      writeAuditLog(db, {
        actorUserId: req.authUser!.id,
        actorName: req.authUser!.name,
        actorRole: 'admin',
        action: `DONOR_${status.toUpperCase()}`,
        entityType: 'donor',
        entityId: idNum,
        details: typeof notes === 'string' && notes ? notes : `Donor #${idNum} marked ${status}.`,
        createdAt: nowIso,
      });
      res.json({ ok: true, entityType: 'donor', entityId: idNum, status });
      return;
    }

    if (entityType === 'blood_request') {
      const reqRow = db
        .prepare(`SELECT request_code, doctor_verification_contact FROM blood_requests WHERE id = ?`)
        .get(idNum) as { request_code: string; doctor_verification_contact: string } | undefined;
      if (!reqRow) {
        res.status(404).json({ error: 'Blood request not found.' });
        return;
      }

      db.transaction(() => {
        db.prepare(`UPDATE blood_requests SET verification_status = ? WHERE id = ?`).run(
          status,
          idNum
        );
        db.prepare(
          `INSERT INTO hospital_verifications (request_id, doctor_contact, verified_by_user_id, status, notes, checked_at)
           VALUES (?, ?, ?, ?, ?, ?)`
        ).run(
          idNum,
          reqRow.doctor_verification_contact,
          req.authUser!.id,
          status,
          typeof notes === 'string' && notes ? notes : `Marked ${status} by administrator.`,
          nowIso
        );
        writeAuditLog(db, {
          actorUserId: req.authUser!.id,
          actorName: req.authUser!.name,
          actorRole: 'admin',
          action: status === 'verified' ? 'REQUEST_VERIFIED' : 'REQUEST_REJECTED',
          entityType: 'blood_request',
          entityId: idNum,
          details: `Request ${reqRow.request_code} marked ${status}.`,
          createdAt: nowIso,
        });
      })();

      getIo()?.emit('request:verified', { id: idNum, verificationStatus: status });
      res.json({ ok: true, entityType: 'blood_request', entityId: idNum, status });
      return;
    }

    res.status(400).json({ error: 'entityType must be blood_request or donor.' });
  });

  router.post('/expire-sweep', (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const { expiredIds } = runExpirationSweep(db);
    if (expiredIds.length > 0) {
      getIo()?.emit('request:expired', { expiredIds });
    }
    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: 'admin',
      action: 'MANUAL_EXPIRATION_SWEEP',
      entityType: 'system',
      entityId: 'sweep',
      details: `Executed manual expiration sweep; expired ${expiredIds.length} request(s).`,
    });
    res.json({ expiredIds, count: expiredIds.length });
  });

  router.patch('/config', (req: AuthenticatedRequest, res) => {
    const db = getDb();
    const { recoveryDays, defaultExpirationHours } = req.body ?? {};
    const nowIso = new Date().toISOString();

    if (recoveryDays !== undefined) {
      const days = Number(recoveryDays);
      if (!Number.isInteger(days) || days < 1 || days > 365) {
        res.status(400).json({ error: 'recoveryDays must be an integer between 1 and 365.' });
        return;
      }
      db.prepare(`UPDATE system_config SET value = ?, updated_at = ? WHERE key = 'recovery_days'`).run(
        String(days),
        nowIso
      );
    }

    if (defaultExpirationHours !== undefined) {
      const hrs = Number(defaultExpirationHours);
      if (!Number.isInteger(hrs) || hrs < 1 || hrs > 168) {
        res.status(400).json({
          error: 'defaultExpirationHours must be an integer between 1 and 168.',
        });
        return;
      }
      db.prepare(
        `UPDATE system_config SET value = ?, updated_at = ? WHERE key = 'default_expiration_hours'`
      ).run(String(hrs), nowIso);
    }

    writeAuditLog(db, {
      actorUserId: req.authUser!.id,
      actorName: req.authUser!.name,
      actorRole: 'admin',
      action: 'SYSTEM_CONFIG_UPDATED',
      entityType: 'system',
      entityId: 'config',
      details: `Updated system configuration (recoveryDays=${getSystemConfigNumber(
        db,
        'recovery_days',
        90
      )}, defaultExpirationHours=${getSystemConfigNumber(db, 'default_expiration_hours', 24)}).`,
      createdAt: nowIso,
    });

    res.json({
      recoveryDays: getSystemConfigNumber(db, 'recovery_days', 90),
      defaultExpirationHours: getSystemConfigNumber(db, 'default_expiration_hours', 24),
    });
  });

  return router;
}
