import bcrypt from 'bcryptjs';
import type { NextFunction, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import type { UserPublic, UserRole } from '../shared/types.ts';
import type { SqliteDb } from './db.ts';

export const AUTH_COOKIE_NAME = 'redrelay_token';

function getJwtSecret(): string {
  return process.env.JWT_SECRET || 'redrelay-hackathon-dev-secret-change-in-prod';
}

export interface AuthTokenPayload {
  userId: number;
  role: UserRole;
  email: string;
}

export interface AuthenticatedRequest extends Request {
  authUser?: UserPublic;
}

export function hashPassword(plain: string): string {
  return bcrypt.hashSync(plain, 10);
}

export function verifyPassword(plain: string, hash: string): boolean {
  return bcrypt.compareSync(plain, hash);
}

export function signAuthToken(payload: AuthTokenPayload): string {
  return jwt.sign(payload, getJwtSecret(), { expiresIn: '7d' });
}

export function verifyAuthToken(token: string): AuthTokenPayload | null {
  try {
    const decoded = jwt.verify(token, getJwtSecret()) as AuthTokenPayload;
    if (!decoded || typeof decoded.userId !== 'number') return null;
    return decoded;
  } catch {
    return null;
  }
}

export function extractTokenFromRequest(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookieToken = req.cookies?.[AUTH_COOKIE_NAME];
  if (typeof cookieToken === 'string' && cookieToken.length > 0) {
    return cookieToken;
  }
  return null;
}

export function setAuthCookie(res: Response, token: string): void {
  res.cookie(AUTH_COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  });
}

export function clearAuthCookie(res: Response): void {
  res.clearCookie(AUTH_COOKIE_NAME, { path: '/' });
}

export function loadUserById(db: SqliteDb, userId: number): UserPublic | null {
  const row = db
    .prepare(
      `SELECT id, name, email, role, is_demo, created_at
       FROM users WHERE id = ?`
    )
    .get(userId) as
    | {
        id: number;
        name: string;
        email: string;
        role: UserRole;
        is_demo: number;
        created_at: string;
      }
    | undefined;

  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    isDemo: Boolean(row.is_demo),
    createdAt: row.created_at,
  };
}

export function createAuthMiddleware(getDatabase: () => SqliteDb) {
  function optionalAuth(req: AuthenticatedRequest, _res: Response, next: NextFunction): void {
    const token = extractTokenFromRequest(req);
    if (token) {
      const payload = verifyAuthToken(token);
      if (payload) {
        const user = loadUserById(getDatabase(), payload.userId);
        if (user) {
          req.authUser = user;
        }
      }
    }
    next();
  }

  function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
    const token = extractTokenFromRequest(req);
    if (!token) {
      res.status(401).json({ error: 'Authentication required. Please sign in.' });
      return;
    }
    const payload = verifyAuthToken(token);
    if (!payload) {
      res.status(401).json({ error: 'Session expired or invalid. Please sign in again.' });
      return;
    }
    const user = loadUserById(getDatabase(), payload.userId);
    if (!user) {
      res.status(401).json({ error: 'User account not found.' });
      return;
    }
    req.authUser = user;
    next();
  }

  function requireRole(...allowedRoles: UserRole[]) {
    return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
      if (!req.authUser) {
        res.status(401).json({ error: 'Authentication required.' });
        return;
      }
      if (!allowedRoles.includes(req.authUser.role)) {
        res.status(403).json({
          error: `Access denied. Required role: ${allowedRoles.join(' or ')}.`,
        });
        return;
      }
      next();
    };
  }

  return { optionalAuth, requireAuth, requireRole };
}

export const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many authentication attempts. Please wait a few minutes.' },
});

export const sensitiveActionRateLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Rate limit exceeded for emergency actions. Please slow down.' },
});
