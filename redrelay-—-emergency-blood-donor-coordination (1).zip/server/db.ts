import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import { maskDisplayName } from '../shared/bloodCompatibility.ts';
import type {
  AvailabilityStatus,
  BloodGroup,
  BloodRequestRecord,
  LifecycleStatus,
  MaskedDonorRecord,
  MaskedResponseRecord,
  ResponseStatus,
  VerificationStatus,
} from '../shared/types.ts';

export type SqliteDb = Database.Database;

let defaultDbInstance: SqliteDb | null = null;

export function createDatabase(dbPath?: string): SqliteDb {
  const resolvedPath =
    dbPath || process.env.DATABASE_PATH || path.resolve(process.cwd(), 'data', 'redrelay.db');

  if (resolvedPath !== ':memory:') {
    const dir = path.dirname(resolvedPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new Database(resolvedPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  initializeSchema(db);
  return db;
}

export function getDb(): SqliteDb {
  if (!defaultDbInstance) {
    defaultDbInstance = createDatabase();
  }
  return defaultDbInstance;
}

export function initializeSchema(db: SqliteDb): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('requester', 'donor', 'admin')),
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS donors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      blood_group TEXT NOT NULL CHECK (blood_group IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')),
      city TEXT NOT NULL,
      locality TEXT NOT NULL,
      latitude REAL,
      longitude REAL,
      availability_status TEXT NOT NULL DEFAULT 'available' CHECK (availability_status IN ('available', 'unavailable', 'in_recovery')),
      last_donation_date TEXT,
      recovery_until TEXT,
      phone_private TEXT NOT NULL,
      verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
      consent_status INTEGER NOT NULL DEFAULT 1,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS blood_requests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_code TEXT NOT NULL UNIQUE,
      requester_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      patient_name TEXT NOT NULL,
      hospital_name TEXT NOT NULL,
      hospital_location TEXT NOT NULL,
      latitude REAL,
      longitude REAL,
      city TEXT NOT NULL,
      locality TEXT NOT NULL,
      blood_group TEXT NOT NULL CHECK (blood_group IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')),
      units_required INTEGER NOT NULL CHECK (units_required > 0),
      units_committed INTEGER NOT NULL DEFAULT 0 CHECK (units_committed >= 0),
      urgency_deadline TEXT NOT NULL,
      doctor_verification_contact TEXT NOT NULL,
      additional_info TEXT NOT NULL DEFAULT '',
      verification_status TEXT NOT NULL DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected')),
      lifecycle_status TEXT NOT NULL DEFAULT 'open' CHECK (lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit', 'closed', 'expired', 'cancelled')),
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      closed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS responses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id INTEGER NOT NULL REFERENCES blood_requests(id) ON DELETE CASCADE,
      donor_id INTEGER NOT NULL REFERENCES donors(id) ON DELETE CASCADE,
      units_offered INTEGER NOT NULL DEFAULT 1 CHECK (units_offered > 0),
      response_status TEXT NOT NULL DEFAULT 'committed' CHECK (response_status IN ('committed', 'en_route', 'fulfilled', 'withdrawn')),
      eta_minutes INTEGER,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      UNIQUE(request_id, donor_id)
    );

    CREATE TABLE IF NOT EXISTS fulfillment_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id INTEGER NOT NULL REFERENCES blood_requests(id) ON DELETE CASCADE,
      donor_id INTEGER NOT NULL REFERENCES donors(id) ON DELETE CASCADE,
      units_fulfilled INTEGER NOT NULL CHECK (units_fulfilled > 0),
      confirmation_status TEXT NOT NULL DEFAULT 'confirmed' CHECK (confirmation_status IN ('confirmed', 'pending')),
      confirmed_by_user_id INTEGER NOT NULL REFERENCES users(id),
      confirmed_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      request_id INTEGER REFERENCES blood_requests(id) ON DELETE SET NULL,
      channel TEXT NOT NULL DEFAULT 'in_app' CHECK (channel IN ('in_app', 'simulated_sms')),
      delivery_status TEXT NOT NULL DEFAULT 'delivered' CHECK (delivery_status IN ('delivered', 'simulated_sent')),
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS donation_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      donor_id INTEGER NOT NULL REFERENCES donors(id) ON DELETE CASCADE,
      request_id INTEGER REFERENCES blood_requests(id) ON DELETE SET NULL,
      hospital_name TEXT NOT NULL,
      blood_group TEXT NOT NULL CHECK (blood_group IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-')),
      units_donated INTEGER NOT NULL DEFAULT 1,
      donated_at TEXT NOT NULL,
      verified_by_user_id INTEGER REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      actor_name TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      details TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS certificates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      certificate_code TEXT NOT NULL UNIQUE,
      donor_id INTEGER NOT NULL REFERENCES donors(id) ON DELETE CASCADE,
      fulfillment_id INTEGER NOT NULL UNIQUE REFERENCES fulfillment_transactions(id) ON DELETE CASCADE,
      donor_display_name TEXT NOT NULL,
      blood_group TEXT NOT NULL,
      request_code TEXT NOT NULL,
      hospital_name TEXT NOT NULL,
      units_donated INTEGER NOT NULL,
      donation_date TEXT NOT NULL,
      issued_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS hospital_verifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id INTEGER NOT NULL REFERENCES blood_requests(id) ON DELETE CASCADE,
      doctor_contact TEXT NOT NULL,
      verified_by_user_id INTEGER REFERENCES users(id),
      status TEXT NOT NULL CHECK (status IN ('pending', 'verified', 'rejected')),
      notes TEXT NOT NULL DEFAULT '',
      checked_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS relay_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id INTEGER NOT NULL REFERENCES blood_requests(id) ON DELETE CASCADE,
      sender_user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_label TEXT NOT NULL,
      sender_role TEXT NOT NULL,
      message TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS system_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_donors_blood_city ON donors(blood_group, city, availability_status);
    CREATE INDEX IF NOT EXISTS idx_donors_recovery ON donors(recovery_until);
    CREATE INDEX IF NOT EXISTS idx_requests_status ON blood_requests(lifecycle_status, verification_status);
    CREATE INDEX IF NOT EXISTS idx_requests_blood_city ON blood_requests(blood_group, city);
    CREATE INDEX IF NOT EXISTS idx_requests_expires ON blood_requests(expires_at);
    CREATE INDEX IF NOT EXISTS idx_responses_request ON responses(request_id);
    CREATE INDEX IF NOT EXISTS idx_responses_donor ON responses(donor_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
    CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);
  `);

  const responseCols = db.prepare(`PRAGMA table_info(responses)`).all() as Array<{ name: string }>;
  if (!responseCols.some((c) => c.name === 'eta_minutes')) {
    db.exec(`ALTER TABLE responses ADD COLUMN eta_minutes INTEGER`);
  }

  const now = new Date().toISOString();
  const insertCfg = db.prepare(
    `INSERT OR IGNORE INTO system_config (key, value, updated_at) VALUES (?, ?, ?)`
  );
  insertCfg.run('recovery_days', process.env.RECOVERY_DAYS || '90', now);
  insertCfg.run('default_expiration_hours', process.env.DEFAULT_EXPIRATION_HOURS || '24', now);
}

export function getSystemConfigNumber(db: SqliteDb, key: string, fallback: number): number {
  const row = db
    .prepare(`SELECT value FROM system_config WHERE key = ?`)
    .get(key) as { value: string } | undefined;
  if (!row) return fallback;
  const parsed = Number(row.value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

export function writeAuditLog(
  db: SqliteDb,
  params: {
    actorUserId: number | null;
    actorName: string;
    actorRole: string;
    action: string;
    entityType: string;
    entityId: string | number;
    details: string;
    createdAt?: string;
  }
): void {
  db.prepare(
    `INSERT INTO audit_logs (actor_user_id, actor_name, actor_role, action, entity_type, entity_id, details, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    params.actorUserId,
    params.actorName,
    params.actorRole,
    params.action,
    params.entityType,
    String(params.entityId),
    params.details,
    params.createdAt || new Date().toISOString()
  );
}

export function restoreExpiredRecoveries(db: SqliteDb, nowDate: Date = new Date()): number {
  const nowIso = nowDate.toISOString();
  const result = db
    .prepare(
      `UPDATE donors
       SET availability_status = 'available', recovery_until = NULL
       WHERE availability_status = 'in_recovery'
         AND recovery_until IS NOT NULL
         AND recovery_until <= ?`
    )
    .run(nowIso);
  return result.changes;
}

export function runExpirationSweep(
  db: SqliteDb,
  nowDate: Date = new Date()
): { expiredIds: number[] } {
  const nowIso = nowDate.toISOString();
  const candidates = db
    .prepare(
      `SELECT id, request_code
       FROM blood_requests
       WHERE lifecycle_status IN ('open', 'donors_responded', 'fulfilled_in_transit')
         AND expires_at <= ?`
    )
    .all(nowIso) as { id: number; request_code: string }[];

  if (candidates.length === 0) {
    return { expiredIds: [] };
  }

  const updateStmt = db.prepare(
    `UPDATE blood_requests
     SET lifecycle_status = 'expired', closed_at = COALESCE(closed_at, ?)
     WHERE id = ?`
  );

  const tx = db.transaction(() => {
    for (const req of candidates) {
      updateStmt.run(nowIso, req.id);
      writeAuditLog(db, {
        actorUserId: null,
        actorName: 'System Expiration Sweep',
        actorRole: 'system',
        action: 'REQUEST_EXPIRED',
        entityType: 'blood_request',
        entityId: req.id,
        details: `Request ${req.request_code} reached expiration timestamp and was removed from active broadcasts.`,
        createdAt: nowIso,
      });
    }
  });

  tx();
  return { expiredIds: candidates.map((c) => c.id) };
}

export function mapMaskedDonorRow(
  row: {
    id: number;
    user_name: string;
    blood_group: BloodGroup;
    city: string;
    locality: string;
    latitude: number | null;
    longitude: number | null;
    consent_status: number;
    availability_status: AvailabilityStatus;
    last_donation_date: string | null;
    recovery_until: string | null;
    verification_status: VerificationStatus;
    is_demo: number;
    created_at: string;
  },
  nowDate: Date = new Date()
): MaskedDonorRecord {
  const inRecovery =
    row.recovery_until !== null && new Date(row.recovery_until).getTime() > nowDate.getTime();
  const effectiveAvailability: AvailabilityStatus = inRecovery
    ? 'in_recovery'
    : row.availability_status;

  return {
    id: row.id,
    donorInitials: maskDisplayName(row.user_name),
    bloodGroup: row.blood_group,
    city: row.city,
    locality: row.locality,
    latitude: row.consent_status ? row.latitude : null,
    longitude: row.consent_status ? row.longitude : null,
    consentStatus: Boolean(row.consent_status),
    availabilityStatus: row.availability_status,
    effectiveAvailability,
    lastDonationDate: row.last_donation_date,
    recoveryUntil: row.recovery_until,
    verificationStatus: row.verification_status,
    distanceKm: null,
    isDemo: Boolean(row.is_demo),
    createdAt: row.created_at,
  };
}

export function getAllMaskedDonors(db: SqliteDb, nowDate: Date = new Date()): MaskedDonorRecord[] {
  restoreExpiredRecoveries(db, nowDate);
  const rows = db
    .prepare(
      `SELECT d.id, u.name AS user_name, d.blood_group, d.city, d.locality,
              d.latitude, d.longitude, d.consent_status, d.availability_status,
              d.last_donation_date, d.recovery_until, d.verification_status,
              d.is_demo, d.created_at
       FROM donors d
       JOIN users u ON u.id = d.user_id`
    )
    .all() as Array<{
    id: number;
    user_name: string;
    blood_group: BloodGroup;
    city: string;
    locality: string;
    latitude: number | null;
    longitude: number | null;
    consent_status: number;
    availability_status: AvailabilityStatus;
    last_donation_date: string | null;
    recovery_until: string | null;
    verification_status: VerificationStatus;
    is_demo: number;
    created_at: string;
  }>;

  return rows.map((row) => mapMaskedDonorRow(row, nowDate));
}

export function mapBloodRequestRow(row: {
  id: number;
  request_code: string;
  requester_id: number;
  requester_name: string;
  patient_name: string;
  hospital_name: string;
  hospital_location: string;
  latitude: number | null;
  longitude: number | null;
  city: string;
  locality: string;
  blood_group: BloodGroup;
  units_required: number;
  units_committed: number;
  urgency_deadline: string;
  doctor_verification_contact: string;
  additional_info: string;
  verification_status: VerificationStatus;
  lifecycle_status: LifecycleStatus;
  is_demo: number;
  created_at: string;
  expires_at: string;
  closed_at: string | null;
}): BloodRequestRecord {
  return {
    id: row.id,
    requestCode: row.request_code,
    requesterId: row.requester_id,
    requesterName: row.requester_name,
    patientName: row.patient_name,
    hospitalName: row.hospital_name,
    hospitalLocation: row.hospital_location,
    latitude: row.latitude,
    longitude: row.longitude,
    city: row.city,
    locality: row.locality,
    bloodGroup: row.blood_group,
    unitsRequired: row.units_required,
    unitsCommitted: row.units_committed,
    urgencyDeadline: row.urgency_deadline,
    doctorVerificationContact: row.doctor_verification_contact,
    additionalInfo: row.additional_info,
    verificationStatus: row.verification_status,
    lifecycleStatus: row.lifecycle_status,
    isDemo: Boolean(row.is_demo),
    createdAt: row.created_at,
    expiresAt: row.expires_at,
    closedAt: row.closed_at,
  };
}

export function mapMaskedResponseRow(row: {
  id: number;
  request_id: number;
  donor_id: number;
  donor_name: string;
  donor_blood_group: BloodGroup;
  donor_city: string;
  donor_locality: string;
  units_offered: number;
  response_status: ResponseStatus;
  eta_minutes?: number | null;
  created_at: string;
  updated_at: string;
}): MaskedResponseRecord {
  return {
    id: row.id,
    requestId: row.request_id,
    donorId: row.donor_id,
    donorInitials: maskDisplayName(row.donor_name),
    donorBloodGroup: row.donor_blood_group,
    donorCity: row.donor_city,
    donorLocality: row.donor_locality,
    unitsOffered: row.units_offered,
    responseStatus: row.response_status,
    etaMinutes: row.eta_minutes ?? null,
    distanceKm: null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}
