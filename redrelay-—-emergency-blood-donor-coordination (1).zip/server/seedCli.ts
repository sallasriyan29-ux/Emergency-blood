import 'dotenv/config';
import { createDatabase } from './db.ts';
import { seedDatabase } from './seed.ts';

const db = createDatabase();
const forceReset = process.argv.includes('--reset');
const result = seedDatabase(db, { forceReset });
console.log(
  `RedRelay seed complete (seeded=${result.seeded}, donors=${result.donorCount}, activeRequests=${result.requestCount}).`
);
db.close();
