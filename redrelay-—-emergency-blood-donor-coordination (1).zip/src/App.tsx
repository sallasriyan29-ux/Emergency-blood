import { AnimatePresence, motion, MotionConfig } from 'motion/react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { AppShell } from './components/AppShell.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { AdminDashboardPage } from './pages/AdminDashboardPage.tsx';
import { AuthPage } from './pages/AuthPage.tsx';
import { BroadcastFeedPage } from './pages/BroadcastFeedPage.tsx';
import { CreateSosPage } from './pages/CreateSosPage.tsx';
import { DonorPortalPage } from './pages/DonorPortalPage.tsx';
import { FindDonorsPage } from './pages/FindDonorsPage.tsx';
import { MapViewPage } from './pages/MapViewPage.tsx';
import { RequestDetailPage } from './pages/RequestDetailPage.tsx';

export default function App() {
  const location = useLocation();

  return (
    <MotionConfig reducedMotion="user">
      <ErrorBoundary>
        <AppShell>
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            >
              <Routes location={location}>
                <Route path="/" element={<BroadcastFeedPage />} />
                <Route path="/donors" element={<FindDonorsPage />} />
                <Route path="/sos/new" element={<CreateSosPage />} />
                <Route path="/requests/:id" element={<RequestDetailPage />} />
                <Route path="/donor" element={<DonorPortalPage />} />
                <Route path="/map" element={<MapViewPage />} />
                <Route path="/admin" element={<AdminDashboardPage />} />
                <Route path="/auth" element={<AuthPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </AppShell>
      </ErrorBoundary>
    </MotionConfig>
  );
}
