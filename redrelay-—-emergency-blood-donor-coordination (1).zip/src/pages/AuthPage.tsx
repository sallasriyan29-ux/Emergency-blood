import { Lock } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { type FormEvent, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import { BLOOD_GROUPS, type BloodGroup } from '../../shared/types.ts';
import { EcgPulseTrace } from '../components/MotionPrimitives.tsx';
import { useAuth } from '../context/AuthContext.tsx';

export function AuthPage() {
  const { login, register } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [mode, setMode] = useState<'login' | 'register'>(
    searchParams.get('mode') === 'register' ? 'register' : 'login'
  );
  const [role, setRole] = useState<'requester' | 'donor'>(
    searchParams.get('role') === 'donor' ? 'donor' : 'requester'
  );

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Donor-specific registration fields
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [city, setCity] = useState('Hyderabad');
  const [locality, setLocality] = useState('Jubilee Hills');
  const [phone, setPhone] = useState('');
  const [consentLocation, setConsentLocation] = useState(true);

  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === 'login') {
        const loggedUser = await login(email, password);
        navigate(loggedUser.role === 'donor' ? '/donor' : loggedUser.role === 'admin' ? '/admin' : '/');
      } else {
        const createdUser = await register({
          name,
          email,
          password,
          role,
          ...(role === 'donor'
            ? { bloodGroup, city, locality, phone, consentLocation }
            : {}),
        });
        navigate(createdUser.role === 'donor' ? '/donor' : '/');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="max-w-lg mx-auto px-4 sm:px-6 py-10">
      <motion.div
        initial={{ opacity: 0, y: 12, scale: 0.99 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        className="bg-white border border-slate-200 rounded-xl p-6 space-y-6"
      >
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <motion.img
                src="/assets/aistudio/Red_Blood_Drop_Care_Logo_51326305.png"
                alt="LifeLine Logo"
                initial={{ scale: 0.85, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                className="h-10 w-auto object-contain shrink-0"
              />
              <span className="font-display text-base font-extrabold text-[#0F172A]">
                LifeLine
              </span>
            </div>
            <EcgPulseTrace label="" widthClass="w-24" />
          </div>
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            {mode === 'login' ? 'Sign In to LifeLine' : 'Create LifeLine Account'}
          </h1>
          <p className="text-xs text-slate-600">
            Secure session authentication with backend role-based access control.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
          {(
            [
              ['login', 'Sign In'],
              ['register', 'Register'],
            ] as const
          ).map(([key, label]) => {
            const active = mode === key;
            return (
              <motion.button
                key={key}
                type="button"
                whileTap={{ scale: 0.97 }}
                onClick={() => {
                  setMode(key);
                  setError(null);
                }}
                className={`relative py-2 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  active ? 'text-[#0F172A]' : 'text-slate-600 hover:text-[#0F172A]'
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="auth-mode-bg"
                    transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                    className="absolute inset-0 bg-white rounded-md shadow-sm"
                  />
                )}
                <span className="relative z-10">{label}</span>
              </motion.button>
            );
          })}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <AnimatePresence initial={false}>
            {mode === 'register' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-4 overflow-hidden"
              >
                <div>
                  <span className="block text-xs font-semibold text-[#0F172A] mb-1.5">
                    Account Role
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        ['requester', 'Patient / Requester'],
                        ['donor', 'Voluntary Donor'],
                      ] as const
                    ).map(([roleKey, roleLabel]) => {
                      const active = role === roleKey;
                      return (
                        <motion.button
                          key={roleKey}
                          type="button"
                          whileTap={{ scale: 0.97 }}
                          onClick={() => setRole(roleKey)}
                          className={`relative py-2 px-3 rounded-lg border text-xs font-semibold transition-colors cursor-pointer ${
                            active
                              ? 'border-[#B91C1C] bg-red-50 text-[#B91C1C]'
                              : 'border-slate-200 text-slate-600 hover:border-slate-300'
                          }`}
                        >
                          {roleLabel}
                        </motion.button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label htmlFor="auth-name" className="block text-xs font-semibold text-[#0F172A] mb-1">
                    Full Name
                  </label>
                  <input
                    id="auth-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Your full name"
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div>
            <label htmlFor="auth-email" className="block text-xs font-semibold text-[#0F172A] mb-1">
              Email Address
            </label>
            <input
              id="auth-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <div>
            <label htmlFor="auth-password" className="block text-xs font-semibold text-[#0F172A] mb-1">
              Password
            </label>
            <input
              id="auth-password"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
              className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
            />
          </div>

          <AnimatePresence initial={false}>
            {mode === 'register' && role === 'donor' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
                className="pt-2 border-t border-slate-100 space-y-3 overflow-hidden"
              >
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="reg-bg" className="block text-xs font-semibold text-[#0F172A] mb-1">
                      Blood Group
                    </label>
                    <select
                      id="reg-bg"
                      value={bloodGroup}
                      onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
                      className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm font-semibold"
                    >
                      {BLOOD_GROUPS.map((bg) => (
                        <option key={bg} value={bg}>
                          {bg}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="reg-city" className="block text-xs font-semibold text-[#0F172A] mb-1">
                      City
                    </label>
                    <input
                      id="reg-city"
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="reg-loc" className="block text-xs font-semibold text-[#0F172A] mb-1">
                    Locality
                  </label>
                  <select
                    id="reg-loc"
                    value={locality}
                    onChange={(e) => setLocality(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                  >
                    {HYDERABAD_LOCALITIES.map((l) => (
                      <option key={l.locality} value={l.locality}>
                        {l.locality}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="reg-phone" className="block text-xs font-semibold text-[#0F172A] mb-1">
                    Private Contact Phone (Masked from Public Feeds)
                  </label>
                  <input
                    id="reg-phone"
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91-98765-43210"
                    className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                  />
                  <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                    <Lock className="w-3 h-3" />
                    Stored privately; public feeds only show initials and blood group.
                  </p>
                </div>

                <label className="flex items-center gap-2 text-xs text-slate-700">
                  <input
                    type="checkbox"
                    checked={consentLocation}
                    onChange={(e) => setConsentLocation(e.target.checked)}
                  />
                  Consent to locality-level proximity matching
                </label>
              </motion.div>
            )}
          </AnimatePresence>

          <AnimatePresence>
            {error && (
              <motion.p
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="text-xs text-[#B91C1C] font-medium"
              >
                {error}
              </motion.p>
            )}
          </AnimatePresence>

          <motion.button
            type="submit"
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.97 }}
            disabled={submitting}
            className="w-full py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors cursor-pointer"
          >
            {submitting
              ? 'Please wait...'
              : mode === 'login'
              ? 'Sign In'
              : role === 'donor'
              ? 'Register as Voluntary Donor'
              : 'Create Requester Account'}
          </motion.button>
        </form>
      </motion.div>
    </main>
  );
}
