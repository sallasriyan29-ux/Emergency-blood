import {
  Activity,
  AlertCircle,
  ArrowRight,
  Bell,
  Building2,
  CalendarPlus,
  Droplets,
  Heart,
  HeartHandshake,
  MapPin,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Users,
  Zap,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { isCompatibleDonor } from '../../shared/bloodCompatibility.ts';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import {
  BLOOD_GROUPS,
  type BloodGroup,
  type BloodGroupSupplySummary,
  type BloodRequestRecord,
} from '../../shared/types.ts';
import { BloodSupplyBoard } from '../components/BloodSupplyBoard.tsx';
import { CompatibilityModal } from '../components/CompatibilityModal.tsx';
import {
  AnimatedCounter,
  BloodDropLoader,
  EcgPulseTrace,
  HighlightedTagline,
  RadarScanRing,
  RelayFlowLine,
} from '../components/MotionPrimitives.tsx';
import { RequestCard } from '../components/RequestCard.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

function formatRelativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(1, Math.round(diffMs / 60000));
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export function BroadcastFeedPage() {
  const { user, socket } = useAuth();
  const navigate = useNavigate();

  const [scope, setScope] = useState<'active' | 'history' | 'mine'>('active');
  const [bloodGroup, setBloodGroup] = useState<string>('');
  const [locality, setLocality] = useState<string>('');
  const [urgency, setUrgency] = useState<string>('');
  const [lifecycleStatus, setLifecycleStatus] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [compatibleOnly, setCompatibleOnly] = useState(false);

  // "Find Blood Nearby" quick bar state
  const [quickBloodGroup, setQuickBloodGroup] = useState<string>('');
  const [quickLocality, setQuickLocality] = useState<string>('');

  const [requests, setRequests] = useState<BloodRequestRecord[]>([]);
  const [supplyGroups, setSupplyGroups] = useState<BloodGroupSupplySummary[]>([]);
  const [platformStats, setPlatformStats] = useState({
    totalRegisteredDonors: 0,
    totalAvailableDonors: 0,
    totalVerifiedDonors: 0,
    totalConfirmedDonations: 0,
    totalPartnerHospitals: 0,
    totalActiveRequests: 0,
    totalClosedRequests: 0,
  });
  const [showSupplyBoard, setShowSupplyBoard] = useState(false);
  const [showCompatModal, setShowCompatModal] = useState(false);

  const [donorBloodGroup, setDonorBloodGroup] = useState<BloodGroup | null>(null);
  const [respondedRequestIds, setRespondedRequestIds] = useState<Set<number>>(new Set());
  const [respondingId, setRespondingId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [awarenessImgFailed, setAwarenessImgFailed] = useState(false);

  const loadFeed = useCallback(
    async (manual = false) => {
      setError(null);
      if (manual) setRefreshing(true);
      try {
        const res = await api.listRequests({
          scope,
          bloodGroup: bloodGroup || undefined,
          compatibleFor:
            compatibleOnly && donorBloodGroup ? donorBloodGroup : undefined,
          q: searchQuery.trim() || undefined,
          locality: locality || undefined,
          urgency: urgency || undefined,
          lifecycleStatus: lifecycleStatus || undefined,
        });
        setRequests(res.requests);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load emergency feed.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [
      scope,
      bloodGroup,
      compatibleOnly,
      donorBloodGroup,
      searchQuery,
      locality,
      urgency,
      lifecycleStatus,
    ]
  );

  const loadSupplySummary = useCallback(async () => {
    try {
      const res = await api.getDonorSupplySummary();
      setSupplyGroups(res.groups);
      setPlatformStats({
        totalRegisteredDonors: res.totalRegisteredDonors,
        totalAvailableDonors: res.totalAvailableDonors,
        totalVerifiedDonors: res.totalVerifiedDonors,
        totalConfirmedDonations: res.totalConfirmedDonations,
        totalPartnerHospitals: res.totalPartnerHospitals,
        totalActiveRequests: res.totalActiveRequests,
        totalClosedRequests: res.totalClosedRequests,
      });
    } catch {
      // Keep previous supply snapshot
    }
  }, []);

  const loadDonorContext = useCallback(async () => {
    if (user?.role !== 'donor') {
      setDonorBloodGroup(null);
      setCompatibleOnly(false);
      setRespondedRequestIds(new Set());
      return;
    }
    try {
      const comp = await api.getCompatibleRequestsForDonor();
      setDonorBloodGroup(comp.donorBloodGroup);
      const ids = new Set<number>();
      for (const r of comp.requests) {
        if (r.myResponse) ids.add(r.id);
      }
      setRespondedRequestIds(ids);
    } catch {
      setDonorBloodGroup(null);
    }
  }, [user]);

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      void loadFeed();
    }, 120);
    return () => clearTimeout(timer);
  }, [loadFeed]);

  useEffect(() => {
    void loadDonorContext();
    void loadSupplySummary();
  }, [loadDonorContext, loadSupplySummary]);

  useEffect(() => {
    if (!socket) return;
    const handleEvent = () => {
      void loadFeed();
      void loadDonorContext();
      void loadSupplySummary();
    };
    socket.on('request:created', handleEvent);
    socket.on('request:updated', handleEvent);
    socket.on('request:verified', handleEvent);
    socket.on('request:expired', handleEvent);
    socket.on('response:created', handleEvent);

    return () => {
      socket.off('request:created', handleEvent);
      socket.off('request:updated', handleEvent);
      socket.off('request:verified', handleEvent);
      socket.off('request:expired', handleEvent);
      socket.off('response:created', handleEvent);
    };
  }, [socket, loadFeed, loadDonorContext, loadSupplySummary]);

  const handleQuickRespond = async (requestId: number) => {
    setActionFeedback(null);
    setRespondingId(requestId);
    try {
      const res = await api.respondToRequest(requestId, 1);
      setActionFeedback(
        `Commitment recorded (${res.unitsCommitted}/${res.unitsRequired} units committed). Requester notified with your masked profile.`
      );
      await loadFeed();
      await loadDonorContext();
      await loadSupplySummary();
    } catch (err) {
      setActionFeedback(err instanceof Error ? err.message : 'Unable to submit response.');
    } finally {
      setRespondingId(null);
    }
  };

  const handleNearbySearch = (e: React.FormEvent) => {
    e.preventDefault();
    const qs = new URLSearchParams();
    if (quickBloodGroup) qs.set('bloodGroup', quickBloodGroup);
    if (quickLocality) qs.set('locality', quickLocality);
    navigate(`/donors${qs.toString() ? `?${qs.toString()}` : ''}`);
  };

  const liveTopRequests = useMemo(() => requests.slice(0, 3), [requests]);

  const donorCtaLink = user?.role === 'donor' ? '/donor' : '/auth?mode=register&role=donor';

  return (
    <main className="max-w-[1400px] mx-auto px-4 sm:px-6 py-6 space-y-5">
      {/* Row 1: Twilight Medical Hero Banner + 4 Feature Glass Cards */}
      <motion.section
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0A1432] via-[#132248] to-[#0D1A3B] text-white border border-slate-800/80 shadow-md p-6 sm:p-7"
      >
        <div
          aria-hidden="true"
          className="absolute -right-12 -top-12 w-72 h-72 rounded-full bg-[#DC2626]/20 blur-3xl pointer-events-none"
        />

        <div className="relative z-10 grid grid-cols-1 xl:grid-cols-12 gap-6 items-center">
          {/* Left Hero Copy + Animated Tagline + CTAs */}
          <div className="xl:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-200">
              <ShieldCheck className="w-4 h-4 text-[#F87171]" />
              <span>Hyderabad Voluntary Blood Coordination Network</span>
            </div>

            <div className="space-y-2">
              <h1 className="font-display text-3xl sm:text-4xl lg:text-[42px] font-extrabold tracking-tight leading-[1.08] text-balance">
                Donate Blood, <span className="text-[#F87171]">Save Lives</span>
              </h1>
              <div>
                <HighlightedTagline text="Every drop counts." variant="dark" size="md" />
              </div>
            </div>

            <p className="text-sm sm:text-base text-slate-300 max-w-xl leading-relaxed">
              Connect donors, hospitals, and blood banks in real time. A faster, smarter, and
              privacy-first way to coordinate life-saving blood transfusions.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-1">
              <motion.div whileHover={{ y: -2, scale: 1.02 }} whileTap={{ scale: 0.96 }}>
                <Link
                  to={donorCtaLink}
                  className="redrelay-sos-pulse inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#DC2626] to-[#B91C1C] hover:from-[#EF4444] hover:to-[#DC2626] text-white text-sm font-semibold shadow-md transition-all whitespace-nowrap shrink-0"
                >
                  Donate Now
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </motion.div>

              <motion.div whileHover={{ y: -2, scale: 1.02 }} whileTap={{ scale: 0.96 }}>
                <Link
                  to="/donors"
                  className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/25 text-white text-sm font-semibold transition-all whitespace-nowrap shrink-0"
                >
                  <Search className="w-4 h-4" />
                  Find Blood
                </Link>
              </motion.div>

              <motion.div whileHover={{ y: -2, scale: 1.02 }} whileTap={{ scale: 0.96 }}>
                <Link
                  to="/sos/new"
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white text-[#0F172A] hover:bg-red-50 text-sm font-semibold transition-all whitespace-nowrap shrink-0"
                >
                  <Plus className="w-4 h-4 text-[#B91C1C]" />
                  Post SOS
                </Link>
              </motion.div>
            </div>
          </div>

          {/* Right: Vivid Donor Photo + 2x2 Feature Grid */}
          <div className="xl:col-span-5 space-y-3">
            <div className="group relative aspect-[16/9] rounded-xl overflow-hidden border border-white/20 shadow-lg bg-slate-900">
              {!heroImgFailed ? (
                <img
                  src="/assets/aistudio/image_f00f2a9e.png"
                  alt="Voluntary blood donor holding a red heart during donation"
                  referrerPolicy="no-referrer"
                  onError={() => setHeroImgFailed(true)}
                  className="w-full h-full object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-[#991B1B] to-slate-900 flex items-center justify-center">
                  <HeartHandshake className="w-12 h-12 text-white/40" />
                </div>
              )}
              <div
                aria-hidden="true"
                className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent"
              />
              <span className="absolute bottom-2.5 left-3.5 text-xs font-bold text-white">
                Voluntary Blood Care · Every drop counts.
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                {
                  icon: Zap,
                  title: 'Real-time Availability',
                  desc: 'Live donor readiness',
                },
                {
                  icon: ShieldCheck,
                  title: 'Verified Donors',
                  desc: '90-day safety guarded',
                },
                {
                  icon: Bell,
                  title: 'Instant Alerts',
                  desc: 'Privacy-masked relays',
                },
                {
                  icon: Users,
                  title: 'Voluntary Network',
                  desc: 'Zero-fee coordination',
                },
              ].map((feat, idx) => {
                const Icon = feat.icon;
                return (
                  <motion.div
                    key={feat.title}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      duration: 0.26,
                      delay: 0.08 + idx * 0.05,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-xl bg-white/[0.08] border border-white/15 backdrop-blur-sm"
                  >
                    <div className="w-7 h-7 rounded-lg bg-white/10 flex items-center justify-center shrink-0">
                      <Icon className="w-3.5 h-3.5 text-[#FCA5A5]" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] font-bold text-white truncate">{feat.title}</p>
                      <p className="text-[10px] text-slate-300 truncate">{feat.desc}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      </motion.section>

      {/* Row 2: 4-Column Real Database KPI Row */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          {
            label: 'Registered Donors',
            value: platformStats.totalRegisteredDonors,
            sub: `${platformStats.totalVerifiedDonors} verified`,
            icon: Droplets,
            iconBg: 'bg-red-50 text-[#B91C1C]',
            subColor: 'text-[#16A34A]',
          },
          {
            label: 'Ready Donors Now',
            value: platformStats.totalAvailableDonors,
            sub: 'Eligible today',
            icon: Heart,
            iconBg: 'bg-sky-50 text-sky-600',
            subColor: 'text-[#16A34A]',
          },
          {
            label: 'Partner Hospitals',
            value: platformStats.totalPartnerHospitals,
            sub: 'Active coordinators',
            icon: Building2,
            iconBg: 'bg-indigo-50 text-indigo-600',
            subColor: 'text-slate-500',
          },
          {
            label: 'Ongoing SOS Requests',
            value: platformStats.totalActiveRequests,
            sub: `${platformStats.totalClosedRequests} fulfilled`,
            icon: CalendarPlus,
            iconBg: 'bg-rose-50 text-[#DC2626]',
            subColor: 'text-[#B91C1C]',
          },
        ].map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={kpi.label}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              whileHover={{ y: -2 }}
              transition={{ duration: 0.24, delay: idx * 0.05, ease: [0.16, 1, 0.3, 1] }}
              className="bg-white border border-slate-200/90 rounded-2xl p-4 flex items-center justify-between gap-3 shadow-2xs hover:shadow-md transition-all"
            >
              <div className="flex items-center gap-3.5 min-w-0">
                <div
                  className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${kpi.iconBg}`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="font-mono-tabular text-2xl font-extrabold text-[#0F172A] leading-none">
                    <AnimatedCounter value={kpi.value} />
                  </p>
                  <p className="text-xs font-medium text-slate-500 mt-1 truncate">{kpi.label}</p>
                </div>
              </div>
              <span className={`font-mono-tabular text-[11px] font-semibold shrink-0 ${kpi.subColor}`}>
                {kpi.sub}
              </span>
            </motion.div>
          );
        })}
      </section>

      {/* Row 3: 2-Column Action Strip (Find Blood Nearby + Become a Blood Donor) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        {/* Left: Find Blood Nearby */}
        <form
          onSubmit={handleNearbySearch}
          className="lg:col-span-8 bg-white border border-slate-200/90 rounded-2xl p-5 flex flex-col justify-between gap-4 shadow-2xs"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5 text-[#B91C1C]" />
              </div>
              <div>
                <h2 className="text-base font-bold text-[#0F172A]">Find Blood Nearby</h2>
                <p className="text-xs text-slate-500">
                  Search for verified voluntary donors by blood group and Hyderabad locality.
                </p>
              </div>
            </div>
            <RadarScanRing size={28} tone="red" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
            <div className="sm:col-span-5">
              <label
                htmlFor="nearby-bg"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Blood Group
              </label>
              <select
                id="nearby-bg"
                value={quickBloodGroup}
                onChange={(e) => setQuickBloodGroup(e.target.value)}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-slate-50 text-sm text-[#0F172A]"
              >
                <option value="">All Blood Groups</option>
                {BLOOD_GROUPS.map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-5">
              <label
                htmlFor="nearby-loc"
                className="block text-xs font-semibold text-slate-700 mb-1"
              >
                Location
              </label>
              <select
                id="nearby-loc"
                value={quickLocality}
                onChange={(e) => setQuickLocality(e.target.value)}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-slate-50 text-sm text-[#0F172A]"
              >
                <option value="">All Hyderabad Areas</option>
                {HYDERABAD_LOCALITIES.map((loc) => (
                  <option key={loc.locality} value={loc.locality}>
                    {loc.locality}
                  </option>
                ))}
              </select>
            </div>

            <div className="sm:col-span-2">
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                className="w-full h-10 px-4 rounded-xl bg-gradient-to-r from-[#DC2626] to-[#B91C1C] hover:from-[#EF4444] hover:to-[#DC2626] text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
              >
                <Search className="w-3.5 h-3.5" />
                Search
              </motion.button>
            </div>
          </div>
        </form>

        {/* Right: Become a Blood Donor */}
        <div className="lg:col-span-4 bg-white border border-slate-200/90 rounded-2xl p-5 flex flex-col justify-between gap-4 shadow-2xs">
          <div className="flex items-start gap-3">
            <img
              src="/assets/aistudio/Red_Blood_Drop_Care_Logo_51326305.png"
              alt="LifeLine Donor Care"
              className="w-12 h-12 object-contain shrink-0"
            />
            <div>
              <h2 className="text-base font-bold text-[#0F172A]">Become a Blood Donor</h2>
              <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                Register as a voluntary donor and receive privacy-masked alerts when someone nearby
                needs help.
              </p>
            </div>
          </div>

          <Link
            to={donorCtaLink}
            className="w-full py-2.5 px-4 rounded-xl border border-red-200 bg-red-50/40 hover:bg-red-50 text-[#B91C1C] text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
          >
            {user?.role === 'donor' ? 'Open Donor Portal' : 'Register Now'}
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </section>

      {/* Row 4: 3-Column Bento Overview (Live Requests + Donation Awareness Banner + Blood Need Heatmap) */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-stretch">
        {/* Card 1: Live Blood Requests Snapshot */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 flex flex-col justify-between gap-3 shadow-2xs">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#B91C1C]" />
              <h2 className="text-sm font-bold text-[#0F172A]">Live Blood Requests</h2>
            </div>
            <a
              href="#emergency-feed"
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#B91C1C] hover:underline whitespace-nowrap"
            >
              View All
              <ArrowRight className="w-3 h-3" />
            </a>
          </div>

          {liveTopRequests.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">
              No active SOS requests in the current filter view.
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {liveTopRequests.map((req) => {
                const remaining = Math.max(0, req.unitsRequired - req.unitsCommitted);
                const hrsLeft =
                  (new Date(req.urgencyDeadline).getTime() - Date.now()) / (60 * 60 * 1000);
                const priorityLabel =
                  hrsLeft <= 4 ? 'Critical' : hrsLeft <= 12 ? 'Urgent' : 'Active';
                const priorityColor =
                  hrsLeft <= 4
                    ? 'text-[#B91C1C]'
                    : hrsLeft <= 12
                    ? 'text-amber-700'
                    : 'text-[#16A34A]';

                return (
                  <Link
                    key={req.id}
                    to={`/requests/${req.id}`}
                    className="py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50/80 -mx-2 px-2 rounded-xl transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-10 h-10 rounded-xl bg-red-50 text-[#B91C1C] font-display text-sm font-extrabold flex items-center justify-center shrink-0">
                        {req.bloodGroup}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-[#0F172A] truncate">
                          {remaining || req.unitsRequired}{' '}
                          {(remaining || req.unitsRequired) === 1 ? 'Unit' : 'Units'} Needed
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          {req.hospitalName} · {req.locality}
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className={`block text-[11px] font-bold ${priorityColor}`}>
                        {priorityLabel}
                      </span>
                      <span className="block font-mono-tabular text-[10px] text-slate-400">
                        {formatRelativeTime(req.createdAt)}
                      </span>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {/* Card 2: Why Blood Donation Matters (Uploaded Awareness Visual + Link) */}
        <div className="bg-white border border-slate-200/90 rounded-2xl overflow-hidden flex flex-col justify-between shadow-2xs">
          <div className="relative w-full aspect-[1200/628] bg-[#B80000] overflow-hidden">
            {!awarenessImgFailed ? (
              <img
                src="/assets/aistudio/image_272e9488.png"
                alt="Why Blood Donation Matters: Save Lives and Improve Health"
                referrerPolicy="no-referrer"
                onError={() => setAwarenessImgFailed(true)}
                className="w-full h-full object-cover object-center"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-white p-4 text-center">
                <Droplets className="w-8 h-8 mb-1 text-white/80" />
                <p className="font-display text-sm font-bold">Why Blood Donation Matters</p>
              </div>
            )}
          </div>
          <div className="p-4 flex items-center justify-between gap-2 border-t border-slate-100">
            <div className="min-w-0">
              <p className="text-xs font-bold text-[#0F172A]">Every drop counts.</p>
              <p className="text-[11px] text-slate-500 truncate">
                Browse {platformStats.totalAvailableDonors} available voluntary donors
              </p>
            </div>
            <Link
              to="/donors"
              className="inline-flex items-center gap-1 text-xs font-bold text-[#B91C1C] hover:underline whitespace-nowrap shrink-0"
            >
              Find Donors
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Card 3: Blood Need Heatmap Preview -> Opens Full Interactive Leaflet Map */}
        <div className="bg-white border border-slate-200/90 rounded-2xl p-5 flex flex-col justify-between gap-3 shadow-2xs">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#B91C1C]" />
              <h2 className="text-sm font-bold text-[#0F172A]">Blood Need Heatmap</h2>
            </div>
            <Link
              to="/map"
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#B91C1C] hover:underline whitespace-nowrap"
            >
              Open Map
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          <Link
            to="/map"
            className="group relative flex-1 min-h-[126px] rounded-xl border border-slate-200 bg-slate-50 overflow-hidden flex items-center justify-center"
          >
            {/* Subtle grid & radial need rings */}
            <div
              aria-hidden="true"
              className="absolute inset-0 opacity-40"
              style={{
                backgroundImage:
                  'linear-gradient(to right, #CBD5E1 1px, transparent 1px), linear-gradient(to bottom, #CBD5E1 1px, transparent 1px)',
                backgroundSize: '24px 24px',
              }}
            />
            <motion.span
              animate={{ scale: [0.9, 1.45, 0.9], opacity: [0.35, 0.12, 0.35] }}
              transition={{ duration: 3.2, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute w-32 h-32 rounded-full bg-[#DC2626]/20"
            />
            <span className="absolute w-20 h-20 rounded-full bg-[#DC2626]/25" />
            <div className="relative z-10 flex flex-col items-center gap-1.5">
              <div className="w-9 h-9 rounded-full bg-[#B91C1C] text-white flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="px-2.5 py-0.5 rounded-md bg-white/90 border border-slate-200 text-[11px] font-semibold text-[#0F172A]">
                {platformStats.totalActiveRequests} Active Zones in Hyderabad
              </span>
            </div>
          </Link>

          <div className="flex items-center justify-between text-[11px] text-slate-600">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626]" />
              High Need
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              Moderate
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#16A34A]" />
              Ready Supply
            </span>
          </div>
        </div>
      </section>

      {/* Row 5: Bottom Impact Summary + ABO/Rh Compatibility Guide Card */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
        <div className="lg:col-span-8 bg-white border border-slate-200/90 rounded-2xl p-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 shadow-2xs">
          <div className="space-y-0.5">
            <h2 className="text-sm font-bold text-[#0F172A]">Our Impact So Far</h2>
            <p className="text-xs text-slate-500">Live database coordination totals across Hyderabad.</p>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <div>
              <p className="font-mono-tabular text-lg font-extrabold text-[#0F172A]">
                <AnimatedCounter value={platformStats.totalRegisteredDonors} />
              </p>
              <p className="text-[11px] text-slate-500">Total Donors</p>
            </div>
            <div>
              <p className="font-mono-tabular text-lg font-extrabold text-[#B91C1C]">
                <AnimatedCounter value={platformStats.totalConfirmedDonations} />
              </p>
              <p className="text-[11px] text-slate-500">Confirmed Donations</p>
            </div>
            <div>
              <p className="font-mono-tabular text-lg font-extrabold text-[#16A34A]">
                <AnimatedCounter value={platformStats.totalClosedRequests} />
              </p>
              <p className="text-[11px] text-slate-500">Fulfilled Requests</p>
            </div>
            <div>
              <p className="font-mono-tabular text-lg font-extrabold text-[#0F172A]">
                <AnimatedCounter value={platformStats.totalPartnerHospitals} />
              </p>
              <p className="text-[11px] text-slate-500">Hospitals Served</p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowCompatModal(true)}
          className="lg:col-span-4 bg-white border border-slate-200/90 hover:border-red-200 hover:shadow-md rounded-2xl p-4 sm:px-5 flex items-center justify-between gap-3 text-left transition-all cursor-pointer shadow-2xs"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
              <Droplets className="w-5 h-5 text-[#B91C1C]" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-bold text-[#0F172A] truncate">
                ABO/Rh Compatibility Guide
              </p>
              <p className="text-xs text-slate-500 truncate">
                Check red-cell rules &amp; donor eligibility
              </p>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-slate-500 shrink-0" />
        </button>
      </section>

      {/* Expandable Live 8-Group Blood Supply Matrix */}
      {supplyGroups.length > 0 && (
        <section className="bg-white border border-slate-200/90 rounded-2xl p-4 space-y-3 shadow-2xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <EcgPulseTrace label="" widthClass="w-20" />
              <h2 className="text-sm font-bold text-[#0F172A]">
                Live Hyderabad Donor Supply vs. Active Unit Demand
              </h2>
              <span className="text-xs text-slate-500 hidden sm:inline">
                · Click any blood group to filter active requests
              </span>
            </div>
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => setShowSupplyBoard((prev) => !prev)}
              className="text-xs font-semibold text-[#B91C1C] hover:underline cursor-pointer"
            >
              {showSupplyBoard ? 'Hide Supply Matrix' : 'Show 8-Group Supply Matrix'}
            </motion.button>
          </div>

          <RelayFlowLine />

          <AnimatePresence>
            {showSupplyBoard && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden pt-1"
              >
                <BloodSupplyBoard
                  groups={supplyGroups}
                  selectedGroup={bloodGroup}
                  onSelectBloodGroup={(bg) =>
                    setBloodGroup((prev) => (prev === bg ? '' : bg))
                  }
                />
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      )}

      {/* Full Interactive Emergency Broadcast Feed & Filters */}
      <section
        id="emergency-feed"
        className="bg-white border border-slate-200/90 rounded-2xl p-4 sm:p-5 space-y-4 shadow-2xs"
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl">
            {(
              [
                ['active', 'Active Broadcasts'],
                ...(user ? ([['mine', 'My Requests']] as const) : []),
                ['history', 'Closed & Expired Archive'],
              ] as const
            ).map(([key, label]) => {
              const active = scope === key;
              return (
                <motion.button
                  key={key}
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setScope(key)}
                  className={`relative px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    active ? 'text-[#0F172A]' : 'text-slate-600 hover:text-[#0F172A]'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="feed-scope-tab-bg"
                      transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                      className="absolute inset-0 bg-white rounded-lg shadow-sm"
                    />
                  )}
                  <span className="relative z-10">{label}</span>
                </motion.button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {user?.role === 'donor' && donorBloodGroup && (
              <motion.button
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setCompatibleOnly((prev) => !prev)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  compatibleOnly
                    ? 'bg-[#B91C1C] text-white border-[#B91C1C]'
                    : 'bg-white text-[#0F172A] border-slate-300 hover:bg-slate-50'
                }`}
              >
                Compatible With Me ({donorBloodGroup})
              </motion.button>
            )}

            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => loadFeed(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-xl cursor-pointer whitespace-nowrap shrink-0"
            >
              <motion.span
                animate={refreshing ? { rotate: 360 } : { rotate: 0 }}
                transition={
                  refreshing ? { duration: 0.7, repeat: Infinity, ease: 'linear' } : undefined
                }
                className="inline-flex"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </motion.span>
              {refreshing ? 'Syncing...' : 'Refresh Feed'}
            </motion.button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          <div>
            <label htmlFor="filter-search" className="block text-xs font-medium text-slate-600 mb-1">
              Search Hospital / Code
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="filter-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Apollo, REQ-HYD..."
                className="w-full h-10 pl-8 pr-3 rounded-xl border border-slate-200 bg-slate-50/70 text-sm text-[#0F172A]"
              />
            </div>
          </div>

          <div>
            <label htmlFor="filter-blood" className="block text-xs font-medium text-slate-600 mb-1">
              Blood Group
            </label>
            <select
              id="filter-blood"
              value={bloodGroup}
              onChange={(e) => setBloodGroup(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-slate-50/70 text-sm text-[#0F172A]"
            >
              <option value="">All Blood Groups</option>
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label
              htmlFor="filter-locality"
              className="block text-xs font-medium text-slate-600 mb-1"
            >
              Hyderabad Locality
            </label>
            <select
              id="filter-locality"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-slate-50/70 text-sm text-[#0F172A]"
            >
              <option value="">All Localities</option>
              {HYDERABAD_LOCALITIES.map((loc) => (
                <option key={loc.locality} value={loc.locality}>
                  {loc.locality}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="filter-urgency" className="block text-xs font-medium text-slate-600 mb-1">
              Urgency Window
            </label>
            <select
              id="filter-urgency"
              value={urgency}
              onChange={(e) => setUrgency(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-slate-50/70 text-sm text-[#0F172A]"
            >
              <option value="">Any Deadline</option>
              <option value="critical">Critical (Within 4 Hours)</option>
              <option value="urgent">Urgent (Within 12 Hours)</option>
            </select>
          </div>

          <div>
            <label htmlFor="filter-status" className="block text-xs font-medium text-slate-600 mb-1">
              Lifecycle Stage
            </label>
            <select
              id="filter-status"
              value={lifecycleStatus}
              onChange={(e) => setLifecycleStatus(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 bg-slate-50/70 text-sm text-[#0F172A]"
            >
              <option value="">All Stages</option>
              <option value="open">Open / Broadcasted</option>
              <option value="donors_responded">Donors Responded</option>
              <option value="fulfilled_in_transit">Fulfilled / In Transit</option>
              <option value="closed">Closed</option>
              <option value="expired">Expired</option>
            </select>
          </div>
        </div>
      </section>

      <AnimatePresence>
        {actionFeedback && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            role="status"
            className="bg-emerald-50 border border-emerald-200 rounded-2xl px-4 py-3 text-sm text-[#0F172A]"
          >
            {actionFeedback}
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="bg-red-50 border border-red-200 rounded-2xl px-4 py-3 flex items-center gap-2 text-sm text-[#B91C1C]"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Feed Cards Grid */}
      {loading ? (
        <div className="space-y-4">
          <BloodDropLoader label="Loading active Hyderabad emergency requests..." />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((n) => (
              <div
                key={n}
                className="border border-slate-200 rounded-2xl p-5 h-56 redrelay-shimmer-skeleton"
              />
            ))}
          </div>
        </div>
      ) : requests.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
          className="bg-white border border-slate-200 rounded-2xl p-10 text-center"
        >
          <Search className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-[#0F172A] mt-3">
            No matching emergency requests found
          </h3>
          <p className="text-sm text-slate-600 mt-1">
            Adjust your search query, blood group, locality, or urgency filters, or submit a new
            emergency SOS.
          </p>
          <div className="mt-4 flex justify-center gap-3">
            <motion.button
              type="button"
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                setSearchQuery('');
                setBloodGroup('');
                setLocality('');
                setUrgency('');
                setLifecycleStatus('');
                setCompatibleOnly(false);
              }}
              className="px-4 py-2 text-xs font-semibold border border-slate-300 rounded-xl text-[#0F172A] hover:bg-slate-50 cursor-pointer"
            >
              Clear Filters
            </motion.button>
            <Link
              to="/sos/new"
              className="px-4 py-2 text-xs font-semibold bg-[#B91C1C] text-white rounded-xl hover:bg-[#991B1B]"
            >
              Post Emergency SOS
            </Link>
          </div>
        </motion.div>
      ) : (
        <div
          key={`${scope}-${bloodGroup}-${locality}-${urgency}-${lifecycleStatus}-${compatibleOnly}-${searchQuery}`}
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          {requests.map((req, idx) => {
            const canQuickRespond =
              user?.role === 'donor' &&
              donorBloodGroup !== null &&
              isCompatibleDonor(req.bloodGroup, donorBloodGroup);

            return (
              <motion.div
                key={req.id}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.08 }}
                transition={{
                  duration: 0.24,
                  delay: Math.min((idx % 4) * 0.05, 0.18),
                  ease: [0.16, 1, 0.3, 1],
                }}
              >
                <RequestCard
                  request={req}
                  canQuickRespond={canQuickRespond}
                  alreadyResponded={respondedRequestIds.has(req.id)}
                  responding={respondingId === req.id}
                  onQuickRespond={handleQuickRespond}
                />
              </motion.div>
            );
          })}
        </div>
      )}

      {/* Clinical Scope Disclaimer */}
      <footer className="bg-white border border-slate-200/90 rounded-2xl p-4 flex items-start gap-3 text-xs text-slate-600 shadow-2xs">
        <ShieldAlert className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <p>
          <strong>Clinical Coordination Notice:</strong> LifeLine is an emergency donor
          coordination platform, not a blood bank or clinical decision-making system. Seeded
          Hyderabad records are demonstration data. Final compatibility, crossmatching, donor
          screening, and transfusion approval must be performed by qualified medical professionals
          and authorized blood banks.
        </p>
      </footer>

      <AnimatePresence>
        {showCompatModal && (
          <CompatibilityModal
            initialGroup={(bloodGroup as BloodGroup) || donorBloodGroup || 'B+'}
            onClose={() => setShowCompatModal(false)}
            onSelectFilterGroup={(group) => setBloodGroup(group)}
          />
        )}
      </AnimatePresence>
    </main>
  );
}
