import { CheckCircle2, Download, RefreshCw, Settings, ShieldAlert, ShieldCheck, XCircle } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { type FormEvent, useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import type { BloodGroupSupplySummary, BloodRequestRecord, MaskedDonorRecord } from '../../shared/types.ts';
import { BloodSupplyBoard } from '../components/BloodSupplyBoard.tsx';
import {
  AnimatedCounter,
  BloodDropLoader,
  EcgPulseTrace,
  RadarScanRing,
  RelayFlowLine,
} from '../components/MotionPrimitives.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

function downloadCsvFile(filename: string, headers: string[], rows: Array<Array<string | number>>) {
  const escapeCell = (val: string | number) => {
    const str = String(val ?? '');
    if (/[",\n\r]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };
  const csvContent = [
    headers.map(escapeCell).join(','),
    ...rows.map((r) => r.map(escapeCell).join(',')),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function AdminDashboardPage() {
  const { user, switchDemoRole } = useAuth();
  const [tab, setTab] = useState<'requests' | 'donors' | 'audit' | 'config'>('requests');
  const [dashboard, setDashboard] = useState<Awaited<ReturnType<typeof api.getAdminDashboard>> | null>(
    null
  );
  const [requests, setRequests] = useState<BloodRequestRecord[]>([]);
  const [donors, setDonors] = useState<MaskedDonorRecord[]>([]);
  const [supplyGroups, setSupplyGroups] = useState<BloodGroupSupplySummary[]>([]);
  const [recoveryDays, setRecoveryDays] = useState('90');
  const [expirationHours, setExpirationHours] = useState('24');

  const [loading, setLoading] = useState(true);
  const [sweeping, setSweeping] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadAdminData = useCallback(async () => {
    if (user?.role !== 'admin') {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [dash, reqRes, donorRes, supplyRes] = await Promise.all([
        api.getAdminDashboard(),
        api.getAdminRequests(),
        api.getAdminDonors(),
        api.getDonorSupplySummary(),
      ]);
      setDashboard(dash);
      setRequests(reqRes.requests);
      setDonors(donorRes.donors);
      setSupplyGroups(supplyRes.groups);
      setRecoveryDays(String(dash.config.recoveryDays));
      setExpirationHours(String(dash.config.defaultExpirationHours));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load admin dashboard.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadAdminData();
  }, [loadAdminData]);

  const handleVerifyRequest = async (id: number, status: 'verified' | 'rejected') => {
    setFeedback(null);
    try {
      const res = await api.verifyRequest(id, status);
      setFeedback(
        status === 'verified'
          ? `Request verified. Simulated SMS dispatch targeted ${res.simulatedSmsTargeted} compatible donor(s).`
          : 'Request marked verification rejected.'
      );
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Verification failed.');
    }
  };

  const handleVerifyDonor = async (id: number, status: 'verified' | 'rejected') => {
    setFeedback(null);
    try {
      await api.adminVerifyEntity({ entityType: 'donor', entityId: id, status });
      setFeedback(`Donor #${id} marked ${status}.`);
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Donor verification update failed.');
    }
  };

  const handleCloseExpired = async () => {
    setFeedback(null);
    setSweeping(true);
    try {
      const res = await api.runExpirationSweep();
      setFeedback(`Expiration sweep completed: ${res.count} request(s) expired.`);
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Expiration sweep failed.');
    } finally {
      setSweeping(false);
    }
  };

  const handleSaveConfig = async (e: FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setError(null);
    try {
      const updated = await api.updateAdminConfig({
        recoveryDays: Number(recoveryDays),
        defaultExpirationHours: Number(expirationHours),
      });
      setFeedback(
        `System configuration saved (recoveryDays=${updated.recoveryDays}, defaultExpirationHours=${updated.defaultExpirationHours}).`
      );
      await loadAdminData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save configuration.');
    }
  };

  if (user?.role !== 'admin') {
    return (
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.22 }}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center gap-2 text-[#B91C1C]">
            <ShieldAlert className="w-5 h-5" />
            <h1 className="font-display text-xl font-bold text-[#0F172A]">
              Administrator Access Required
            </h1>
          </div>
          <p className="text-sm text-slate-600">
            Admin routes are protected by backend role-based access control. Sign in with an
            administrator account or switch to the Demo Admin role to verify requests and audit
            platform activity.
          </p>
          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => switchDemoRole('admin@redrelay.demo')}
            className="px-4 py-2.5 bg-[#0F172A] text-white text-xs font-semibold rounded-lg hover:bg-slate-800 cursor-pointer"
          >
            Switch to Demo Admin
          </motion.button>
        </motion.section>
      </main>
    );
  }

  if (loading || !dashboard) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-4">
        <BloodDropLoader label="Loading verification queue and platform telemetry..." />
        <div className="h-24 border border-slate-200 rounded-xl redrelay-shimmer-skeleton" />
        <div className="h-64 border border-slate-200 rounded-xl redrelay-shimmer-skeleton" />
      </main>
    );
  }

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <RadarScanRing size={34} tone="red" />
            <EcgPulseTrace label="Clinical Verification & Audit" widthClass="w-32" />
          </div>
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            LifeLine Administrator Console
          </h1>
          <p className="text-sm text-slate-600">
            Verify hospital contacts, audit donor registrations, monitor request lifecycles, and
            enforce expiration sweeps.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={() =>
              downloadCsvFile(
                `lifeline-requests-${new Date().toISOString().slice(0, 10)}.csv`,
                [
                  'Request Code',
                  'Hospital',
                  'Locality',
                  'Blood Group',
                  'Units Committed',
                  'Units Required',
                  'Verification Status',
                  'Lifecycle Status',
                  'Urgency Deadline',
                ],
                requests.map((r) => [
                  r.requestCode,
                  r.hospitalName,
                  r.locality,
                  r.bloodGroup,
                  r.unitsCommitted,
                  r.unitsRequired,
                  r.verificationStatus,
                  r.lifecycleStatus,
                  r.urgencyDeadline,
                ])
              )
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-white border border-slate-300 text-[#0F172A] text-xs font-semibold rounded-lg hover:bg-slate-50 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Export Requests CSV
          </motion.button>

          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={() =>
              downloadCsvFile(
                `lifeline-audit-${new Date().toISOString().slice(0, 10)}.csv`,
                ['Timestamp', 'Action', 'Actor', 'Role', 'Entity', 'Details'],
                dashboard.auditLogs.map((l) => [
                  l.createdAt,
                  l.action,
                  l.actorName,
                  l.actorRole,
                  `${l.entityType}:${l.entityId}`,
                  l.details,
                ])
              )
            }
            className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-white border border-slate-300 text-[#0F172A] text-xs font-semibold rounded-lg hover:bg-slate-50 cursor-pointer whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5" />
            Export Audit CSV
          </motion.button>

          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            disabled={sweeping}
            onClick={handleCloseExpired}
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#0F172A] text-white text-xs font-semibold rounded-lg hover:bg-slate-800 cursor-pointer shrink-0 whitespace-nowrap"
          >
            <motion.span
              animate={sweeping ? { rotate: 360 } : { rotate: 0 }}
              transition={sweeping ? { duration: 0.7, repeat: Infinity, ease: 'linear' } : undefined}
              className="inline-flex"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </motion.span>
            {sweeping ? 'Sweeping...' : 'Run Expiration Sweep'}
          </motion.button>
        </div>
      </motion.div>

      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-sm text-[#0F172A]"
          >
            {feedback}
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-[#B91C1C]"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real Summary Metrics */}
      <section className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {[
          {
            label: 'Active Requests',
            valueNode: (
              <p className="font-mono-tabular text-2xl font-bold text-[#0F172A] mt-1">
                <AnimatedCounter value={dashboard.summary.activeRequestsCount} />
              </p>
            ),
          },
          {
            label: 'Pending Verification',
            valueNode: (
              <p className="font-mono-tabular text-2xl font-bold text-amber-700 mt-1">
                <AnimatedCounter value={dashboard.summary.pendingVerificationCount} />
              </p>
            ),
          },
          {
            label: 'Available Donors',
            valueNode: (
              <p className="font-mono-tabular text-2xl font-bold text-[#16A34A] mt-1">
                <AnimatedCounter value={dashboard.summary.availableDonorsCount} /> /{' '}
                <AnimatedCounter value={dashboard.summary.totalDonorsCount} />
              </p>
            ),
          },
          {
            label: 'Donor Responses',
            valueNode: (
              <p className="font-mono-tabular text-2xl font-bold text-[#0F172A] mt-1">
                <AnimatedCounter value={dashboard.summary.totalResponsesCount} />
              </p>
            ),
          },
          {
            label: 'Closed / Expired',
            valueNode: (
              <p className="font-mono-tabular text-2xl font-bold text-slate-700 mt-1">
                <AnimatedCounter value={dashboard.summary.closedRequestsCount} /> /{' '}
                <AnimatedCounter value={dashboard.summary.expiredRequestsCount} />
              </p>
            ),
          },
        ].map((metric, idx) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            whileHover={{ y: -3 }}
            transition={{ duration: 0.22, delay: idx * 0.05, ease: [0.16, 1, 0.3, 1] }}
            className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md hover:border-red-200/70 transition-all duration-200"
          >
            <p className="text-xs text-slate-500">{metric.label}</p>
            {metric.valueNode}
          </motion.div>
        ))}
      </section>

      {/* Live 8-Group Supply Coverage Matrix */}
      {supplyGroups.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm font-bold text-[#0F172A]">
              ABO/Rh Blood Supply vs. Active Demand Coverage
            </h2>
            <span className="text-xs text-slate-500">
              Exact ready donors · Compatible pool · Active unfulfilled units
            </span>
          </div>
          <BloodSupplyBoard groups={supplyGroups} />
        </section>
      )}

      <RelayFlowLine />

      {/* Section Tabs */}
      <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg w-fit">
        {(
          [
            ['requests', `Requests (${requests.length})`],
            ['donors', `Donor Registry (${donors.length})`],
            ['audit', `Audit Logs (${dashboard.auditLogs.length})`],
            ['config', 'Configuration & Users'],
          ] as const
        ).map(([key, label]) => {
          const active = tab === key;
          return (
            <motion.button
              key={key}
              type="button"
              whileTap={{ scale: 0.96 }}
              onClick={() => setTab(key)}
              className={`relative px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                active ? 'text-[#0F172A]' : 'text-slate-600 hover:text-[#0F172A]'
              }`}
            >
              {active && (
                <motion.span
                  layoutId="admin-tab-bg"
                  transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                  className="absolute inset-0 bg-white rounded-md shadow-sm"
                />
              )}
              <span className="relative z-10">{label}</span>
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence mode="wait">
        {tab === 'requests' && (
          <motion.section
            key="tab-requests"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18 }}
            className="bg-white border border-slate-200 rounded-xl overflow-hidden"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                    <th className="py-3 px-4 font-semibold">Code</th>
                    <th className="py-3 px-4 font-semibold">Hospital &amp; Doctor Contact</th>
                    <th className="py-3 px-4 font-semibold">Blood / Units</th>
                    <th className="py-3 px-4 font-semibold">Verification</th>
                    <th className="py-3 px-4 font-semibold">Lifecycle</th>
                    <th className="py-3 px-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {requests.map((r, idx) => (
                    <motion.tr
                      key={r.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: Math.min(idx * 0.025, 0.25) }}
                      className="hover:bg-slate-50/70"
                    >
                      <td className="py-3 px-4 font-mono-tabular font-semibold">
                        <Link to={`/requests/${r.id}`} className="text-[#0F172A] hover:text-[#B91C1C]">
                          {r.requestCode}
                        </Link>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#0F172A]">{r.hospitalName}</div>
                        <div className="text-xs text-slate-500">{r.doctorVerificationContact}</div>
                      </td>
                      <td className="py-3 px-4 font-mono-tabular">
                        <span className="font-bold text-[#B91C1C]">{r.bloodGroup}</span>
                        <span className="text-slate-500 ml-2">
                          {r.unitsCommitted}/{r.unitsRequired}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-xs font-semibold">
                        {r.verificationStatus === 'verified' ? (
                          <span className="inline-flex items-center gap-1 text-[#16A34A]">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                          </span>
                        ) : r.verificationStatus === 'rejected' ? (
                          <span className="inline-flex items-center gap-1 text-[#B91C1C]">
                            <XCircle className="w-3.5 h-3.5" /> Rejected
                          </span>
                        ) : (
                          <span className="text-amber-700">Pending</span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono-tabular text-xs text-slate-700">
                        {r.lifecycleStatus}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                        {r.verificationStatus !== 'verified' && (
                          <motion.button
                            type="button"
                            whileTap={{ scale: 0.94 }}
                            onClick={() => handleVerifyRequest(r.id, 'verified')}
                            className="px-2.5 py-1 bg-[#16A34A] text-white text-xs font-semibold rounded hover:bg-emerald-700 cursor-pointer"
                          >
                            Verify
                          </motion.button>
                        )}
                        {r.verificationStatus === 'pending' && (
                          <motion.button
                            type="button"
                            whileTap={{ scale: 0.94 }}
                            onClick={() => handleVerifyRequest(r.id, 'rejected')}
                            className="px-2.5 py-1 border border-red-200 text-[#B91C1C] text-xs font-semibold rounded hover:bg-red-50 cursor-pointer"
                          >
                            Reject
                          </motion.button>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.section>
        )}

        {tab === 'donors' && (
          <motion.section
            key="tab-donors"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18 }}
            className="bg-white border border-slate-200 rounded-xl overflow-hidden"
          >
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs text-slate-500">
                    <th className="py-3 px-4 font-semibold">Initials (Masked)</th>
                    <th className="py-3 px-4 font-semibold">Group</th>
                    <th className="py-3 px-4 font-semibold">Locality</th>
                    <th className="py-3 px-4 font-semibold">Availability</th>
                    <th className="py-3 px-4 font-semibold">Verification</th>
                    <th className="py-3 px-4 font-semibold text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {donors.map((d, idx) => (
                    <motion.tr
                      key={d.id}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: Math.min(idx * 0.015, 0.25) }}
                      className="hover:bg-slate-50/70"
                    >
                      <td className="py-3 px-4 font-semibold text-[#0F172A]">{d.donorInitials}</td>
                      <td className="py-3 px-4 font-mono-tabular font-bold text-[#B91C1C]">
                        {d.bloodGroup}
                      </td>
                      <td className="py-3 px-4 text-slate-600">
                        {d.locality}, {d.city}
                      </td>
                      <td className="py-3 px-4 font-mono-tabular text-xs">{d.effectiveAvailability}</td>
                      <td className="py-3 px-4 text-xs font-semibold">
                        {d.verificationStatus === 'verified' ? (
                          <span className="text-[#16A34A]">Verified</span>
                        ) : d.verificationStatus === 'rejected' ? (
                          <span className="text-[#B91C1C]">Rejected</span>
                        ) : (
                          <span className="text-amber-700">Pending</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap space-x-2">
                        {d.verificationStatus !== 'verified' && (
                          <motion.button
                            type="button"
                            whileTap={{ scale: 0.94 }}
                            onClick={() => handleVerifyDonor(d.id, 'verified')}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#16A34A] text-white text-xs font-semibold rounded cursor-pointer"
                          >
                            <ShieldCheck className="w-3 h-3" /> Verify
                          </motion.button>
                        )}
                        {d.verificationStatus === 'pending' && (
                          <motion.button
                            type="button"
                            whileTap={{ scale: 0.94 }}
                            onClick={() => handleVerifyDonor(d.id, 'rejected')}
                            className="px-2.5 py-1 border border-red-200 text-[#B91C1C] text-xs font-semibold rounded cursor-pointer"
                          >
                            Reject
                          </motion.button>
                        )}
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.section>
        )}

        {tab === 'audit' && (
          <motion.section
            key="tab-audit"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18 }}
            className="bg-white border border-slate-200 rounded-xl p-5 divide-y divide-slate-100 text-xs"
          >
            {dashboard.auditLogs.map((log, idx) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, x: -4 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: Math.min(idx * 0.015, 0.25) }}
                className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <span className="font-mono-tabular font-bold text-[#0F172A]">{log.action}</span>
                  <span aria-hidden="true"> · </span>
                  <span className="text-slate-700">{log.details}</span>
                </div>
                <div className="font-mono-tabular text-slate-500 shrink-0">
                  {log.actorName} ({log.actorRole}) · {new Date(log.createdAt).toLocaleString()}
                </div>
              </motion.div>
            ))}
          </motion.section>
        )}

        {tab === 'config' && (
          <motion.div
            key="tab-config"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.18 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6"
          >
            <form
              onSubmit={handleSaveConfig}
              className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
            >
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-[#0F172A]" />
                <h2 className="text-base font-bold text-[#0F172A]">Platform Policy Configuration</h2>
              </div>

              <div>
                <label htmlFor="cfg-recovery" className="block text-xs font-semibold text-[#0F172A] mb-1">
                  Post-Donation Recovery Restriction (Days)
                </label>
                <input
                  id="cfg-recovery"
                  type="number"
                  min={1}
                  max={365}
                  value={recoveryDays}
                  onChange={(e) => setRecoveryDays(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono-tabular"
                />
              </div>

              <div>
                <label htmlFor="cfg-exp" className="block text-xs font-semibold text-[#0F172A] mb-1">
                  Default SOS Expiration Window (Hours)
                </label>
                <input
                  id="cfg-exp"
                  type="number"
                  min={1}
                  max={168}
                  value={expirationHours}
                  onChange={(e) => setExpirationHours(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm font-mono-tabular"
                />
              </div>

              <motion.button
                type="submit"
                whileTap={{ scale: 0.96 }}
                className="px-4 py-2 bg-[#B91C1C] text-white text-xs font-semibold rounded-lg hover:bg-[#991B1B] cursor-pointer"
              >
                Save Policy Settings
              </motion.button>
            </form>

            <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-3">
              <h2 className="text-base font-bold text-[#0F172A]">
                Registered Accounts ({dashboard.users.length})
              </h2>
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 text-xs">
                {dashboard.users.map((u) => (
                  <div key={u.id} className="py-2 flex items-center justify-between gap-2">
                    <div>
                      <span className="font-semibold text-[#0F172A]">{u.name}</span>
                      <span className="text-slate-500 ml-2">{u.email}</span>
                    </div>
                    <span className="font-mono-tabular font-semibold uppercase text-slate-600">
                      {u.role}
                    </span>
                  </div>
                ))}
              </div>
            </section>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
