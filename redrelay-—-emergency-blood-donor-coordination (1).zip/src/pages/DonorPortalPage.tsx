import {
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  Droplets,
  HeartHandshake,
  QrCode,
  ShieldCheck,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { type FormEvent, useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import { BLOOD_GROUPS, type BloodGroup, type CertificateRecord, type DonorPrivateProfile } from '../../shared/types.ts';
import { CertificateModal } from '../components/CertificateModal.tsx';
import { CompatibilityModal } from '../components/CompatibilityModal.tsx';
import { type CheckInPassData, DonorCheckInPassModal } from '../components/DonorCheckInPassModal.tsx';
import {
  AnimatedCounter,
  BloodDropLoader,
  EcgPulseTrace,
  HighlightedTagline,
  LiveBeaconDot,
  RelayFlowLine,
} from '../components/MotionPrimitives.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

export function DonorPortalPage() {
  const { user, refreshUser, switchDemoRole } = useAuth();
  const [profile, setProfile] = useState<DonorPrivateProfile | null>(null);
  const [compatibleRequests, setCompatibleRequests] = useState<
    Awaited<ReturnType<typeof api.getCompatibleRequestsForDonor>>['requests']
  >([]);
  const [history, setHistory] = useState<Awaited<ReturnType<typeof api.getDonorHistory>> | null>(
    null
  );
  const [selectedCert, setSelectedCert] = useState<CertificateRecord | null>(null);
  const [selectedPass, setSelectedPass] = useState<CheckInPassData | null>(null);
  const [showCompatModal, setShowCompatModal] = useState(false);
  const [etaDrafts, setEtaDrafts] = useState<Record<number, number>>({});

  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Donor registration form for existing requester accounts wanting to become donors
  const [regBloodGroup, setRegBloodGroup] = useState<BloodGroup>('O+');
  const [regCity, setRegCity] = useState('Hyderabad');
  const [regLocality, setRegLocality] = useState('Jubilee Hills');
  const [regPhone, setRegPhone] = useState('');
  const [regConsent, setRegConsent] = useState(true);

  const loadDonorData = useCallback(async () => {
    if (user?.role !== 'donor') {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [profRes, compRes, histRes] = await Promise.all([
        api.getDonorProfile(),
        api.getCompatibleRequestsForDonor(),
        api.getDonorHistory(),
      ]);
      setProfile(profRes.profile);
      setCompatibleRequests(compRes.requests);
      setHistory(histRes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load donor portal.');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadDonorData();
  }, [loadDonorData]);

  const handleToggleAvailability = async (nextStatus: 'available' | 'unavailable') => {
    setFeedback(null);
    setError(null);
    try {
      await api.updateDonorAvailability({ availabilityStatus: nextStatus });
      setFeedback(`Donor availability updated to ${nextStatus}.`);
      await loadDonorData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update availability.');
    }
  };

  const handleUpdateLocality = async (locality: string) => {
    setFeedback(null);
    setError(null);
    try {
      await api.updateDonorAvailability({ locality });
      setFeedback(`Locality updated to ${locality}.`);
      await loadDonorData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update locality.');
    }
  };

  const handleRespond = async (requestId: number) => {
    setFeedback(null);
    setError(null);
    try {
      const res = await api.respondToRequest(requestId, 1);
      setFeedback(
        `Commitment saved (${res.unitsCommitted}/${res.unitsRequired} Units Committed). Coordinate arrival via the masked relay.`
      );
      await loadDonorData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to commit donation.');
    }
  };

  const handleUpdateResponse = async (
    responseId: number,
    status: 'en_route' | 'withdrawn',
    etaMinutes?: number
  ) => {
    setFeedback(null);
    setError(null);
    try {
      await api.updateResponseStatus(responseId, status, etaMinutes);
      setFeedback(
        status === 'en_route'
          ? `Updated your response status to En Route${etaMinutes ? ` (ETA ~${etaMinutes} min)` : ''}.`
          : 'Commitment withdrawn and unit re-opened for matching donors.'
      );
      await loadDonorData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update commitment.');
    }
  };

  const handleRegisterDonor = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      await api.registerDonorProfile({
        bloodGroup: regBloodGroup,
        city: regCity,
        locality: regLocality,
        phone: regPhone,
        consentLocation: regConsent,
      });
      await refreshUser();
      await loadDonorData();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Donor registration failed.');
    }
  };

  if (!user) {
    return (
      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <EcgPulseTrace label="Voluntary Donor Network" widthClass="w-32" />
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            Voluntary Donor Portal
          </h1>
          <p className="text-sm text-slate-600">
            Register as a voluntary donor with privacy-protected phone masking, manage your
            availability and 90-day donation interval, respond to compatible SOS requests, and
            access appreciation certificates.
          </p>
          <div className="flex flex-wrap gap-3">
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.96 }}>
              <Link
                to="/auth?mode=register&role=donor"
                className="inline-flex px-4 py-2.5 bg-[#B91C1C] text-white text-sm font-semibold rounded-lg hover:bg-[#991B1B]"
              >
                Register as Voluntary Donor
              </Link>
            </motion.div>
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => switchDemoRole('donor.oplus@redrelay.demo')}
              className="px-4 py-2.5 border border-slate-300 text-sm font-semibold text-[#0F172A] rounded-lg hover:bg-slate-50 cursor-pointer"
            >
              Try Demo O+ Donor
            </motion.button>
          </div>
        </motion.section>
      </main>
    );
  }

  if (user.role !== 'donor') {
    return (
      <main className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            Become a Voluntary Donor
          </h1>
          <p className="text-sm text-slate-600">
            You are currently signed in as <strong>{user.name}</strong> ({user.role}). Switch to a
            Demo Donor role above or complete your donor profile below.
          </p>

          {user.role === 'requester' && (
            <form onSubmit={handleRegisterDonor} className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                  Blood Group
                </label>
                <select
                  value={regBloodGroup}
                  onChange={(e) => setRegBloodGroup(e.target.value as BloodGroup)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                >
                  {BLOOD_GROUPS.map((bg) => (
                    <option key={bg} value={bg}>
                      {bg}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">City</label>
                <input
                  type="text"
                  value={regCity}
                  onChange={(e) => setRegCity(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">Locality</label>
                <select
                  value={regLocality}
                  onChange={(e) => setRegLocality(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm"
                >
                  {HYDERABAD_LOCALITIES.map((l) => (
                    <option key={l.locality} value={l.locality}>
                      {l.locality}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0F172A] mb-1">
                  Private Phone (Never Public)
                </label>
                <input
                  type="tel"
                  required
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="+91-98765-43210"
                  className="w-full h-10 px-3 rounded-lg border border-slate-300 text-sm"
                />
              </div>
              <div className="sm:col-span-2 flex items-center gap-2 text-xs text-slate-700">
                <input
                  id="consent-coords"
                  type="checkbox"
                  checked={regConsent}
                  onChange={(e) => setRegConsent(e.target.checked)}
                />
                <label htmlFor="consent-coords">
                  Consent to locality-level proximity matching on the hospital map
                </label>
              </div>
              {error && <p className="sm:col-span-2 text-xs text-[#B91C1C]">{error}</p>}
              <div className="sm:col-span-2">
                <motion.button
                  type="submit"
                  whileTap={{ scale: 0.96 }}
                  className="px-5 py-2.5 bg-[#B91C1C] text-white text-sm font-semibold rounded-lg hover:bg-[#991B1B] cursor-pointer"
                >
                  Register Donor Profile
                </motion.button>
              </div>
            </form>
          )}
        </motion.section>
      </main>
    );
  }

  if (loading || !profile) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-4">
        <BloodDropLoader label="Loading donor readiness and recovery tracker..." />
        <div className="h-48 border border-slate-200 rounded-xl redrelay-shimmer-skeleton" />
        <div className="h-56 border border-slate-200 rounded-xl redrelay-shimmer-skeleton" />
      </main>
    );
  }

  const inRecovery = profile.effectiveAvailability === 'in_recovery';
  const recoveryDaysLeft = profile.recoveryUntil
    ? Math.max(
        0,
        Math.ceil((new Date(profile.recoveryUntil).getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      )
    : 0;

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <AnimatePresence>
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 text-sm text-[#0F172A]"
          >
            {feedback}
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-[#B91C1C]"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Donor Profile & 90-Day Donation Interval Tracker */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="space-y-1">
              <EcgPulseTrace label="Donor Readiness Channel" widthClass="w-28" />
              <p className="text-xs font-medium text-slate-500 pt-1">
                Voluntary Donor Profile · Public Alias: {profile.donorInitials}
              </p>
              <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
                {profile.fullName}
              </h1>
              <p className="text-xs text-slate-500">
                Private Contact (Hidden from Feeds):{' '}
                <span className="font-mono-tabular text-[#0F172A]">{profile.phone}</span>
              </p>
            </div>

            <motion.div
              whileHover={{ scale: 1.06 }}
              className="w-16 h-16 rounded-xl bg-red-50 border border-red-200 flex flex-col items-center justify-center"
            >
              <span className="font-display text-2xl font-extrabold text-[#B91C1C]">
                {profile.bloodGroup}
              </span>
              <span className="text-[10px] text-red-700 font-medium">Group</span>
            </motion.div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600">Availability:</span>
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                {(
                  [
                    ['available', 'Available', 'bg-[#16A34A]'],
                    ['unavailable', 'Unavailable', 'bg-[#0F172A]'],
                  ] as const
                ).map(([statusKey, statusLabel, activeBg]) => {
                  const isActive = profile.effectiveAvailability === statusKey;
                  return (
                    <motion.button
                      key={statusKey}
                      type="button"
                      whileTap={{ scale: 0.96 }}
                      disabled={inRecovery}
                      onClick={() => handleToggleAvailability(statusKey)}
                      className={`relative px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                        isActive
                          ? 'text-white'
                          : 'text-slate-600 hover:text-[#0F172A] disabled:opacity-40'
                      }`}
                    >
                      {isActive && (
                        <motion.span
                          layoutId="donor-avail-bg"
                          transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                          className={`absolute inset-0 rounded-md ${activeBg}`}
                        />
                      )}
                      <span className="relative z-10">{statusLabel}</span>
                    </motion.button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <motion.button
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => setShowCompatModal(true)}
                className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-[#0F172A] cursor-pointer"
              >
                <Droplets className="w-3.5 h-3.5 text-[#B91C1C]" />
                Compatibility Guide
              </motion.button>
              <label htmlFor="donor-locality" className="text-xs font-semibold text-slate-600 ml-1">
                Locality:
              </label>
              <select
                id="donor-locality"
                value={profile.locality}
                onChange={(e) => handleUpdateLocality(e.target.value)}
                className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A]"
              >
                {HYDERABAD_LOCALITIES.map((l) => (
                  <option key={l.locality} value={l.locality}>
                    {l.locality}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </motion.div>

        {/* 90-Day Donation Interval Tracker */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
          className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-4"
        >
          <div>
            <div className="flex items-center justify-between gap-2">
              <h2 className="text-sm font-bold text-[#0F172A]">90-Day Donation Interval</h2>
              <Calendar className="w-4 h-4 text-slate-500" />
            </div>

            <div className="mt-4 flex items-center gap-4">
              {/* Circular Recovery Gauge */}
              <div className="relative w-16 h-16 shrink-0 flex items-center justify-center">
                {!inRecovery && (
                  <motion.span
                    animate={{ scale: [0.95, 1.15], opacity: [0.45, 0] }}
                    transition={{ duration: 2.2, repeat: Infinity, ease: [0.16, 1, 0.3, 1] }}
                    className="absolute inset-0 rounded-full border-2 border-[#16A34A]"
                    aria-hidden="true"
                  />
                )}
                <svg viewBox="0 0 64 64" className="w-16 h-16 -rotate-90">
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    fill="none"
                    stroke="#E2E8F0"
                    strokeWidth="5"
                  />
                  <motion.circle
                    cx="32"
                    cy="32"
                    r="26"
                    fill="none"
                    stroke={inRecovery ? '#D97706' : '#16A34A'}
                    strokeWidth="5"
                    strokeLinecap="round"
                    initial={{ pathLength: 0 }}
                    animate={{
                      pathLength: inRecovery
                        ? Math.max(0.08, (90 - recoveryDaysLeft) / 90)
                        : 1,
                    }}
                    transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
                  />
                </svg>
                <span className="absolute font-mono-tabular text-xs font-bold text-[#0F172A]">
                  <AnimatedCounter value={inRecovery ? 90 - recoveryDaysLeft : 90} />d
                </span>
              </div>

              {inRecovery ? (
                <div className="space-y-1">
                  <p className="inline-flex items-center gap-2 text-base font-extrabold text-amber-700 font-mono-tabular">
                    <LiveBeaconDot tone="amber" size="sm" />
                    <span>
                      <AnimatedCounter value={recoveryDaysLeft} /> days remaining
                    </span>
                  </p>
                  <p className="text-xs text-slate-600">
                    Recovery active until{' '}
                    <strong className="font-mono-tabular text-[#0F172A]">
                      {new Date(profile.recoveryUntil!).toLocaleDateString()}
                    </strong>
                    . Restores automatically on expiry.
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  <p className="inline-flex items-center gap-1.5 text-base font-bold text-[#16A34A]">
                    <CheckCircle2 className="w-4 h-4" />
                    Eligible to Donate
                  </p>
                  <p className="text-xs text-slate-600">
                    {profile.lastDonationDate
                      ? `Last donation: ${new Date(
                          profile.lastDonationDate
                        ).toLocaleDateString()}.`
                      : 'No prior donations recorded on platform.'}
                  </p>
                </div>
              )}
            </div>
          </div>

          <p className="text-[11px] text-slate-500 pt-3 border-t border-slate-100">
            90-day recovery is a configurable hackathon guideline; final medical eligibility rests
            with authorized blood-bank clinicians.
          </p>
        </motion.div>
      </section>

      {/* Compatible Active Emergency Requests */}
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.24, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
        className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
      >
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-base font-bold text-[#0F172A]">
              Compatible Active SOS Requests (<AnimatedCounter value={compatibleRequests.length} />)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Matched by exact ABO/Rh compatibility for your {profile.bloodGroup} blood group.
            </p>
          </div>
          <Link to="/" className="text-xs font-semibold text-[#B91C1C] hover:underline">
            View Full Broadcast Feed
          </Link>
        </div>

        {compatibleRequests.length === 0 ? (
          <p className="text-sm text-slate-600">
            No active compatible emergency requests at this moment.
          </p>
        ) : (
          <div className="divide-y divide-slate-100">
            {compatibleRequests.map((req, idx) => (
              <motion.div
                key={req.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.18, delay: idx * 0.04 }}
                className="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 font-mono-tabular">
                    <span className="font-bold text-[#0F172A]">{req.requestCode}</span>
                    <span>·</span>
                    <span className="font-bold text-[#B91C1C]">{req.bloodGroup} Needed</span>
                    <span>·</span>
                    <span>
                      {req.unitsCommitted}/{req.unitsRequired} Units Committed
                    </span>
                    {req.distanceKm !== null && (
                      <>
                        <span>·</span>
                        <span>{req.distanceKm} km away</span>
                      </>
                    )}
                  </div>
                  <h3 className="text-sm font-bold text-[#0F172A]">
                    {req.hospitalName} ({req.locality})
                  </h3>
                  <p className="text-xs text-slate-600 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    Deadline: {new Date(req.urgencyDeadline).toLocaleString()}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Link
                    to={`/requests/${req.id}`}
                    className="px-3.5 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-[#0F172A] hover:bg-slate-50"
                  >
                    Details &amp; Relay
                  </Link>
                  {req.myResponse ? (
                    <span className="inline-flex items-center gap-1 px-3 py-2 rounded-lg bg-emerald-50 border border-emerald-200 text-xs font-semibold text-[#16A34A]">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      {req.myResponse.response_status}
                    </span>
                  ) : (
                    <motion.button
                      type="button"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.96 }}
                      disabled={inRecovery || profile.effectiveAvailability !== 'available' || req.unitsCommitted >= req.unitsRequired}
                      onClick={() => handleRespond(req.id)}
                      className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#B91C1C] hover:bg-[#991B1B] disabled:opacity-40 text-white text-xs font-semibold cursor-pointer"
                    >
                      <HeartHandshake className="w-3.5 h-3.5" />
                      I Can Donate
                    </motion.button>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.section>

      <RelayFlowLine color="#16A34A" />

      {/* Active Commitments & Certificates */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, delay: 0.14, ease: [0.16, 1, 0.3, 1] }}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <h2 className="text-base font-bold text-[#0F172A]">My Donation Commitments</h2>
          {!history || history.commitments.length === 0 ? (
            <p className="text-sm text-slate-600">You have not committed to any requests yet.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {history.commitments.map((c, idx) => {
                const selectedEta = etaDrafts[c.id] ?? c.eta_minutes ?? 30;
                const isOpenCommitment =
                  c.response_status === 'committed' || c.response_status === 'en_route';
                return (
                  <motion.div
                    key={c.id}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.18, delay: idx * 0.04 }}
                    className="py-3 flex flex-col gap-2.5"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <Link
                          to={`/requests/${c.request_id}`}
                          className="text-sm font-bold text-[#0F172A] hover:text-[#B91C1C]"
                        >
                          {c.request_code} · {c.hospital_name}
                        </Link>
                        <p className="text-xs text-slate-500 font-mono-tabular mt-0.5">
                          {c.blood_group} · {c.units_offered} unit · Status: {c.response_status}
                          {c.eta_minutes && (
                            <motion.span
                              key={c.eta_minutes}
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              transition={{ duration: 0.2 }}
                              className="text-emerald-700 font-semibold"
                            >
                              {' '}· ETA ~{c.eta_minutes}m
                            </motion.span>
                          )}
                        </p>
                      </div>

                      {isOpenCommitment && (
                        <motion.button
                          type="button"
                          whileHover={{ scale: 1.03 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() =>
                            setSelectedPass({
                              passCode: `LL-PASS-${c.request_code}-D${profile.id}`,
                              requestCode: c.request_code,
                              hospitalName: c.hospital_name,
                              hospitalLocation: c.hospital_location,
                              locality: c.locality,
                              donorInitials: profile.donorInitials,
                              bloodGroup: profile.bloodGroup,
                              unitsOffered: c.units_offered,
                              responseStatus: c.response_status,
                              etaMinutes: c.eta_minutes,
                            })
                          }
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-slate-300 text-xs font-semibold text-[#0F172A] hover:bg-slate-50 cursor-pointer"
                        >
                          <QrCode className="w-3.5 h-3.5 text-[#B91C1C]" />
                          Check-In Pass
                        </motion.button>
                      )}
                    </div>

                    {isOpenCommitment && (
                      <div className="flex flex-wrap items-center gap-2">
                        <select
                          aria-label={`Select arrival ETA for ${c.request_code}`}
                          value={selectedEta}
                          onChange={(e) =>
                            setEtaDrafts((prev) => ({
                              ...prev,
                              [c.id]: Number(e.target.value),
                            }))
                          }
                          className="h-8 px-2 rounded border border-slate-300 bg-white text-xs font-mono-tabular text-[#0F172A]"
                        >
                          <option value={15}>ETA 15 min</option>
                          <option value={30}>ETA 30 min</option>
                          <option value={45}>ETA 45 min</option>
                          <option value={60}>ETA 60 min</option>
                          <option value={90}>ETA 90 min</option>
                        </select>
                        <motion.button
                          type="button"
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleUpdateResponse(c.id, 'en_route', selectedEta)}
                          className="px-2.5 py-1.5 rounded bg-[#0F172A] text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                        >
                          {c.response_status === 'en_route' ? 'Update ETA' : 'Mark En Route'}
                        </motion.button>
                        {c.response_status === 'committed' && (
                          <motion.button
                            type="button"
                            whileTap={{ scale: 0.95 }}
                            onClick={() => handleUpdateResponse(c.id, 'withdrawn')}
                            className="px-2.5 py-1.5 rounded border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 cursor-pointer"
                          >
                            Withdraw
                          </motion.button>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </div>
          )}
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.24, delay: 0.18, ease: [0.16, 1, 0.3, 1] }}
          className="bg-white border border-slate-200 rounded-xl p-6 space-y-4"
        >
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-base font-bold text-[#0F172A]">
              Appreciation Certificates &amp; History
            </h2>
            <motion.div whileHover={{ rotate: 12, scale: 1.1 }}>
              <Award className="w-4 h-4 text-[#B91C1C]" />
            </motion.div>
          </div>
          {!history || history.certificates.length === 0 ? (
            <p className="text-sm text-slate-600">
              Certificates are issued strictly after a requester or administrator confirms blood
              receipt via the fulfillment workflow.
            </p>
          ) : (
            <div className="divide-y divide-slate-100">
              {history.certificates.map((cert, idx) => (
                <motion.div
                  key={cert.id}
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.18, delay: idx * 0.04 }}
                  className="py-3 flex items-center justify-between gap-3"
                >
                  <div>
                    <p className="text-sm font-bold text-[#0F172A]">{cert.hospitalName}</p>
                    <p className="text-xs text-slate-500 font-mono-tabular mt-0.5">
                      {cert.certificateCode} · {cert.bloodGroup} ·{' '}
                      {new Date(cert.donationDate).toLocaleDateString()}
                    </p>
                  </div>
                  <motion.button
                    type="button"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.96 }}
                    onClick={() => setSelectedCert(cert)}
                    className="px-3 py-1.5 rounded-lg bg-[#0F172A] text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
                  >
                    View &amp; Download
                  </motion.button>
                </motion.div>
              ))}
            </div>
          )}
        </motion.section>
      </div>

      <AnimatePresence>
        {selectedCert && (
          <CertificateModal certificate={selectedCert} onClose={() => setSelectedCert(null)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedPass && (
          <DonorCheckInPassModal pass={selectedPass} onClose={() => setSelectedPass(null)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showCompatModal && (
          <CompatibilityModal
            initialGroup={profile.bloodGroup}
            onClose={() => setShowCompatModal(false)}
          />
        )}
      </AnimatePresence>
    </main>
  );
}
