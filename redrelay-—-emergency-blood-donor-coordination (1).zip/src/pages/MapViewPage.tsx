import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import { BLOOD_GROUPS, type BloodGroup, type BloodRequestRecord, type MaskedDonorRecord } from '../../shared/types.ts';
import { HospitalDonorMap } from '../components/HospitalDonorMap.tsx';
import {
  AnimatedCounter,
  BloodDropLoader,
  EcgPulseTrace,
  LiveBeaconDot,
  RadarScanRing,
  RelayFlowLine,
} from '../components/MotionPrimitives.tsx';
import { api } from '../services/api.ts';

export function MapViewPage() {
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('B+');
  const [locality, setLocality] = useState<string>('');
  const [requests, setRequests] = useState<BloodRequestRecord[]>([]);
  const [donors, setDonors] = useState<MaskedDonorRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.listRequests({ scope: 'active' }),
      api.matchDonors({
        bloodGroup,
        city: 'Hyderabad',
        locality: locality || undefined,
      }),
    ])
      .then(([reqRes, donorRes]) => {
        setRequests(reqRes.requests);
        setDonors(donorRes.donors);
      })
      .finally(() => setLoading(false));
  }, [bloodGroup, locality]);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <motion.section
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
        className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4"
      >
        <div className="space-y-2 flex-1">
          <div className="flex items-center gap-3">
            <RadarScanRing size={38} tone="emerald" />
            <EcgPulseTrace label="Live Hyderabad Geo-Relay" color="#16A34A" trackColor="#DCFCE7" />
          </div>
          <h1 className="font-display text-2xl font-extrabold text-[#0F172A]">
            Hyderabad Emergency Hospital &amp; Donor Map
          </h1>
          <p className="text-sm text-slate-600">
            Interactive OpenStreetMap view showing active hospital emergencies and consented
            compatible donor localities. Private phone numbers and exact home addresses are never
            exposed.
          </p>
          <RelayFlowLine color="#16A34A" />
          <div className="flex flex-wrap items-center gap-4 pt-1 text-xs font-mono-tabular text-slate-600">
            <span className="inline-flex items-center gap-1.5">
              <LiveBeaconDot tone="red" size="sm" />
              <strong className="text-[#0F172A]">
                <AnimatedCounter value={requests.length} />
              </strong>{' '}
              Active Hospital Pins
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1.5">
              <LiveBeaconDot tone="emerald" size="sm" />
              <strong className="text-[#16A34A]">
                <AnimatedCounter value={donors.length} />
              </strong>{' '}
              Compatible Consented Donors ({bloodGroup})
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div>
            <label htmlFor="map-blood" className="block text-xs font-medium text-slate-500 mb-1">
              Compatible Donors For
            </label>
            <select
              id="map-blood"
              value={bloodGroup}
              onChange={(e) => setBloodGroup(e.target.value as BloodGroup)}
              className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A]"
            >
              {BLOOD_GROUPS.map((bg) => (
                <option key={bg} value={bg}>
                  {bg} Recipient
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="map-locality" className="block text-xs font-medium text-slate-500 mb-1">
              Locality Filter
            </label>
            <select
              id="map-locality"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              className="h-9 px-3 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A]"
            >
              <option value="">All Hyderabad Localities</option>
              {HYDERABAD_LOCALITIES.map((l) => (
                <option key={l.locality} value={l.locality}>
                  {l.locality}
                </option>
              ))}
            </select>
          </div>
        </div>
      </motion.section>

      <AnimatePresence mode="wait">
        {loading ? (
          <motion.div
            key="map-loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-4"
          >
            <BloodDropLoader label="Synchronizing hospital and donor geo-coordinates..." />
            <div className="h-[440px] border border-slate-200 rounded-xl redrelay-shimmer-skeleton" />
          </motion.div>
        ) : (
          <motion.div
            key="map-ready"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          >
            <HospitalDonorMap requests={requests} donors={donors} heightClass="h-[520px]" />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
