import {
  AlertCircle,
  Award,
  BellRing,
  CheckCircle2,
  Droplets,
  HeartHandshake,
  Lock,
  MapPin,
  Navigation,
  Plus,
  RefreshCw,
  Search,
  Send,
  ShieldCheck,
  UserPlus,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { getCompatibleDonorGroups, isCompatibleDonor } from '../../shared/bloodCompatibility.ts';
import { HYDERABAD_LOCALITIES } from '../../shared/hyderabadData.ts';
import {
  BLOOD_GROUPS,
  type BloodGroup,
  type BloodRequestRecord,
  type DirectoryDonorRecord,
} from '../../shared/types.ts';
import {
  AnimatedCounter,
  BloodDropLoader,
  EcgPulseTrace,
  HighlightedTagline,
  LiveBeaconDot,
  RadarScanRing,
  RelayFlowLine,
} from '../components/MotionPrimitives.tsx';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';

const EMPTY_COUNTS: Record<BloodGroup, number> = {
  'A+': 0,
  'A-': 0,
  'B+': 0,
  'B-': 0,
  'AB+': 0,
  'AB-': 0,
  'O+': 0,
  'O-': 0,
};

export function FindDonorsPage() {
  const { user, socket } = useAuth();
  const [searchParams] = useSearchParams();

  const initialBg = searchParams.get('bloodGroup');
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup | ''>(
    initialBg && BLOOD_GROUPS.includes(initialBg as BloodGroup) ? (initialBg as BloodGroup) : ''
  );
  const [matchMode, setMatchMode] = useState<'exact' | 'compatible'>('exact');
  const [locality, setLocality] = useState<string>(searchParams.get('locality') || '');
  const [nearLocality, setNearLocality] = useState<string>('');
  const [availability, setAvailability] = useState<'available' | 'all'>('available');
  const [searchQuery, setSearchQuery] = useState<string>(searchParams.get('q') || '');

  const [donors, setDonors] = useState<DirectoryDonorRecord[]>([]);
  const [exactCounts, setExactCounts] = useState<Record<BloodGroup, number>>(EMPTY_COUNTS);
  const [totalInScope, setTotalInScope] = useState(0);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [bannerSuccess, setBannerSuccess] = useState<string | null>(null);
  const [heroPhotoFailed, setHeroPhotoFailed] = useState(false);

  // Direct Donor Ping modal state
  const [pingTarget, setPingTarget] = useState<DirectoryDonorRecord | null>(null);
  const [activeRequests, setActiveRequests] = useState<BloodRequestRecord[]>([]);
  const [loadingRequests, setLoadingRequests] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<string>('');
  const [hospitalName, setHospitalName] = useState<string>('');
  const [pingMessage, setPingMessage] = useState<string>('');
  const [pingSubmitting, setPingSubmitting] = useState(false);
  const [pingError, setPingError] = useState<string | null>(null);

  const loadDirectory = useCallback(
    async (manual = false) => {
      setError(null);
      if (manual) setRefreshing(true);
      try {
        const res = await api.getDonorDirectory({
          bloodGroup: selectedGroup || undefined,
          matchMode: selectedGroup ? matchMode : 'exact',
          locality: locality || undefined,
          nearLocality: nearLocality || undefined,
          availability,
          q: searchQuery.trim() || undefined,
        });
        setDonors(res.donors);
        setExactCounts(res.exactCountsByGroup);
        setTotalInScope(res.totalInScope);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load voluntary donor directory.');
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [selectedGroup, matchMode, locality, nearLocality, availability, searchQuery]
  );

  useEffect(() => {
    setLoading(true);
    const timer = setTimeout(() => {
      void loadDirectory();
    }, 120);
    return () => clearTimeout(timer);
  }, [loadDirectory]);

  useEffect(() => {
    if (!socket) return;
    const refresh = () => {
      void loadDirectory();
    };
    socket.on('response:created', refresh);
    socket.on('fulfillment:confirmed', refresh);
    socket.on('request:created', refresh);
    return () => {
      socket.off('response:created', refresh);
      socket.off('fulfillment:confirmed', refresh);
      socket.off('request:created', refresh);
    };
  }, [socket, loadDirectory]);

  const openPingModal = async (donor: DirectoryDonorRecord) => {
    setPingTarget(donor);
    setSelectedRequestId('');
    setHospitalName('');
    setPingMessage('');
    setPingError(null);

    if (!user) return;
    setLoadingRequests(true);
    try {
      const res = await api.listRequests({ scope: 'active' });
      const compatible = res.requests.filter((r) =>
        isCompatibleDonor(r.bloodGroup, donor.bloodGroup)
      );
      setActiveRequests(compatible);
      if (compatible.length > 0) {
        setSelectedRequestId(String(compatible[0].id));
      }
    } catch {
      setActiveRequests([]);
    } finally {
      setLoadingRequests(false);
    }
  };

  const handleSendPing = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pingTarget) return;
    setPingError(null);
    setPingSubmitting(true);
    try {
      const res = await api.pingDonor(pingTarget.id, {
        requestId: selectedRequestId ? Number(selectedRequestId) : null,
        hospitalName: hospitalName.trim() || undefined,
        message: pingMessage.trim() || undefined,
      });
      setBannerSuccess(
        `Direct alert dispatched to ${pingTarget.bloodGroup} donor (${res.donorInitials}) in ${pingTarget.locality} via LifeLine in-app relay.`
      );
      setPingTarget(null);
    } catch (err) {
      setPingError(err instanceof Error ? err.message : 'Unable to dispatch direct alert.');
    } finally {
      setPingSubmitting(false);
    }
  };

  const stats = useMemo(() => {
    const readyCount = donors.filter((d) => d.effectiveAvailability === 'available').length;
    const verifiedCount = donors.filter((d) => d.verificationStatus === 'verified').length;
    const totalDonations = donors.reduce((acc, d) => acc + d.confirmedDonationsCount, 0);
    return { readyCount, verifiedCount, totalDonations };
  }, [donors]);

  const compatibleHint = useMemo(() => {
    if (!selectedGroup || matchMode !== 'compatible') return null;
    return getCompatibleDonorGroups(selectedGroup).join(', ');
  }, [selectedGroup, matchMode]);

  const donorRegistrationLink =
    user?.role === 'donor' ? '/donor' : '/auth?mode=register&role=donor';

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Hero Banner */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
        className="relative overflow-hidden bg-white border border-slate-200 rounded-xl p-6 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6"
      >
        <div className="absolute inset-0 redrelay-hero-ambient" aria-hidden="true" />
        <div className="relative z-10 max-w-2xl space-y-2.5">
          <div className="flex items-center gap-2.5">
            <RadarScanRing size={30} tone="red" />
            <EcgPulseTrace label="Voluntary Donor Directory" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#0F172A] tracking-tight text-balance">
            Find Verified Voluntary Blood Donors
          </h1>
          <div>
            <HighlightedTagline text="Every drop counts." />
          </div>
          <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
            Search voluntary donors by blood group, city, and neighborhood across Hyderabad. Unlike
            public phone directories, LifeLine keeps donor phone numbers and emails strictly private
            and dispatches direct alerts through verified in-app relays.
          </p>
        </div>

        <div className="relative z-10 flex flex-wrap items-center gap-3 shrink-0">
          {!heroPhotoFailed && (
            <div className="hidden md:block relative w-56 lg:w-64 aspect-[16/10] rounded-xl overflow-hidden border border-slate-200 shadow-sm shrink-0">
              <img
                src="/assets/aistudio/image_f00f2a9e.png"
                alt="Voluntary blood donor — Every drop counts"
                referrerPolicy="no-referrer"
                onError={() => setHeroPhotoFailed(true)}
                className="w-full h-full object-cover"
              />
              <div
                className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent"
                aria-hidden="true"
              />
              <span className="absolute bottom-2 left-2.5 text-xs font-bold text-white">
                Every drop counts.
              </span>
            </div>
          )}
          <motion.div whileHover={{ y: -2, scale: 1.02 }} whileTap={{ scale: 0.96 }}>
            <Link
              to={donorRegistrationLink}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-white border border-slate-300 hover:bg-slate-50 hover:border-slate-400 text-[#0F172A] text-sm font-semibold rounded-lg transition-all whitespace-nowrap shrink-0"
            >
              <UserPlus className="w-4 h-4 text-[#B91C1C]" />
              {user?.role === 'donor' ? 'My Donor Profile' : 'Register as Voluntary Donor'}
            </Link>
          </motion.div>
          <motion.div whileHover={{ y: -2, scale: 1.02 }} whileTap={{ scale: 0.96 }}>
            <Link
              to="/sos/new"
              className="redrelay-sos-pulse inline-flex items-center gap-2 px-5 py-2.5 bg-[#B91C1C] hover:bg-[#991B1B] text-white text-sm font-semibold rounded-lg transition-all whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              Post Emergency SOS
            </Link>
          </motion.div>
        </div>
      </motion.section>

      {/* Voluntary Non-Commercial & Privacy Pledge Strip */}
      <section className="bg-white border border-slate-200 rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
          <span className="inline-flex items-center gap-1.5 font-semibold text-[#0F172A]">
            <HeartHandshake className="w-4 h-4 text-[#B91C1C]" />
            100% Voluntary & Zero-Fee Coordination
          </span>
          <span aria-hidden="true" className="hidden sm:inline text-slate-300">
            ·
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-slate-500" />
            Donor phones & emails never displayed publicly
          </span>
          <span aria-hidden="true" className="hidden sm:inline text-slate-300">
            ·
          </span>
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-[#16A34A]" />
            90-day post-donation safety interval enforced
          </span>
        </div>
        <Link
          to="/map"
          className="inline-flex items-center gap-1 text-xs font-semibold text-[#B91C1C] hover:underline whitespace-nowrap shrink-0"
        >
          <MapPin className="w-3.5 h-3.5" />
          View Coverage Map
        </Link>
      </section>

      {/* Live Directory Metrics Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          {
            label: 'Donors Matching Filters',
            value: donors.length,
            colorClass: 'text-[#0F172A]',
          },
          {
            label: 'Ready to Donate Now',
            value: stats.readyCount,
            colorClass: 'text-[#16A34A]',
          },
          {
            label: 'Verified Profiles in Result',
            value: stats.verifiedCount,
            colorClass: 'text-[#0F172A]',
          },
        ].map((metric, idx) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            whileHover={{ y: -2 }}
            transition={{ duration: 0.22, delay: idx * 0.05, ease: [0.16, 1, 0.3, 1] }}
            className="bg-white border border-slate-200 rounded-xl p-4"
          >
            <p className="text-xs font-medium text-slate-500">{metric.label}</p>
            <p className={`font-mono-tabular text-2xl font-bold mt-1 ${metric.colorClass}`}>
              <AnimatedCounter value={metric.value} />
            </p>
          </motion.div>
        ))}
      </section>

      {/* Blood Group Selector & Directory Filters */}
      <section className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold text-[#0F172A] flex items-center gap-2">
              <Droplets className="w-4 h-4 text-[#B91C1C]" />
              Browse by Blood Group
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Select a blood group to filter exact donors or expand to ABO/Rh compatible groups.
            </p>
          </div>
          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => loadDirectory(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer whitespace-nowrap shrink-0"
          >
            <motion.span
              animate={refreshing ? { rotate: 360 } : { rotate: 0 }}
              transition={refreshing ? { duration: 0.7, repeat: Infinity, ease: 'linear' } : undefined}
              className="inline-flex"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </motion.span>
            {refreshing ? 'Syncing...' : 'Refresh Directory'}
          </motion.button>
        </div>

        <RelayFlowLine />

        {/* 8-Group + All Interactive Segmented Selector */}
        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2">
          <button
            type="button"
            onClick={() => setSelectedGroup('')}
            className={`relative px-3 py-2.5 rounded-lg border text-left transition-colors cursor-pointer whitespace-nowrap ${
              selectedGroup === ''
                ? 'border-[#B91C1C] bg-red-50/70 text-[#0F172A]'
                : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
            }`}
          >
            <span className="block text-xs font-bold">All Groups</span>
            <span className="block font-mono-tabular text-xs text-slate-500 mt-0.5">
              {totalInScope} donors
            </span>
          </button>

          {BLOOD_GROUPS.map((bg) => {
            const active = selectedGroup === bg;
            const count = exactCounts[bg] ?? 0;
            return (
              <button
                key={bg}
                type="button"
                onClick={() => setSelectedGroup((prev) => (prev === bg ? '' : bg))}
                className={`relative px-3 py-2.5 rounded-lg border text-left transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? 'border-[#B91C1C] bg-[#B91C1C] text-white'
                    : 'border-slate-200 bg-white hover:border-red-200 hover:bg-red-50/40 text-[#0F172A]'
                }`}
              >
                <span className="block font-display text-sm font-extrabold">{bg}</span>
                <span
                  className={`block font-mono-tabular text-xs mt-0.5 ${
                    active ? 'text-red-100' : 'text-slate-500'
                  }`}
                >
                  {count} {count === 1 ? 'donor' : 'donors'}
                </span>
              </button>
            );
          })}
        </div>

        {/* Location, Search, Match Mode & Proximity Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-1">
          <div>
            <label htmlFor="dir-search" className="block text-xs font-medium text-slate-600 mb-1">
              Search Locality or Initials
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                id="dir-search"
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Jubilee Hills, K. R..."
                className="w-full h-10 pl-8 pr-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
              />
            </div>
          </div>

          <div>
            <label htmlFor="dir-locality" className="block text-xs font-medium text-slate-600 mb-1">
              Filter by Locality
            </label>
            <select
              id="dir-locality"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
            >
              <option value="">All Hyderabad Localities</option>
              {HYDERABAD_LOCALITIES.map((loc) => (
                <option key={loc.locality} value={loc.locality}>
                  {loc.locality}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="dir-near" className="block text-xs font-medium text-slate-600 mb-1">
              Sort Closest To
            </label>
            <select
              id="dir-near"
              value={nearLocality}
              onChange={(e) => setNearLocality(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
            >
              <option value="">Default Readiness Order</option>
              {HYDERABAD_LOCALITIES.map((loc) => (
                <option key={loc.locality} value={loc.locality}>
                  Near {loc.locality}
                </option>
              ))}
            </select>
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-600 mb-1">
              Blood Group Match Rule
            </span>
            <div className="flex items-center gap-1 p-1 h-10 bg-slate-100 rounded-lg">
              {(
                [
                  ['exact', 'Exact Type'],
                  ['compatible', 'Compatible'],
                ] as const
              ).map(([mode, label]) => {
                const isActive = matchMode === mode;
                return (
                  <button
                    key={mode}
                    type="button"
                    disabled={!selectedGroup}
                    onClick={() => setMatchMode(mode)}
                    className={`flex-1 h-8 px-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
                      isActive
                        ? 'bg-white text-[#0F172A] shadow-xs'
                        : 'text-slate-600 hover:text-[#0F172A]'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <span className="block text-xs font-medium text-slate-600 mb-1">
              Donor Availability
            </span>
            <div className="flex items-center gap-1 p-1 h-10 bg-slate-100 rounded-lg">
              {(
                [
                  ['available', 'Ready Now'],
                  ['all', 'All Registered'],
                ] as const
              ).map(([val, label]) => {
                const isActive = availability === val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAvailability(val)}
                    className={`flex-1 h-8 px-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? 'bg-white text-[#0F172A] shadow-xs'
                        : 'text-slate-600 hover:text-[#0F172A]'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {compatibleHint && (
          <p className="text-xs text-slate-600">
            Showing red-cell compatible donor groups for recipient{' '}
            <strong className="text-[#0F172A]">{selectedGroup}</strong>:{' '}
            <span className="font-mono-tabular font-semibold text-[#B91C1C]">
              {compatibleHint}
            </span>
          </p>
        )}
      </section>

      <AnimatePresence>
        {bannerSuccess && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            role="status"
            className="bg-emerald-50 border border-emerald-200 rounded-xl px-4 py-3 flex items-center justify-between gap-3 text-sm text-[#0F172A]"
          >
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#16A34A] shrink-0" />
              {bannerSuccess}
            </span>
            <button
              type="button"
              onClick={() => setBannerSuccess(null)}
              aria-label="Dismiss message"
              className="p-1 text-slate-500 hover:text-[#0F172A] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 flex items-center gap-2 text-sm text-[#B91C1C]"
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Donor Cards Grid */}
      {loading ? (
        <div className="space-y-4">
          <BloodDropLoader label="Searching verified voluntary donors..." />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div
                key={n}
                className="border border-slate-200 rounded-xl p-5 h-44 redrelay-shimmer-skeleton"
              />
            ))}
          </div>
        </div>
      ) : donors.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.2 }}
          className="bg-white border border-slate-200 rounded-xl p-10 text-center"
        >
          <Search className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-base font-bold text-[#0F172A] mt-3">
            No voluntary donors match these filters
          </h3>
          <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
            Try switching to Compatible mode, including all localities, or broadcast an emergency SOS
            so nearby matching donors receive an instant alert.
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <button
              type="button"
              onClick={() => {
                setSelectedGroup('');
                setMatchMode('exact');
                setLocality('');
                setNearLocality('');
                setAvailability('available');
                setSearchQuery('');
              }}
              className="px-4 py-2 text-xs font-semibold border border-slate-300 rounded-lg text-[#0F172A] hover:bg-slate-50 cursor-pointer"
            >
              Reset Directory Filters
            </button>
            <Link
              to="/sos/new"
              className="px-4 py-2 text-xs font-semibold bg-[#B91C1C] text-white rounded-lg hover:bg-[#991B1B]"
            >
              Post Emergency SOS
            </Link>
          </div>
        </motion.div>
      ) : (
        <div
          key={`${selectedGroup}-${matchMode}-${locality}-${nearLocality}-${availability}-${searchQuery}`}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {donors.map((donor, idx) => {
            const isAvailable = donor.effectiveAvailability === 'available';
            const isRecovery = donor.effectiveAvailability === 'in_recovery';

            return (
              <motion.article
                key={donor.id}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.08 }}
                whileHover={{ y: -3 }}
                transition={{
                  duration: 0.22,
                  delay: Math.min((idx % 6) * 0.04, 0.2),
                  ease: [0.16, 1, 0.3, 1],
                }}
                className="bg-white border border-slate-200 hover:border-red-200 hover:shadow-md rounded-xl p-5 flex flex-col justify-between gap-4 transition-all duration-200"
              >
                <div className="space-y-3">
                  {/* Header: Blood Group Tile + Masked Alias & Location */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-12 h-12 rounded-xl bg-[#B91C1C] text-white flex items-center justify-center font-display text-lg font-extrabold shrink-0">
                        {donor.bloodGroup}
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-base font-bold text-[#0F172A] truncate">
                          Donor {donor.donorInitials}
                        </h3>
                        <p className="text-xs text-slate-600 flex items-center gap-1 truncate mt-0.5">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">
                            {donor.locality}, {donor.city}
                          </span>
                        </p>
                      </div>
                    </div>

                    {donor.distanceKm !== null && (
                      <span className="font-mono-tabular text-xs font-semibold text-[#0F172A] inline-flex items-center gap-1 shrink-0">
                        <Navigation className="w-3 h-3 text-[#B91C1C]" />
                        {donor.distanceKm.toFixed(1)} km
                      </span>
                    )}
                  </div>

                  {/* Clean Unboxed Status & Trust Metadata */}
                  <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-2">
                      {isAvailable ? (
                        <LiveBeaconDot tone="emerald" size="sm" />
                      ) : (
                        <span
                          className={`w-2 h-2 rounded-full shrink-0 ${
                            isRecovery ? 'bg-amber-500' : 'bg-slate-400'
                          }`}
                          aria-hidden="true"
                        />
                      )}
                      <span
                        className={`font-semibold ${
                          isAvailable
                            ? 'text-[#16A34A]'
                            : isRecovery
                            ? 'text-amber-700'
                            : 'text-slate-500'
                        }`}
                      >
                        {isAvailable
                          ? 'Ready to Donate'
                          : isRecovery
                          ? '90-Day Recovery'
                          : 'Unavailable'}
                      </span>
                      <span aria-hidden="true" className="text-slate-300">
                        ·
                      </span>
                      <span>
                        {donor.verificationStatus === 'verified'
                          ? 'Admin Verified'
                          : 'Pending Review'}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-slate-500">
                      <span className="inline-flex items-center gap-1 font-mono-tabular">
                        <Award className="w-3.5 h-3.5 text-slate-400" />
                        {donor.confirmedDonationsCount}{' '}
                        {donor.confirmedDonationsCount === 1
                          ? 'confirmed donation'
                          : 'confirmed donations'}
                      </span>
                      <span aria-hidden="true" className="text-slate-300">
                        ·
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Lock className="w-3 h-3 text-slate-400" />
                        Phone Protected
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-1">
                  {isAvailable ? (
                    <motion.button
                      type="button"
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => void openPingModal(donor)}
                      className="w-full py-2 px-4 rounded-lg bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      <BellRing className="w-3.5 h-3.5" />
                      Send Direct Alert
                    </motion.button>
                  ) : (
                    <button
                      type="button"
                      disabled
                      className="w-full py-2 px-4 rounded-lg bg-slate-100 text-slate-500 text-xs font-semibold cursor-not-allowed whitespace-nowrap shrink-0"
                    >
                      {isRecovery && donor.recoveryUntil
                        ? `Eligible ${new Date(donor.recoveryUntil).toLocaleDateString()}`
                        : 'Currently Unavailable'}
                    </button>
                  )}
                </div>
              </motion.article>
            );
          })}
        </div>
      )}

      {/* Blood Donation Awareness Visual Strip */}
      <section className="bg-white border border-slate-200 rounded-xl overflow-hidden grid grid-cols-1 md:grid-cols-12 items-center">
        <div className="md:col-span-5 aspect-[1200/628] bg-[#B80000] overflow-hidden">
          <img
            src="/assets/aistudio/image_272e9488.png"
            alt="Why Blood Donation Matters: Save Lives and Improve Health"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center"
          />
        </div>
        <div className="md:col-span-7 p-5 sm:p-6 space-y-2.5">
          <h2 className="font-display text-lg font-extrabold text-[#0F172A]">
            Every drop counts — Donate Safely, Help Locally
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Your single whole-blood unit supports red-cell, plasma, and surgical emergencies across
            Hyderabad hospitals. LifeLine protects your phone number and email at every step.
          </p>
          <div className="pt-1 flex flex-wrap items-center gap-3">
            <Link
              to={donorRegistrationLink}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#B91C1C] hover:bg-[#991B1B] text-white text-xs font-semibold"
            >
              <UserPlus className="w-3.5 h-3.5" />
              {user?.role === 'donor' ? 'Manage My Donor Profile' : 'Register as Voluntary Donor'}
            </Link>
          </div>
        </div>
      </section>

      {/* Clinical & Privacy Disclaimer */}
      <footer className="bg-white border border-slate-200 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-600">
        <ShieldCheck className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
        <p>
          <strong>Zero-Fee Voluntary Coordination & Privacy Shield:</strong> All donors listed here
          are strictly voluntary. LifeLine never sells blood, charges brokerage fees, or exposes
          donor phone numbers and email addresses. Final donor screening, infectious-disease testing,
          and crossmatching must be completed at an authorized hospital blood bank.
        </p>
      </footer>

      {/* Privacy-Masked Direct Donor Alert Modal */}
      <AnimatePresence>
        {pingTarget && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.16 }}
            className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-[2px] flex items-center justify-center p-4"
            onClick={() => setPingTarget(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white border border-slate-200 rounded-xl max-w-md w-full p-6 shadow-xl space-y-4"
              role="dialog"
              aria-modal="true"
              aria-labelledby="ping-modal-title"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 id="ping-modal-title" className="text-base font-bold text-[#0F172A]">
                    Alert Voluntary Donor {pingTarget.donorInitials}
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5">
                    {pingTarget.bloodGroup} · {pingTarget.locality}, {pingTarget.city} · Phone
                    number remains masked
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setPingTarget(null)}
                  aria-label="Close modal"
                  className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {!user ? (
                <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-3 text-sm text-slate-700">
                  <p>
                    Sign in (or select a role in the Demo Role Switcher above) to dispatch a
                    privacy-masked in-app alert to this {pingTarget.bloodGroup} donor.
                  </p>
                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setPingTarget(null)}
                      className="px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg cursor-pointer"
                    >
                      Close
                    </button>
                    <Link
                      to="/auth"
                      className="px-4 py-2 text-xs font-semibold bg-[#B91C1C] text-white rounded-lg hover:bg-[#991B1B]"
                    >
                      Sign In / Register
                    </Link>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSendPing} className="space-y-4">
                  <div>
                    <label
                      htmlFor="ping-request"
                      className="block text-xs font-semibold text-slate-700 mb-1"
                    >
                      Link Compatible Active SOS Request (Optional)
                    </label>
                    <select
                      id="ping-request"
                      value={selectedRequestId}
                      onChange={(e) => setSelectedRequestId(e.target.value)}
                      disabled={loadingRequests}
                      className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
                    >
                      <option value="">
                        {loadingRequests
                          ? 'Loading compatible active requests...'
                          : 'No linked SOS — send direct hospital inquiry'}
                      </option>
                      {activeRequests.map((req) => (
                        <option key={req.id} value={req.id}>
                          {req.requestCode} · {req.bloodGroup} · {req.hospitalName}
                        </option>
                      ))}
                    </select>
                  </div>

                  {!selectedRequestId && (
                    <div>
                      <label
                        htmlFor="ping-hospital"
                        className="block text-xs font-semibold text-slate-700 mb-1"
                      >
                        Hospital / Blood Bank Name
                      </label>
                      <input
                        id="ping-hospital"
                        type="text"
                        value={hospitalName}
                        onChange={(e) => setHospitalName(e.target.value)}
                        placeholder="e.g., Apollo Hospital Jubilee Hills Blood Bank"
                        className="w-full h-10 px-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
                      />
                    </div>
                  )}

                  <div>
                    <label
                      htmlFor="ping-note"
                      className="block text-xs font-semibold text-slate-700 mb-1"
                    >
                      Coordination Message (Ward, Timing, Crossmatch Desk)
                    </label>
                    <textarea
                      id="ping-note"
                      rows={3}
                      maxLength={300}
                      value={pingMessage}
                      onChange={(e) => setPingMessage(e.target.value)}
                      placeholder="e.g., Need 1 unit packed RBC at Emergency Blood Bank counter before 6:00 PM."
                      className="w-full p-3 rounded-lg border border-slate-300 bg-white text-sm text-[#0F172A]"
                    />
                  </div>

                  {pingError && (
                    <div className="bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-xs text-[#B91C1C]">
                      {pingError}
                    </div>
                  )}

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setPingTarget(null)}
                      className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100 rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                    <motion.button
                      type="submit"
                      disabled={pingSubmitting}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.96 }}
                      className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-[#B91C1C] hover:bg-[#991B1B] text-white rounded-lg cursor-pointer disabled:opacity-60"
                    >
                      <Send className="w-3.5 h-3.5" />
                      {pingSubmitting ? 'Dispatching Alert...' : 'Dispatch In-App Alert'}
                    </motion.button>
                  </div>
                </form>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
