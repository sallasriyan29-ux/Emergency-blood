import { ArrowRight, Bell, Check, CheckCheck, Radio, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import type { NotificationRecord } from '../../shared/types.ts';
import { RelayFlowLine } from './MotionPrimitives.tsx';

interface NotificationsDrawerProps {
  notifications: NotificationRecord[];
  loading: boolean;
  onClose: () => void;
  onMarkRead: (id: number) => Promise<void>;
  onMarkAllRead: () => Promise<void>;
}

export function NotificationsDrawer({
  notifications,
  loading,
  onClose,
  onMarkRead,
  onMarkAllRead,
}: NotificationsDrawerProps) {
  const [filter, setFilter] = useState<'all' | 'unread' | 'simulated_sms'>('all');
  const [markingAll, setMarkingAll] = useState(false);

  const unreadCount = notifications.filter((n) => !n.isRead).length;
  const filtered = notifications.filter((n) => {
    if (filter === 'unread') return !n.isRead;
    if (filter === 'simulated_sms') return n.channel === 'simulated_sms';
    return true;
  });

  const handleMarkAll = async () => {
    setMarkingAll(true);
    try {
      await onMarkAllRead();
    } finally {
      setMarkingAll(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.16 }}
      className="no-print fixed inset-0 z-50 bg-slate-900/45 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-label="Live Alerts & Notification Center"
      onClick={onClose}
    >
      <motion.aside
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-white h-full border-l border-slate-200 flex flex-col shadow-xl"
      >
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <motion.span
              animate={unreadCount > 0 ? { rotate: [0, -12, 12, -8, 8, 0] } : { rotate: 0 }}
              transition={
                unreadCount > 0
                  ? { duration: 0.7, repeat: Infinity, repeatDelay: 3.2, ease: 'easeInOut' }
                  : undefined
              }
              className="inline-flex origin-top"
            >
              <Bell className="w-4 h-4 text-[#B91C1C]" />
            </motion.span>
            <h2 className="font-display text-base font-bold text-[#0F172A]">
              Alerts &amp; Relay Notifications
            </h2>
            <span className="font-mono-tabular text-xs text-slate-500">
              · {unreadCount} unread
            </span>
          </div>
          <motion.button
            type="button"
            whileTap={{ scale: 0.92 }}
            onClick={onClose}
            aria-label="Close alerts drawer"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </motion.button>
        </div>

        <RelayFlowLine />

        <div className="px-5 py-3 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2 bg-slate-50">
          <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
            {(
              [
                ['all', `All (${notifications.length})`],
                ['unread', `Unread (${unreadCount})`],
                ['simulated_sms', 'Simulated SMS'],
              ] as const
            ).map(([key, label]) => {
              const active = filter === key;
              return (
                <motion.button
                  key={key}
                  type="button"
                  whileTap={{ scale: 0.96 }}
                  onClick={() => setFilter(key)}
                  className={`relative px-2.5 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active ? 'text-[#0F172A]' : 'text-slate-600 hover:text-[#0F172A]'
                  }`}
                >
                  {active && (
                    <motion.span
                      layoutId="notif-filter-bg"
                      transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                      className="absolute inset-0 bg-white rounded-md shadow-sm"
                    />
                  )}
                  <span className="relative z-10">{label}</span>
                </motion.button>
              );
            })}
          </div>

          {unreadCount > 0 && (
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.95 }}
              disabled={markingAll}
              onClick={handleMarkAll}
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#B91C1C] hover:underline disabled:opacity-50 cursor-pointer whitespace-nowrap"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              {markingAll ? 'Marking...' : 'Mark all read'}
            </motion.button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
          {loading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((n) => (
                <div key={n} className="h-20 rounded-lg redrelay-shimmer-skeleton" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.2 }}
              className="p-8 text-center space-y-2"
            >
              <Bell className="w-7 h-7 text-slate-300 mx-auto" />
              <p className="text-sm font-semibold text-[#0F172A]">
                No notifications in this view
              </p>
              <p className="text-xs text-slate-500">
                Real-time alerts appear here when SOS requests are verified, donors commit, or
                donations are confirmed.
              </p>
            </motion.div>
          ) : (
            <AnimatePresence initial={false}>
              {filtered.map((n, idx) => (
                <motion.div
                  key={n.id}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 16 }}
                  transition={{ duration: 0.2, delay: Math.min(idx * 0.035, 0.25), ease: [0.16, 1, 0.3, 1] }}
                  className={`p-4 space-y-2 transition-colors ${
                    n.isRead ? 'bg-white' : 'bg-red-50/35'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="inline-flex items-center gap-1.5 font-medium">
                      {n.channel === 'simulated_sms' && (
                        <Radio className="w-3 h-3 text-amber-700" />
                      )}
                      <span className={n.channel === 'simulated_sms' ? 'text-amber-800' : 'text-slate-600'}>
                        {n.channel === 'simulated_sms' ? 'Simulated SMS Dispatch' : 'In-App Relay'}
                      </span>
                      {!n.isRead && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-[#B91C1C]">Unread</span>
                        </>
                      )}
                    </span>
                    <span className="font-mono-tabular">
                      {new Date(n.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-[#0F172A]">{n.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed">{n.message}</p>

                  <div className="flex items-center justify-between gap-3 pt-1">
                    {n.requestId ? (
                      <Link
                        to={`/requests/${n.requestId}`}
                        onClick={() => {
                          if (!n.isRead) void onMarkRead(n.id);
                          onClose();
                        }}
                        className="group inline-flex items-center gap-1 text-xs font-semibold text-[#B91C1C] hover:underline"
                      >
                        Open {n.requestCode || 'Request'}
                        <ArrowRight className="w-3.5 h-3.5 transition-transform duration-150 group-hover:translate-x-0.5" />
                      </Link>
                    ) : (
                      <span />
                    )}

                    {!n.isRead && (
                      <motion.button
                        type="button"
                        whileTap={{ scale: 0.94 }}
                        onClick={() => onMarkRead(n.id)}
                        className="inline-flex items-center gap-1 text-xs font-medium text-slate-600 hover:text-[#0F172A] cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Mark read
                      </motion.button>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>
      </motion.aside>
    </motion.div>
  );
}
