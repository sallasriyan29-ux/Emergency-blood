import { CheckCircle2, Droplets, ShieldAlert, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useEffect, useState } from 'react';
import {
  getCompatibleDonorGroups,
  getCompatibleRecipientGroups,
} from '../../shared/bloodCompatibility.ts';
import { BLOOD_GROUPS, type BloodGroup, type BloodGroupSupplySummary } from '../../shared/types.ts';
import { api } from '../services/api.ts';
import { RelayFlowLine } from './MotionPrimitives.tsx';

interface CompatibilityModalProps {
  initialGroup?: BloodGroup;
  onClose: () => void;
  onSelectFilterGroup?: (group: BloodGroup) => void;
}

const SCREENING_QUESTIONS = [
  {
    id: 'age',
    label: 'Donor age is between 18 and 65 years',
  },
  {
    id: 'weight',
    label: 'Body weight is at least 50 kg (110 lbs)',
  },
  {
    id: 'interval',
    label: 'At least 90 days have elapsed since last whole-blood donation',
  },
  {
    id: 'health',
    label: 'Feeling well today with no fever, cold, or active infection',
  },
] as const;

export function CompatibilityModal({
  initialGroup = 'B+',
  onClose,
  onSelectFilterGroup,
}: CompatibilityModalProps) {
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup>(initialGroup);
  const [supplyMap, setSupplyMap] = useState<Record<string, BloodGroupSupplySummary>>({});
  const [checks, setChecks] = useState<Record<string, boolean>>({
    age: true,
    weight: true,
    interval: true,
    health: true,
  });

  useEffect(() => {
    api
      .getDonorSupplySummary()
      .then((res) => {
        const next: Record<string, BloodGroupSupplySummary> = {};
        for (const g of res.groups) {
          next[g.bloodGroup] = g;
        }
        setSupplyMap(next);
      })
      .catch(() => {});
  }, []);

  const canReceiveFrom = getCompatibleDonorGroups(selectedGroup);
  const canDonateTo = getCompatibleRecipientGroups(selectedGroup);
  const currentSupply = supplyMap[selectedGroup];
  const allChecksPassed = SCREENING_QUESTIONS.every((q) => Boolean(checks[q.id]));

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.16 }}
      className="no-print fixed inset-0 z-50 bg-slate-900/55 flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label="ABO/Rh Compatibility & Eligibility Explorer"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 8 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white border border-slate-200 rounded-xl max-w-3xl w-full overflow-hidden my-auto"
      >
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <motion.span
              animate={{ scale: [1, 1.12, 1] }}
              transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
              className="inline-flex"
            >
              <Droplets className="w-5 h-5 text-[#B91C1C]" />
            </motion.span>
            <h2 className="font-display text-lg font-bold text-[#0F172A]">
              ABO/Rh Compatibility &amp; Donor Readiness Guide
            </h2>
          </div>
          <motion.button
            type="button"
            whileTap={{ scale: 0.92 }}
            onClick={onClose}
            aria-label="Close compatibility guide"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </motion.button>
        </div>

        <RelayFlowLine />

        <div className="p-6 space-y-6">
          {/* Blood Group Selector */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-600">
              Select an ABO/Rh blood group to inspect clinical red-cell matching rules and live Hyderabad availability:
            </p>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
              {BLOOD_GROUPS.map((bg) => {
                const active = selectedGroup === bg;
                return (
                  <motion.button
                    key={bg}
                    type="button"
                    whileHover={{ y: -1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedGroup(bg)}
                    className={`relative h-11 rounded-lg font-mono-tabular text-sm font-bold border transition-colors cursor-pointer ${
                      active
                        ? 'text-white border-[#B91C1C]'
                        : 'bg-white text-[#0F172A] border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="compat-selected-bg"
                        transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                        className="absolute inset-0 bg-[#B91C1C] rounded-lg"
                      />
                    )}
                    <span className="relative z-10">{bg}</span>
                  </motion.button>
                );
              })}
            </div>
          </div>

          {/* Compatibility Results */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-slate-200 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#0F172A]">
                  If Patient Needs {selectedGroup}
                </h3>
                <span className="font-mono-tabular text-xs text-slate-500">
                  {canReceiveFrom.length} donor group{canReceiveFrom.length === 1 ? '' : 's'}
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Compatible red-cell donor blood groups:
              </p>
              <div className="flex flex-wrap gap-2 font-mono-tabular text-xs font-bold text-[#B91C1C]">
                <AnimatePresence mode="popLayout">
                  {canReceiveFrom.map((g, idx) => (
                    <motion.span
                      key={`${selectedGroup}-rcv-${g}`}
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      transition={{ duration: 0.16, delay: idx * 0.03 }}
                      className="px-2.5 py-1 rounded bg-red-50 border border-red-200"
                    >
                      {g}
                    </motion.span>
                  ))}
                </AnimatePresence>
              </div>
              {currentSupply && (
                <p className="text-xs text-slate-600 pt-2 border-t border-slate-100 font-mono-tabular">
                  Live Hyderabad pool:{' '}
                  <strong className="text-[#16A34A]">{currentSupply.compatibleDonors}</strong>{' '}
                  compatible available donor(s) ·{' '}
                  <strong className="text-[#0F172A]">{currentSupply.activeUnitsNeeded}</strong>{' '}
                  active unit(s) needed
                </p>
              )}
            </div>

            <div className="border border-slate-200 rounded-xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-[#0F172A]">
                  If Donor Is {selectedGroup}
                </h3>
                <span className="font-mono-tabular text-xs text-slate-500">
                  {canDonateTo.length} recipient group{canDonateTo.length === 1 ? '' : 's'}
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Can safely supply red cells to recipients with:
              </p>
              <div className="flex flex-wrap gap-2 font-mono-tabular text-xs font-bold text-[#0F172A]">
                <AnimatePresence mode="popLayout">
                  {canDonateTo.map((g, idx) => (
                    <motion.span
                      key={`${selectedGroup}-don-${g}`}
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      transition={{ duration: 0.16, delay: idx * 0.03 }}
                      className="px-2.5 py-1 rounded bg-slate-100 border border-slate-200"
                    >
                      {g}
                    </motion.span>
                  ))}
                </AnimatePresence>
              </div>
              {currentSupply && (
                <p className="text-xs text-slate-600 pt-2 border-t border-slate-100 font-mono-tabular">
                  Exact {selectedGroup} donors ready:{' '}
                  <strong className="text-[#0F172A]">
                    {currentSupply.availableDonors}/{currentSupply.totalDonors}
                  </strong>
                </p>
              )}
            </div>
          </div>

          {/* 4-Point Pre-Screening Self-Check */}
          <div className="border border-slate-200 rounded-xl p-4 space-y-3 bg-slate-50">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-[#0F172A]">
                Quick Voluntary Donor Pre-Screening Check
              </h3>
              <AnimatePresence mode="wait">
                {allChecksPassed ? (
                  <motion.span
                    key="screen-pass"
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 4 }}
                    transition={{ duration: 0.16 }}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#16A34A]"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Meets baseline self-check criteria
                  </motion.span>
                ) : (
                  <motion.span
                    key="screen-defer"
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 4 }}
                    transition={{ duration: 0.16 }}
                    className="text-xs font-semibold text-amber-700"
                  >
                    Defer donation until criteria are met
                  </motion.span>
                )}
              </AnimatePresence>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SCREENING_QUESTIONS.map((q) => (
                <motion.label
                  key={q.id}
                  whileTap={{ scale: 0.99 }}
                  className="flex items-start gap-2.5 p-2.5 rounded-lg bg-white border border-slate-200 text-xs text-slate-700 cursor-pointer hover:border-slate-300 transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={Boolean(checks[q.id])}
                    onChange={(e) =>
                      setChecks((prev) => ({ ...prev, [q.id]: e.target.checked }))
                    }
                    className="mt-0.5"
                  />
                  <span>{q.label}</span>
                </motion.label>
              ))}
            </div>

            <p className="text-[11px] text-slate-500 flex items-start gap-1.5">
              <ShieldAlert className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              Informational coordination tool only. Hemoglobin check, infectious disease screening,
              and final clinical crossmatching are conducted exclusively by authorized blood-bank staff.
            </p>
          </div>
        </div>

        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-end gap-3">
          {onSelectFilterGroup && (
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => {
                onSelectFilterGroup(selectedGroup);
                onClose();
              }}
              className="px-4 py-2 rounded-lg bg-[#B91C1C] hover:bg-[#991B1B] text-white text-xs font-semibold cursor-pointer"
            >
              Filter Feed for {selectedGroup} Requests
            </motion.button>
          )}
          <motion.button
            type="button"
            whileTap={{ scale: 0.96 }}
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-300 bg-white text-xs font-semibold text-[#0F172A] hover:bg-slate-50 cursor-pointer"
          >
            Close
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}
