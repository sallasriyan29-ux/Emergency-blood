import { Clock, MapPin, Printer, ShieldCheck, X } from 'lucide-react';
import { motion } from 'motion/react';
import type { BloodGroup } from '../../shared/types.ts';
import { RelayFlowLine } from './MotionPrimitives.tsx';

export interface CheckInPassData {
  passCode: string;
  requestCode: string;
  hospitalName: string;
  hospitalLocation: string;
  locality: string;
  donorInitials: string;
  bloodGroup: BloodGroup;
  unitsOffered: number;
  responseStatus: string;
  etaMinutes: number | null;
}

interface DonorCheckInPassModalProps {
  pass: CheckInPassData;
  onClose: () => void;
}

function buildDeterministicMatrix(seedText: string): boolean[][] {
  const size = 9;
  const grid: boolean[][] = [];
  let hash = 2166136261;
  for (let i = 0; i < seedText.length; i++) {
    hash ^= seedText.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  for (let r = 0; r < size; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < size; c++) {
      // Corner anchor squares for authentic check-in glyph symmetry
      const isCorner =
        (r < 3 && c < 3) || (r < 3 && c >= size - 3) || (r >= size - 3 && c < 3);
      if (isCorner) {
        const localR = r < 3 ? r : r - (size - 3);
        const localC = c < 3 ? c : c - (size - 3);
        row.push(localR !== 1 || localC !== 1 || (localR === 1 && localC === 1));
      } else {
        hash ^= r * 31 + c * 17;
        hash = Math.imul(hash, 16777619);
        row.push((hash >>> 0) % 2 === 0);
      }
    }
    grid.push(row);
  }
  return grid;
}

export function DonorCheckInPassModal({ pass, onClose }: DonorCheckInPassModalProps) {
  const matrix = buildDeterministicMatrix(pass.passCode);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.16 }}
      className="fixed inset-0 z-50 bg-slate-900/60 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Hospital Blood Bank Check-In Pass"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 8 }}
        transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white border border-slate-200 rounded-xl max-w-md w-full overflow-hidden"
      >
        <div className="no-print px-5 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#16A34A]" />
            <h2 className="font-display text-base font-bold text-[#0F172A]">
              Hospital Check-In Pass
            </h2>
          </div>
          <motion.button
            type="button"
            whileTap={{ scale: 0.92 }}
            onClick={onClose}
            aria-label="Close check-in pass"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </motion.button>
        </div>

        <div className="p-5 bg-slate-50">
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
            <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-100">
              <div>
                <p className="font-mono-tabular text-xs font-bold text-[#B91C1C]">
                  {pass.passCode}
                </p>
                <h3 className="font-display text-lg font-extrabold text-[#0F172A] mt-0.5">
                  {pass.hospitalName}
                </h3>
                <p className="text-xs text-slate-600 flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 shrink-0" />
                  {pass.hospitalLocation} ({pass.locality})
                </p>
              </div>
              <motion.div
                whileHover={{ scale: 1.06 }}
                className="w-12 h-12 rounded-lg bg-red-50 border border-red-200 flex flex-col items-center justify-center shrink-0"
              >
                <span className="font-display text-base font-extrabold text-[#B91C1C]">
                  {pass.bloodGroup}
                </span>
              </motion.div>
            </div>

            <RelayFlowLine color="#16A34A" />

            <div className="flex items-center justify-between gap-4">
              <div className="space-y-1.5 text-xs">
                <p className="text-slate-500">
                  Masked Donor Alias:{' '}
                  <strong className="text-[#0F172A] font-mono-tabular">{pass.donorInitials}</strong>
                </p>
                <p className="text-slate-500">
                  Request Code:{' '}
                  <strong className="text-[#0F172A] font-mono-tabular">{pass.requestCode}</strong>
                </p>
                <p className="text-slate-500">
                  Commitment:{' '}
                  <strong className="text-[#0F172A] font-mono-tabular">
                    {pass.unitsOffered} unit(s) · {pass.responseStatus}
                  </strong>
                </p>
                {pass.etaMinutes && (
                  <p className="text-emerald-700 font-semibold flex items-center gap-1 font-mono-tabular">
                    <Clock className="w-3.5 h-3.5" />
                    Reported ETA: ~{pass.etaMinutes} min
                  </p>
                )}
              </div>

              <svg
                viewBox="0 0 90 90"
                className="w-20 h-20 shrink-0 border border-slate-200 rounded-lg p-1.5 bg-white"
                aria-label="Verification code matrix"
              >
                {matrix.map((row, r) =>
                  row.map((filled, c) =>
                    filled ? (
                      <motion.rect
                        key={`${r}-${c}`}
                        x={c * 10 + 1}
                        y={r * 10 + 1}
                        width={8}
                        height={8}
                        rx={1.5}
                        fill="#0F172A"
                        initial={{ opacity: 0, scale: 0.4 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: (r + c) * 0.015, duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                      />
                    ) : null
                  )
                )}
              </svg>
            </div>

            <p className="text-[11px] text-slate-500 pt-3 border-t border-slate-100">
              Present this pass code at the hospital blood bank reception for priority donor intake.
              Personal phone numbers remain masked.
            </p>
          </div>
        </div>

        <div className="no-print px-5 py-3.5 bg-white border-t border-slate-200 flex items-center justify-end gap-2">
          <motion.button
            type="button"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.96 }}
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#0F172A] text-white text-xs font-semibold hover:bg-slate-800 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Pass
          </motion.button>
          <motion.button
            type="button"
            whileTap={{ scale: 0.96 }}
            onClick={onClose}
            className="px-3.5 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-[#0F172A] hover:bg-slate-50 cursor-pointer"
          >
            Close
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}
