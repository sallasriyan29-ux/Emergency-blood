import { AlertTriangle, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import type { BloodGroup, BloodGroupSupplySummary } from '../../shared/types.ts';
import { AnimatedCounter } from './MotionPrimitives.tsx';

interface BloodSupplyBoardProps {
  groups: BloodGroupSupplySummary[];
  onSelectBloodGroup?: (group: BloodGroup) => void;
  selectedGroup?: string;
}

export function BloodSupplyBoard({
  groups,
  onSelectBloodGroup,
  selectedGroup,
}: BloodSupplyBoardProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
      {groups.map((item, idx) => {
        const isShortage =
          item.activeUnitsNeeded > 0 && item.compatibleDonors < item.activeUnitsNeeded;
        const isLowExact = item.availableDonors <= 1 && item.activeUnitsNeeded > 0;
        const isSelected = selectedGroup === item.bloodGroup;
        const coverageRatio =
          item.activeUnitsNeeded > 0
            ? Math.min(1, item.compatibleDonors / Math.max(1, item.activeUnitsNeeded * 2))
            : Math.min(1, item.availableDonors / Math.max(1, item.totalDonors));

        return (
          <motion.button
            key={item.bloodGroup}
            type="button"
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.15 }}
            whileHover={{ y: -3 }}
            whileTap={{ scale: 0.97 }}
            transition={{ duration: 0.2, delay: idx * 0.025 }}
            onClick={() => onSelectBloodGroup?.(item.bloodGroup)}
            className={`relative text-left border rounded-xl p-3.5 transition-all duration-200 hover:shadow-md cursor-pointer ${
              isSelected
                ? 'border-[#B91C1C] bg-red-50/40'
                : isShortage || isLowExact
                ? 'border-amber-200 bg-white hover:border-amber-300'
                : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            {isSelected && (
              <motion.span
                layoutId="supply-selected-ring"
                transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                className="pointer-events-none absolute -inset-px rounded-xl border-2 border-[#B91C1C]"
              />
            )}

            <div className="flex items-center justify-between gap-1">
              <span className="font-display text-lg font-extrabold text-[#B91C1C]">
                {item.bloodGroup}
              </span>
              {isShortage || isLowExact ? (
                <motion.span
                  animate={{ scale: [1, 1.18, 1] }}
                  transition={{ duration: 1.9, repeat: Infinity, ease: 'easeInOut' }}
                  className="inline-flex"
                >
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" aria-label="Low reserve" />
                </motion.span>
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A]" aria-label="Ready" />
              )}
            </div>

            <div className="mt-2 h-1 w-full bg-slate-100 rounded-full overflow-hidden">
              <motion.div
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: Math.max(0.08, coverageRatio) }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{ duration: 0.5, delay: idx * 0.03, ease: [0.16, 1, 0.3, 1] }}
                style={{ transformOrigin: 'left' }}
                className={`h-full w-full ${
                  isShortage || isLowExact ? 'bg-amber-500' : 'bg-[#16A34A]'
                }`}
              />
            </div>

            <div className="mt-2.5 space-y-1 font-mono-tabular text-xs">
              <div className="flex items-center justify-between text-slate-600">
                <span>Ready</span>
                <strong className="text-[#0F172A]">
                  <AnimatedCounter value={item.availableDonors} />/{item.totalDonors}
                </strong>
              </div>
              <div className="flex items-center justify-between text-slate-600">
                <span>Pool</span>
                <strong className="text-[#16A34A]">
                  <AnimatedCounter value={item.compatibleDonors} />
                </strong>
              </div>
              <div className="flex items-center justify-between text-slate-600 pt-1 border-t border-slate-100">
                <span>Need</span>
                <strong className={item.activeUnitsNeeded > 0 ? 'text-[#B91C1C]' : 'text-slate-500'}>
                  {item.activeUnitsNeeded}u
                </strong>
              </div>
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}
