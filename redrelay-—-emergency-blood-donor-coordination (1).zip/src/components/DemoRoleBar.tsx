import { Bell, ShieldCheck, Users } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useCallback, useEffect, useState } from 'react';
import type { NotificationRecord } from '../../shared/types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { LiveBeaconDot } from './MotionPrimitives.tsx';
import { NotificationsDrawer } from './NotificationsDrawer.tsx';

export function DemoRoleBar() {
  const { user, demoAccounts, switchDemoRole, socket, socketConnected } = useAuth();
  const [switchingEmail, setSwitchingEmail] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [notifLoading, setNotifLoading] = useState(false);

  const loadNotifications = useCallback(async () => {
    if (!user) {
      setNotifications([]);
      return;
    }
    setNotifLoading(true);
    try {
      const res = await api.getNotifications();
      setNotifications(res.notifications);
    } catch {
      // Keep existing state on transient error
    } finally {
      setNotifLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  useEffect(() => {
    if (!socket || !user) return;
    const refresh = () => {
      void loadNotifications();
    };
    socket.on('notification:created', refresh);
    socket.on('request:verified', refresh);
    socket.on('response:created', refresh);
    return () => {
      socket.off('notification:created', refresh);
      socket.off('request:verified', refresh);
      socket.off('response:created', refresh);
    };
  }, [socket, user, loadNotifications]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkRead = async (id: number) => {
    await api.markNotificationRead(id);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const handleMarkAllRead = async () => {
    await api.markAllNotificationsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  if (demoAccounts.length === 0) return null;

  const handleSwitch = async (email: string) => {
    setError(null);
    setSwitchingEmail(email);
    try {
      await switchDemoRole(email);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to switch demo role.');
    } finally {
      setSwitchingEmail(null);
    }
  };

  return (
    <>
      <div className="no-print bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 mr-1">
              <Users className="w-3.5 h-3.5 text-slate-500" />
              Demo Role Switcher:
            </span>
            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-200/70 rounded-lg">
              {demoAccounts.map((acc) => {
                const isActive = user?.email === acc.email;
                const shortLabel =
                  acc.role === 'requester'
                    ? 'Requester'
                    : acc.role === 'admin'
                    ? 'Admin'
                    : `Donor (${acc.bloodGroup || 'Donor'})`;

                return (
                  <motion.button
                    key={acc.email}
                    type="button"
                    whileTap={{ scale: 0.96 }}
                    disabled={switchingEmail !== null}
                    onClick={() => handleSwitch(acc.email)}
                    className={`relative px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? 'text-[#0F172A] font-semibold'
                        : 'text-slate-600 hover:text-[#0F172A]'
                    }`}
                  >
                    {isActive && (
                      <motion.span
                        layoutId="demo-role-active-bg"
                        transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                        className="absolute inset-0 bg-white rounded-md shadow-sm"
                      />
                    )}
                    <span className="relative z-10">
                      {switchingEmail === acc.email ? 'Switching...' : shortLabel}
                    </span>
                  </motion.button>
                );
              })}
            </div>
            <AnimatePresence mode="wait">
              {user && (
                <motion.span
                  key={user.email}
                  initial={{ opacity: 0, x: -4 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 4 }}
                  transition={{ duration: 0.16 }}
                  className="text-xs text-slate-600 ml-1"
                >
                  Active: <strong className="text-[#0F172A]">{user.name}</strong>
                  <span aria-hidden="true"> · </span>
                  <span className="capitalize">{user.role}</span>
                </motion.span>
              )}
            </AnimatePresence>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
            {user && (
              <motion.button
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setDrawerOpen(true);
                  void loadNotifications();
                }}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border border-slate-300 bg-white hover:bg-slate-100 text-xs font-semibold text-[#0F172A] whitespace-nowrap shrink-0 cursor-pointer"
              >
                <motion.span
                  animate={unreadCount > 0 ? { rotate: [0, -14, 14, -8, 8, 0] } : { rotate: 0 }}
                  transition={
                    unreadCount > 0
                      ? { duration: 0.65, repeat: Infinity, repeatDelay: 3.5, ease: 'easeInOut' }
                      : undefined
                  }
                  className="inline-flex origin-top"
                >
                  <Bell className="w-3.5 h-3.5 text-[#B91C1C]" />
                </motion.span>
                <span>Alerts</span>
                {unreadCount > 0 && (
                  <motion.span
                    key={unreadCount}
                    initial={{ scale: 0.7, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 24 }}
                    className="font-mono-tabular text-[#B91C1C] font-bold"
                  >
                    ({unreadCount})
                  </motion.span>
                )}
              </motion.button>
            )}
            <span className="inline-flex items-center gap-1.5">
              <LiveBeaconDot tone={socketConnected ? 'emerald' : 'amber'} size="sm" />
              {socketConnected ? 'Live Socket Connected' : 'Reconnecting Feed'}
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
              Hyderabad Demo Dataset · Coordination Only
            </span>
          </div>
        </div>
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 pb-2 text-xs text-[#B91C1C]"
            >
              {error}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {drawerOpen && (
          <NotificationsDrawer
            notifications={notifications}
            loading={notifLoading}
            onClose={() => setDrawerOpen(false)}
            onMarkRead={handleMarkRead}
            onMarkAllRead={handleMarkAllRead}
          />
        )}
      </AnimatePresence>
    </>
  );
}
