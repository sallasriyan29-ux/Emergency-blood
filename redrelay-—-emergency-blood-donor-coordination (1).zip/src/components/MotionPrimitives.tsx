import { animate, motion, useInView, useReducedMotion } from 'motion/react';
import { type ReactNode, useEffect, useRef, useState } from 'react';

interface AnimatedCounterProps {
  value: number;
  className?: string;
}

export function AnimatedCounter({ value, className }: AnimatedCounterProps) {
  const prefersReduced = useReducedMotion();
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, amount: 'some' });
  const [displayValue, setDisplayValue] = useState(prefersReduced ? value : 0);
  const previousAnimatedValue = useRef(0);

  useEffect(() => {
    if (prefersReduced) {
      setDisplayValue(value);
      previousAnimatedValue.current = value;
      return;
    }
    if (!inView) return;

    const startFrom = previousAnimatedValue.current;
    const controls = animate(startFrom, value, {
      duration: 0.65,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (latest) => {
        setDisplayValue(Math.round(latest));
      },
      onComplete: () => {
        previousAnimatedValue.current = value;
      },
    });
    return () => controls.stop();
  }, [value, inView, prefersReduced]);

  return (
    <span ref={ref} className={className}>
      {displayValue}
    </span>
  );
}

interface EcgPulseTraceProps {
  label?: string;
  color?: string;
  trackColor?: string;
  widthClass?: string;
}

export function EcgPulseTrace({
  label = 'Emergency Dispatch Relay',
  color = '#B91C1C',
  trackColor = '#FEE2E2',
  widthClass = 'w-36',
}: EcgPulseTraceProps) {
  return (
    <div className="flex items-center gap-3" aria-hidden="true">
      <svg viewBox="0 0 180 28" className={`${widthClass} h-6`} fill="none">
        <path
          d="M0 14 H36 L44 14 L50 5 L56 23 L62 3 L68 20 L74 14 H180"
          stroke={trackColor}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <motion.path
          d="M0 14 H36 L44 14 L50 5 L56 23 L62 3 L68 20 L74 14 H180"
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0, opacity: 0.45 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{
            duration: 2.1,
            repeat: Infinity,
            repeatDelay: 1.1,
            ease: [0.16, 1, 0.3, 1],
          }}
        />
      </svg>
      {label && (
        <span
          className="font-mono-tabular text-[11px] font-semibold tracking-wide"
          style={{ color }}
        >
          {label}
        </span>
      )}
    </div>
  );
}

interface LiveBeaconDotProps {
  tone?: 'red' | 'emerald' | 'amber';
  size?: 'sm' | 'md';
}

export function LiveBeaconDot({ tone = 'red', size = 'sm' }: LiveBeaconDotProps) {
  const bg =
    tone === 'emerald' ? 'bg-[#16A34A]' : tone === 'amber' ? 'bg-amber-500' : 'bg-[#DC2626]';
  const box = size === 'md' ? 'w-3 h-3' : 'w-2.5 h-2.5';
  const core = size === 'md' ? 'w-2 h-2' : 'w-1.5 h-1.5';

  return (
    <span className={`relative flex ${box} items-center justify-center shrink-0`} aria-hidden="true">
      <motion.span
        animate={{ scale: [1, 2.3], opacity: [0.7, 0] }}
        transition={{ duration: 1.6, repeat: Infinity, ease: [0.16, 1, 0.3, 1] }}
        className={`absolute inset-0 rounded-full ${bg}`}
      />
      <span className={`relative ${core} rounded-full ${bg}`} />
    </span>
  );
}

interface RadarScanRingProps {
  size?: number;
  tone?: 'red' | 'emerald';
}

export function RadarScanRing({ size = 44, tone = 'red' }: RadarScanRingProps) {
  const stroke = tone === 'emerald' ? '#16A34A' : '#B91C1C';
  const fill = tone === 'emerald' ? 'rgba(22, 163, 74, 0.16)' : 'rgba(185, 28, 28, 0.16)';

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 44 44"
      className="shrink-0"
      aria-hidden="true"
    >
      <circle cx="22" cy="22" r="20" fill="none" stroke="#E2E8F0" strokeWidth="1.25" />
      <circle cx="22" cy="22" r="12" fill="none" stroke="#E2E8F0" strokeWidth="1" strokeDasharray="3 3" />
      <g className="redrelay-radar-sweep">
        <path d="M22 22 L22 2 A20 20 0 0 1 39.32 12 Z" fill={fill} />
        <line x1="22" y1="22" x2="22" y2="2" stroke={stroke} strokeWidth="1.5" strokeLinecap="round" />
      </g>
      <circle cx="22" cy="22" r="3" fill={stroke} />
    </svg>
  );
}

export function RelayFlowLine({ color = '#B91C1C' }: { color?: string }) {
  return (
    <div className="relative h-px w-full bg-slate-200 overflow-hidden" aria-hidden="true">
      <motion.span
        animate={{ x: ['-15%', '115%'] }}
        transition={{ duration: 2.6, repeat: Infinity, ease: 'linear' }}
        style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }}
        className="absolute top-0 left-0 h-full w-24"
      />
    </div>
  );
}

interface BloodDropLoaderProps {
  label?: string;
}

export function BloodDropLoader({ label = 'Syncing emergency dispatch data...' }: BloodDropLoaderProps) {
  return (
    <div
      className="flex flex-col items-center justify-center py-6 gap-3"
      role="status"
      aria-live="polite"
    >
      <div className="relative flex items-center justify-center">
        <motion.span
          animate={{ scale: [0.9, 1.45], opacity: [0.4, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: [0.16, 1, 0.3, 1] }}
          className="absolute w-12 h-12 rounded-full border-2 border-[#B91C1C]"
          aria-hidden="true"
        />
        <motion.svg
          viewBox="0 0 40 48"
          className="w-10 h-12 drop-shadow-xs"
          animate={{ y: [0, -4, 0] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
          aria-hidden="true"
        >
          <defs>
            <clipPath id="redrelay-drop-clip">
              <path d="M20 3 C20 3 6 19.5 6 30.5 C6 38.5 12.27 45 20 45 C27.73 45 34 38.5 34 30.5 C34 19.5 20 3 20 3 Z" />
            </clipPath>
          </defs>
          <path
            d="M20 3 C20 3 6 19.5 6 30.5 C6 38.5 12.27 45 20 45 C27.73 45 34 38.5 34 30.5 C34 19.5 20 3 20 3 Z"
            fill="#FEE2E2"
            stroke="#B91C1C"
            strokeWidth="2"
          />
          <g clipPath="url(#redrelay-drop-clip)">
            <motion.rect
              x="0"
              y="0"
              width="40"
              height="48"
              fill="#B91C1C"
              initial={{ y: 38 }}
              animate={{ y: [36, 12, 36] }}
              transition={{ duration: 1.9, repeat: Infinity, ease: [0.16, 1, 0.3, 1] }}
            />
          </g>
          <path
            d="M14 29 C14 33 16.5 36.5 20 37.5"
            fill="none"
            stroke="#FFFFFF"
            strokeOpacity="0.65"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </motion.svg>
      </div>
      <p className="text-xs font-medium text-slate-600">{label}</p>
    </div>
  );
}

interface ScrollRevealProps {
  children: ReactNode;
  delay?: number;
  className?: string;
}

export function ScrollReveal({ children, delay = 0, className }: ScrollRevealProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.28, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

interface HighlightedTaglineProps {
  text?: string;
  variant?: 'light' | 'dark';
  size?: 'md' | 'lg';
}

export function HighlightedTagline({
  text = 'Every drop counts.',
  variant = 'light',
  size = 'md',
}: HighlightedTaglineProps) {
  const prefersReduced = useReducedMotion();
  const words = text.split(' ');
  const isDark = variant === 'dark';

  return (
    <motion.div
      initial={prefersReduced ? false : { opacity: 0, y: 8 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 'some' }}
      transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
      className="relative inline-flex items-center gap-2.5 py-1.5 px-2.5 pr-5"
    >
      {/* Animated highlight swath behind the tagline */}
      <motion.span
        aria-hidden="true"
        initial={prefersReduced ? false : { scaleX: 0, opacity: 0 }}
        whileInView={{ scaleX: 1, opacity: 1 }}
        viewport={{ once: true, amount: 'some' }}
        transition={{ duration: 0.45, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
        className={`absolute inset-0 origin-left rounded-lg overflow-hidden ${
          isDark
            ? 'bg-gradient-to-r from-[#DC2626]/40 via-[#B91C1C]/25 to-transparent'
            : 'bg-gradient-to-r from-[#FEE2E2]/95 via-[#FEF2F2]/85 to-transparent'
        }`}
      >
        {!prefersReduced && (
          <motion.span
            animate={{ x: ['-100%', '220%'] }}
            transition={{ duration: 3.4, repeat: Infinity, repeatDelay: 1.8, ease: 'easeInOut' }}
            className={`absolute inset-y-0 w-1/2 ${
              isDark
                ? 'bg-gradient-to-r from-transparent via-white/15 to-transparent'
                : 'bg-gradient-to-r from-transparent via-white/75 to-transparent'
            }`}
          />
        )}
      </motion.span>

      {/* Subtle pulsing blood drop emblem */}
      <motion.svg
        viewBox="0 0 20 24"
        className={`relative z-10 shrink-0 ${size === 'lg' ? 'w-6 h-7' : 'w-5 h-6'}`}
        animate={
          prefersReduced
            ? undefined
            : {
                scale: [1, 1.15, 1, 1.08, 1],
                y: [0, -1, 0],
              }
        }
        transition={{ duration: 2.6, repeat: Infinity, ease: 'easeInOut' }}
        aria-hidden="true"
      >
        <path
          d="M10 1.5 C10 1.5 3 10.2 3 15.6 C3 19.6 6.13 22.5 10 22.5 C13.87 22.5 17 19.6 17 15.6 C17 10.2 10 1.5 10 1.5 Z"
          fill={isDark ? '#F87171' : '#B91C1C'}
        />
        <path
          d="M7 15 C7 17 8.3 18.8 10 19.2"
          fill="none"
          stroke="#FFFFFF"
          strokeOpacity="0.7"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
      </motion.svg>

      {/* Word-by-word kinetic animated & highlighted typography */}
      <div className="relative z-10 flex flex-col">
        <p
          className={`font-display font-extrabold tracking-tight flex flex-wrap items-baseline gap-x-2 leading-tight ${
            size === 'lg' ? 'text-2xl sm:text-3xl' : 'text-xl sm:text-2xl'
          }`}
        >
          {words.map((word, idx) => (
            <motion.span
              key={`${word}-${idx}`}
              initial={prefersReduced ? false : { opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 'some' }}
              transition={{
                duration: 0.32,
                delay: 0.08 + idx * 0.1,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="inline-block"
            >
              <motion.span
                animate={
                  prefersReduced
                    ? undefined
                    : {
                        y: [0, -2.5, 0],
                        scale: [1, 1.045, 1],
                      }
                }
                transition={{
                  duration: 0.72,
                  delay: 0.5 + idx * 0.16,
                  repeat: Infinity,
                  repeatDelay: 2.2,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={`inline-block ${
                  prefersReduced
                    ? isDark
                      ? 'text-white'
                      : 'text-[#B91C1C]'
                    : isDark
                    ? 'redrelay-tagline-text-dark'
                    : 'redrelay-tagline-text-light'
                }`}
              >
                {word}
              </motion.span>
            </motion.span>
          ))}
        </p>

        {/* Animated highlight underline sweep */}
        <div
          className={`relative h-[3px] w-full mt-1 rounded-full overflow-hidden ${
            isDark ? 'bg-red-400/35' : 'bg-[#B91C1C]/20'
          }`}
          aria-hidden="true"
        >
          <motion.span
            initial={prefersReduced ? false : { scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, amount: 'some' }}
            transition={{ duration: 0.5, delay: 0.24, ease: [0.16, 1, 0.3, 1] }}
            className={`absolute inset-0 origin-left rounded-full ${
              isDark
                ? 'bg-gradient-to-r from-red-400 via-white to-red-400'
                : 'bg-gradient-to-r from-[#B91C1C] via-[#EF4444] to-[#B91C1C]'
            }`}
          />
          {!prefersReduced && (
            <motion.span
              animate={{ x: ['-40%', '240%'] }}
              transition={{ duration: 2.8, repeat: Infinity, repeatDelay: 1.6, ease: 'easeInOut' }}
              className="absolute inset-y-0 left-0 w-1/3 bg-gradient-to-r from-transparent via-white/90 to-transparent"
            />
          )}
        </div>
      </div>
    </motion.div>
  );
}
