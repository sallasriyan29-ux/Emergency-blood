import { CheckCircle2, Clock, Truck, UserCheck } from 'lucide-react';
import { motion } from 'motion/react';
import type { AuditLogRecord, LifecycleStatus } from '../../shared/types.ts';

interface LifecycleStepperProps {
  lifecycleStatus: LifecycleStatus;
  createdAt: string;
  closedAt: string | null;
  auditLogs?: AuditLogRecord[];
}

const STAGES: Array<{
  key: 'open' | 'donors_responded' | 'fulfilled_in_transit' | 'closed';
  label: string;
  subtitle: string;
  Icon: typeof Clock;
}> = [
  {
    key: 'open',
    label: 'Open / Broadcasted',
    subtitle: 'Request logged & awaiting verification or donor match',
    Icon: Clock,
  },
  {
    key: 'donors_responded',
    label: 'Donors Responded',
    subtitle: 'Compatible donor commitment(s) recorded',
    Icon: UserCheck,
  },
  {
    key: 'fulfilled_in_transit',
    label: 'Fulfilled / In Transit',
    subtitle: 'Required units committed · awaiting blood bank receipt',
    Icon: Truck,
  },
  {
    key: 'closed',
    label: 'Closed',
    subtitle: 'Emergency resolved and confirmed',
    Icon: CheckCircle2,
  },
];

function getStageIndex(status: LifecycleStatus): number {
  if (status === 'open') return 0;
  if (status === 'donors_responded') return 1;
  if (status === 'fulfilled_in_transit') return 2;
  if (status === 'closed') return 3;
  return -1;
}

export function LifecycleStepper({
  lifecycleStatus,
  createdAt,
  closedAt,
  auditLogs = [],
}: LifecycleStepperProps) {
  const activeIndex = getStageIndex(lifecycleStatus);

  const stageTimestamp = (stageKey: string): string | null => {
    if (stageKey === 'open') return createdAt;
    if (stageKey === 'closed' && closedAt) return closedAt;
    if (stageKey === 'donors_responded') {
      const log = auditLogs.find((l) => l.action === 'DONOR_RESPONDED');
      return log ? log.createdAt : null;
    }
    if (stageKey === 'fulfilled_in_transit') {
      const log = auditLogs.find((l) => l.details.includes('fulfilled_in_transit'));
      return log ? log.createdAt : null;
    }
    return null;
  };

  if (lifecycleStatus === 'expired' || lifecycleStatus === 'cancelled') {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-[#0F172A]">Request Lifecycle</h3>
          <span className="text-xs font-semibold text-amber-700 uppercase">
            {lifecycleStatus === 'expired' ? 'Expired Automatically' : 'Cancelled by Requester'}
          </span>
        </div>
        <p className="text-sm text-slate-600 mt-3">
          This emergency request was removed from the active broadcast feed on{' '}
          <span className="font-mono-tabular text-[#0F172A]">
            {closedAt ? new Date(closedAt).toLocaleString() : 'expiration'}
          </span>
          . Audit history remains preserved for accountability.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5">
      <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100">
        <h3 className="text-sm font-semibold text-[#0F172A]">
          Four-Stage Request Lifecycle
        </h3>
        <span className="text-xs text-slate-500">
          Donor commitments do not confirm delivery until blood receipt is verified
        </span>
      </div>

      {/* Relay Flow Track across the 4 stages */}
      <div className="hidden lg:block relative h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{
            scaleX:
              lifecycleStatus === 'closed'
                ? 1
                : activeIndex >= 0
                ? (activeIndex + 0.5) / 4
                : 0,
          }}
          transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
          style={{ transformOrigin: 'left' }}
          className={`h-full w-full ${
            lifecycleStatus === 'closed'
              ? 'bg-[#16A34A]'
              : 'bg-[#B91C1C] redrelay-fill-shimmer'
          }`}
        />
        {lifecycleStatus !== 'closed' && activeIndex >= 0 && (
          <motion.span
            aria-hidden="true"
            animate={{ x: ['-10%', '1000%'] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'linear' }}
            className="absolute top-0 left-0 h-full w-10 bg-gradient-to-r from-transparent via-white/75 to-transparent"
          />
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        {STAGES.map((stage, idx) => {
          const isCompleted = idx < activeIndex || (lifecycleStatus === 'closed' && idx === 3);
          const isCurrent = idx === activeIndex && lifecycleStatus !== 'closed';
          const Icon = stage.Icon;
          const ts = stageTimestamp(stage.key);

          return (
            <motion.div
              key={stage.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ y: -2 }}
              transition={{ duration: 0.22, delay: idx * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className={`p-3.5 rounded-lg border transition-colors ${
                isCompleted
                  ? 'bg-emerald-50/50 border-emerald-200'
                  : isCurrent
                  ? 'bg-red-50/50 border-red-200'
                  : 'bg-slate-50/70 border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <span className="font-mono-tabular text-xs font-semibold text-slate-500">
                  Stage {idx + 1}
                </span>
                <motion.div
                  animate={isCurrent ? { scale: [1, 1.15, 1] } : { scale: 1 }}
                  transition={
                    isCurrent
                      ? { duration: 1.8, repeat: Infinity, ease: 'easeInOut' }
                      : { duration: 0.15 }
                  }
                >
                  <Icon
                    className={`w-4 h-4 ${
                      isCompleted
                        ? 'text-[#16A34A]'
                        : isCurrent
                        ? 'text-[#B91C1C]'
                        : 'text-slate-400'
                    }`}
                  />
                </motion.div>
              </div>
              <p className="text-sm font-semibold text-[#0F172A]">{stage.label}</p>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">{stage.subtitle}</p>
              <p className="font-mono-tabular text-[11px] text-slate-500 mt-2">
                {ts ? new Date(ts).toLocaleString() : isCurrent ? 'In Progress' : 'Pending'}
              </p>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
