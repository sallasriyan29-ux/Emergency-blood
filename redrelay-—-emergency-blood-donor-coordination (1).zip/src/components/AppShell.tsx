import {
  ArrowRight,
  Bell,
  ChevronDown,
  Droplets,
  Home,
  LogIn,
  LogOut,
  MapPin,
  Menu,
  PlusSquare,
  Search,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { type FormEvent, type ReactNode, useCallback, useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { BLOOD_GROUPS, type BloodGroup, type NotificationRecord } from '../../shared/types.ts';
import { useAuth } from '../context/AuthContext.tsx';
import { api } from '../services/api.ts';
import { LiveBeaconDot } from './MotionPrimitives.tsx';
import { NotificationsDrawer } from './NotificationsDrawer.tsx';

const SIDEBAR_NAV = [
  { to: '/', label: 'Home', icon: Home, end: true },
  { to: '/donors', label: 'Find Blood', icon: Search, end: false },
  { to: '/donor', label: 'Donate Blood', icon: Droplets, end: false },
  { to: '/sos/new', label: 'Request Blood', icon: PlusSquare, end: false },
  { to: '/map', label: 'Blood Heatmap', icon: MapPin, end: false },
  { to: '/admin', label: 'Admin Console', icon: ShieldCheck, end: false },
] as const;

function getInitials(name?: string | null): string {
  if (!name) return 'LL';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return `${parts[0][0] ?? ''}${parts[parts.length - 1][0] ?? ''}`.toUpperCase();
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user, demoAccounts, switchDemoRole, logout, socket, socketConnected } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);
  const [switchingEmail, setSwitchingEmail] = useState<string | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [notifLoading, setNotifLoading] = useState(false);
  const [headerSearch, setHeaderSearch] = useState('');

  const searchInputRef = useRef<HTMLInputElement>(null);
  const roleMenuRef = useRef<HTMLDivElement>(null);

  const loadNotifications = useCallback(async () => {
    if (!user) {
      setNotifications([]);
      return;
    }
    setNotifLoading(true);
    try {
      const res = await api.getNotifications();
      setNotifications(res.notifications);
    } catch {
      // Keep existing list on transient error
    } finally {
      setNotifLoading(false);
    }
  }, [user]);

  useEffect(() => {
    void loadNotifications();
  }, [loadNotifications]);

  useEffect(() => {
    if (!socket || !user) return;
    const refresh = () => {
      void loadNotifications();
    };
    socket.on('notification:created', refresh);
    socket.on('request:verified', refresh);
    socket.on('response:created', refresh);
    return () => {
      socket.off('notification:created', refresh);
      socket.off('request:verified', refresh);
      socket.off('response:created', refresh);
    };
  }, [socket, user, loadNotifications]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (roleMenuRef.current && !roleMenuRef.current.contains(e.target as Node)) {
        setRoleMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleMarkRead = async (id: number) => {
    await api.markNotificationRead(id);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const handleMarkAllRead = async () => {
    await api.markAllNotificationsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const handleSearchSubmit = (e: FormEvent) => {
    e.preventDefault();
    const raw = headerSearch.trim();
    if (!raw) {
      navigate('/donors');
      return;
    }
    const upper = raw.toUpperCase() as BloodGroup;
    if (BLOOD_GROUPS.includes(upper)) {
      navigate(`/donors?bloodGroup=${encodeURIComponent(upper)}`);
      return;
    }
    navigate(`/donors?q=${encodeURIComponent(raw)}`);
  };

  const handleSwitchRole = async (email: string) => {
    setSwitchingEmail(email);
    try {
      await switchDemoRole(email);
      setRoleMenuOpen(false);
    } finally {
      setSwitchingEmail(null);
    }
  };

  const renderSidebarContent = (isMobile = false) => (
    <div className="flex flex-col justify-between h-full px-4 py-5 select-none">
      <div className="space-y-6">
        {/* Sidebar Brand Header */}
        <div className="flex items-center justify-between gap-2 px-1">
          <Link
            to="/"
            onClick={() => isMobile && setMobileNavOpen(false)}
            className="flex items-center gap-2.5 group"
          >
            <motion.img
              src="/assets/aistudio/Red_Blood_Drop_Care_Logo_51326305.png"
              alt="LifeLine Logo"
              whileHover={{ scale: 1.08 }}
              className="h-9 w-auto object-contain shrink-0 redrelay-heartbeat-subtle"
            />
            <div className="leading-tight">
              <span className="block font-display text-lg font-extrabold tracking-tight text-white">
                LifeLine
              </span>
              <span className="block text-[11px] text-slate-300/80">
                Blood Donation Network
              </span>
            </div>
          </Link>
          {isMobile && (
            <button
              type="button"
              onClick={() => setMobileNavOpen(false)}
              aria-label="Close menu"
              className="p-1.5 rounded-lg text-slate-300 hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Vertical Navigation Links */}
        <nav className="space-y-1.5" aria-label="Sidebar Navigation">
          {SIDEBAR_NAV.map((item) => {
            const Icon = item.icon;
            const isActive = item.end
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to);

            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={() => isMobile && setMobileNavOpen(false)}
                className={`relative flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-white font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                {isActive && (
                  <motion.span
                    layoutId={isMobile ? 'sidebar-active-mobile' : 'sidebar-active-desktop'}
                    transition={{ type: 'spring', stiffness: 460, damping: 34 }}
                    className="absolute inset-0 rounded-xl bg-gradient-to-r from-[#DC2626] to-[#B91C1C] shadow-md shadow-red-950/30"
                  />
                )}
                <Icon className="w-4 h-4 relative z-10 shrink-0" />
                <span className="relative z-10">{item.label}</span>
              </NavLink>
            );
          })}
        </nav>
      </div>

      {/* Bottom Sidebar Lifesaver Card */}
      <div className="mt-6 rounded-2xl bg-white/[0.06] border border-white/10 p-4 text-center space-y-3">
        <motion.div
          animate={{ y: [0, -4, 0] }}
          transition={{ duration: 3.4, repeat: Infinity, ease: 'easeInOut' }}
          className="flex justify-center"
        >
          <img
            src="/assets/aistudio/Red_Blood_Drop_Care_Logo_51326305.png"
            alt="Be a Lifesaver"
            className="h-12 w-auto object-contain drop-shadow"
          />
        </motion.div>
        <div className="space-y-1">
          <p className="font-display text-sm font-bold text-white">Be a Lifesaver</p>
          <p className="text-[11px] text-slate-300 leading-relaxed">
            Every drop counts. Donate blood and give someone a second chance at life.
          </p>
        </div>
        <Link
          to={user?.role === 'donor' ? '/donor' : '/auth?mode=register&role=donor'}
          onClick={() => isMobile && setMobileNavOpen(false)}
          className="w-full py-2 px-3 rounded-xl bg-[#E0F2FE] hover:bg-white text-[#0F172A] text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
        >
          Donate Now
          <ArrowRight className="w-3.5 h-3.5 text-[#B91C1C]" />
        </Link>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-[#EFF3F8] text-[#0F172A]">
      {/* Fixed Desktop Left Sidebar */}
      <aside className="no-print hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 lg:left-0 bg-[#0B1736] border-r border-slate-800 z-30">
        {renderSidebarContent(false)}
      </aside>

      {/* Mobile Slide-Out Sidebar Drawer */}
      <AnimatePresence>
        {mobileNavOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileNavOpen(false)}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-[2px] z-40 lg:hidden"
            />
            <motion.aside
              initial={{ x: -272 }}
              animate={{ x: 0 }}
              exit={{ x: -272 }}
              transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
              className="fixed inset-y-0 left-0 w-64 bg-[#0B1736] z-50 lg:hidden shadow-2xl"
            >
              {renderSidebarContent(true)}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content Shell */}
      <div className="flex-1 flex flex-col min-w-0 lg:pl-64">
        {/* Top Utility Header */}
        <header className="no-print sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-slate-200/90">
          <div className="max-w-[1400px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
            {/* Mobile Menu Trigger + Global Search */}
            <div className="flex items-center gap-3 flex-1 min-w-0 max-w-xl">
              <button
                type="button"
                onClick={() => setMobileNavOpen(true)}
                aria-label="Open navigation menu"
                className="lg:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 shrink-0 cursor-pointer"
              >
                <Menu className="w-5 h-5" />
              </button>

              <form onSubmit={handleSearchSubmit} className="relative flex-1 min-w-0">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  ref={searchInputRef}
                  type="search"
                  value={headerSearch}
                  onChange={(e) => setHeaderSearch(e.target.value)}
                  placeholder="Search hospitals, blood groups (e.g., O+, A-), or locations..."
                  aria-label="Search hospitals, blood groups, or locations"
                  className="w-full h-10 pl-10 pr-16 rounded-xl border border-slate-200 bg-slate-50/80 hover:bg-white focus:bg-white focus:border-[#B91C1C] focus:outline-none text-sm text-[#0F172A] transition-colors"
                />
                <kbd className="hidden sm:inline-flex items-center px-1.5 py-0.5 text-[11px] font-mono-tabular font-medium text-slate-500 bg-white border border-slate-200 rounded-md absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
                  Ctrl K
                </kbd>
              </form>
            </div>

            {/* Right Controls: City + Live Indicator + Notifications + User / Demo Role Switcher */}
            <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
              <div className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-medium text-[#0F172A] whitespace-nowrap shrink-0">
                <MapPin className="w-3.5 h-3.5 text-[#B91C1C]" />
                <span>Hyderabad</span>
                <span aria-hidden="true" className="text-slate-300">
                  ·
                </span>
                <LiveBeaconDot tone={socketConnected ? 'emerald' : 'amber'} size="sm" />
              </div>

              {user && (
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(true);
                    void loadNotifications();
                  }}
                  aria-label="Open notifications"
                  className="relative p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 cursor-pointer shrink-0"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-[#DC2626] text-white font-mono-tabular text-[10px] font-bold flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>
              )}

              {/* User Profile & Demo Role Switcher Dropdown */}
              <div className="relative" ref={roleMenuRef}>
                <button
                  type="button"
                  onClick={() => setRoleMenuOpen((prev) => !prev)}
                  className="flex items-center gap-2.5 pl-1.5 pr-2.5 py-1 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span className="w-8 h-8 rounded-full bg-gradient-to-br from-[#DC2626] to-[#991B1B] text-white font-display text-xs font-bold flex items-center justify-center shrink-0">
                    {user ? getInitials(user.name) : 'LL'}
                  </span>
                  <div className="hidden sm:block text-left leading-tight">
                    <span className="block text-xs font-bold text-[#0F172A] max-w-[120px] truncate">
                      {user ? user.name : 'Switch Role / Sign In'}
                    </span>
                    <span className="block text-[11px] text-[#16A34A] font-medium capitalize">
                      {user ? `${user.role} Account` : 'Demo & Auth Menu'}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                </button>

                <AnimatePresence>
                  {roleMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 6, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 4, scale: 0.98 }}
                      transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
                      className="absolute right-0 mt-2 w-72 rounded-2xl bg-white border border-slate-200 shadow-xl p-3 space-y-2.5 z-50"
                    >
                      {demoAccounts.length > 0 && (
                        <div className="space-y-1.5">
                          <p className="px-2 text-[11px] font-semibold text-slate-500 flex items-center gap-1.5">
                            <Users className="w-3.5 h-3.5" />
                            1-Click Demo Role Switcher
                          </p>
                          <div className="space-y-1">
                            {demoAccounts.map((acc) => {
                              const active = user?.email === acc.email;
                              const label =
                                acc.role === 'requester'
                                  ? `${acc.name} (Requester)`
                                  : acc.role === 'admin'
                                  ? `${acc.name} (Admin)`
                                  : `${acc.name} (Donor · ${acc.bloodGroup})`;

                              return (
                                <button
                                  key={acc.email}
                                  type="button"
                                  disabled={switchingEmail !== null}
                                  onClick={() => void handleSwitchRole(acc.email)}
                                  className={`w-full text-left px-2.5 py-2 rounded-xl text-xs font-medium flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                                    active
                                      ? 'bg-red-50 text-[#B91C1C] font-semibold'
                                      : 'text-slate-700 hover:bg-slate-100'
                                  }`}
                                >
                                  <span className="truncate">{label}</span>
                                  {switchingEmail === acc.email ? (
                                    <span className="text-[10px] text-slate-400">...</span>
                                  ) : active ? (
                                    <span className="text-[10px] font-bold">Active</span>
                                  ) : null}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      <div className="pt-2 border-t border-slate-100 flex flex-col gap-1">
                        {user ? (
                          <button
                            type="button"
                            onClick={async () => {
                              await logout();
                              setRoleMenuOpen(false);
                              navigate('/auth');
                            }}
                            className="w-full px-2.5 py-2 rounded-xl text-xs font-semibold text-slate-700 hover:bg-slate-100 flex items-center gap-2 cursor-pointer"
                          >
                            <LogOut className="w-3.5 h-3.5 text-slate-500" />
                            Sign Out ({user.role})
                          </button>
                        ) : (
                          <Link
                            to="/auth"
                            onClick={() => setRoleMenuOpen(false)}
                            className="w-full px-3 py-2 rounded-xl text-xs font-semibold bg-[#B91C1C] text-white hover:bg-[#991B1B] flex items-center justify-center gap-1.5"
                          >
                            <LogIn className="w-3.5 h-3.5" />
                            Sign In / Register
                          </Link>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </header>

        {/* Page Body */}
        <div className="flex-1">{children}</div>
      </div>

      <AnimatePresence>
        {drawerOpen && (
          <NotificationsDrawer
            notifications={notifications}
            loading={notifLoading}
            onClose={() => setDrawerOpen(false)}
            onMarkRead={handleMarkRead}
            onMarkAllRead={handleMarkAllRead}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
