import { Menu, X } from 'lucide-react';
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'motion/react';
import { useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.tsx';

const NAV_ITEMS = [
  { to: '/', label: 'Broadcast Feed', end: true },
  { to: '/donors', label: 'Find Donors', end: false },
  { to: '/sos/new', label: 'Post SOS', end: false },
  { to: '/donor', label: 'Donor Portal', end: false },
  { to: '/map', label: 'Map View', end: false },
  { to: '/admin', label: 'Admin', end: false },
];

export function TopNav() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, 'change', (latest) => {
    const next = latest > 12;
    if (next !== scrolled) setScrolled(next);
  });

  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
      className={`no-print sticky top-0 z-30 border-b transition-all duration-200 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md border-slate-200 shadow-sm'
          : 'bg-white/85 backdrop-blur-sm border-slate-200/80'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark & Logo */}
        <Link
          to="/"
          className="group flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B91C1C]"
        >
          <motion.img
            src="/assets/aistudio/Red_Blood_Drop_Care_Logo_51326305.png"
            alt="LifeLine Logo"
            whileHover={{ scale: [1, 1.14, 1.04] }}
            whileTap={{ scale: 0.94 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="h-9 w-auto object-contain shrink-0 redrelay-heartbeat-subtle"
          />
          <span className="font-display text-lg font-bold tracking-tight text-[#0F172A]">
            LifeLine
          </span>
        </Link>

        {/* Zone 2: Single-line text navigation links with active & hover animated underlines */}
        <nav className="hidden md:flex items-center gap-5" aria-label="Primary Navigation">
          {NAV_ITEMS.map((item) => {
            const isActive = item.end
              ? location.pathname === item.to
              : location.pathname.startsWith(item.to);

            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={`group relative whitespace-nowrap shrink-0 text-sm font-medium transition-colors py-1.5 ${
                  isActive
                    ? 'text-[#0F172A]'
                    : 'text-slate-600 hover:text-[#0F172A]'
                }`}
              >
                {item.label}
                {isActive ? (
                  <motion.span
                    layoutId="topnav-active-underline"
                    transition={{ type: 'spring', stiffness: 480, damping: 36 }}
                    className="absolute left-0 right-0 -bottom-px h-0.5 bg-[#B91C1C] rounded-full"
                  />
                ) : (
                  <span
                    aria-hidden="true"
                    className="absolute left-0 right-0 -bottom-px h-0.5 bg-[#B91C1C]/45 rounded-full origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-200 ease-out"
                  />
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {user ? (
            <motion.button
              type="button"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.96 }}
              onClick={async () => {
                await logout();
                navigate('/auth');
              }}
              className="hidden md:inline-flex items-center px-4 py-2 text-xs font-semibold text-[#0F172A] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Sign Out ({user.role})
            </motion.button>
          ) : (
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.96 }}>
              <Link
                to="/auth"
                className="hidden md:inline-flex items-center px-4 py-2 text-xs font-semibold text-white bg-[#B91C1C] hover:bg-[#991B1B] rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                Sign In
              </Link>
            </motion.div>
          )}

          <motion.button
            type="button"
            whileTap={{ scale: 0.92 }}
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="md:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </motion.button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="md:hidden overflow-hidden border-t border-slate-200 bg-white"
          >
            <div className="px-4 py-3 space-y-2">
              <div className="flex flex-col space-y-1">
                {NAV_ITEMS.map((item, idx) => (
                  <motion.div
                    key={item.to}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.03, duration: 0.16 }}
                  >
                    <Link
                      to={item.to}
                      onClick={() => setMobileOpen(false)}
                      className="block px-3 py-2.5 text-sm font-medium text-[#0F172A] rounded-lg hover:bg-slate-50"
                    >
                      {item.label}
                    </Link>
                  </motion.div>
                ))}
              </div>
              <div className="pt-2 border-t border-slate-100">
                {user ? (
                  <button
                    type="button"
                    onClick={async () => {
                      await logout();
                      setMobileOpen(false);
                      navigate('/auth');
                    }}
                    className="w-full py-2.5 px-4 text-sm font-semibold text-[#0F172A] bg-slate-100 rounded-lg"
                  >
                    Sign Out ({user.name})
                  </button>
                ) : (
                  <Link
                    to="/auth"
                    onClick={() => setMobileOpen(false)}
                    className="block w-full text-center py-2.5 px-4 text-sm font-semibold text-white bg-[#B91C1C] rounded-lg"
                  >
                    Sign In / Register
                  </Link>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
