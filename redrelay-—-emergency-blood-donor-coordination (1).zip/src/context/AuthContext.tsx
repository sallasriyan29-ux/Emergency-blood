import {
  createContext,
  type ReactNode,
  useCallback,
  useContext,
  useEffect,
  useState,
} from 'react';
import { io, type Socket } from 'socket.io-client';
import type { UserPublic } from '../../shared/types.ts';
import { api, type DemoAccountOption, setStoredToken } from '../services/api.ts';

interface AuthContextValue {
  user: UserPublic | null;
  loading: boolean;
  socket: Socket | null;
  socketConnected: boolean;
  demoAccounts: DemoAccountOption[];
  refreshUser: () => Promise<void>;
  login: (email: string, password: string) => Promise<UserPublic>;
  register: (payload: Record<string, unknown>) => Promise<UserPublic>;
  logout: () => Promise<void>;
  switchDemoRole: (email: string) => Promise<UserPublic>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserPublic | null>(null);
  const [loading, setLoading] = useState(true);
  const [demoAccounts, setDemoAccounts] = useState<DemoAccountOption[]>([]);
  const [socket, setSocket] = useState<Socket | null>(null);
  const [socketConnected, setSocketConnected] = useState(false);

  const refreshUser = useCallback(async () => {
    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshUser();
    api
      .getDemoAccounts()
      .then((res) => setDemoAccounts(res.accounts))
      .catch(() => setDemoAccounts([]));
  }, [refreshUser]);

  useEffect(() => {
    const client = io({
      withCredentials: true,
      transports: ['websocket', 'polling'],
    });

    client.on('connect', () => setSocketConnected(true));
    client.on('disconnect', () => setSocketConnected(false));
    setSocket(client);

    return () => {
      client.disconnect();
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const res = await api.login(email, password);
    setStoredToken(res.token);
    setUser(res.user);
    return res.user;
  }, []);

  const register = useCallback(async (payload: Record<string, unknown>) => {
    const res = await api.register(payload);
    setStoredToken(res.token);
    setUser(res.user);
    return res.user;
  }, []);

  const logout = useCallback(async () => {
    await api.logout().catch(() => {});
    setStoredToken(null);
    setUser(null);
  }, []);

  const switchDemoRole = useCallback(async (email: string) => {
    const res = await api.demoSwitch(email);
    setStoredToken(res.token);
    setUser(res.user);
    return res.user;
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        socket,
        socketConnected,
        demoAccounts,
        refreshUser,
        login,
        register,
        logout,
        switchDemoRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return ctx;
}
