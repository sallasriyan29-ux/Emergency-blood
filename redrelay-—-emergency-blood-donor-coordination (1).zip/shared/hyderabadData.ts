export interface LocalityCoordinate {
  city: string;
  locality: string;
  latitude: number;
  longitude: number;
}

export interface DemoHospitalReference {
  name: string;
  location: string;
  city: string;
  locality: string;
  latitude: number;
  longitude: number;
}

export const HYDERABAD_LOCALITIES: LocalityCoordinate[] = [
  { city: 'Hyderabad', locality: 'Jubilee Hills', latitude: 17.4319, longitude: 78.4094 },
  { city: 'Hyderabad', locality: 'Banjara Hills', latitude: 17.4156, longitude: 78.4347 },
  { city: 'Hyderabad', locality: 'Madhapur', latitude: 17.4483, longitude: 78.3915 },
  { city: 'Hyderabad', locality: 'Gachibowli', latitude: 17.4401, longitude: 78.3489 },
  { city: 'Hyderabad', locality: 'Kondapur', latitude: 17.4622, longitude: 78.3568 },
  { city: 'Hyderabad', locality: 'Hitech City', latitude: 17.4435, longitude: 78.3772 },
  { city: 'Hyderabad', locality: 'Begumpet', latitude: 17.4447, longitude: 78.4664 },
  { city: 'Hyderabad', locality: 'Somajiguda', latitude: 17.4239, longitude: 78.4581 },
  { city: 'Hyderabad', locality: 'Secunderabad', latitude: 17.4399, longitude: 78.4983 },
  { city: 'Hyderabad', locality: 'Ameerpet', latitude: 17.4375, longitude: 78.4483 },
  { city: 'Hyderabad', locality: 'Kukatpally', latitude: 17.4948, longitude: 78.3996 },
  { city: 'Hyderabad', locality: 'Nampally', latitude: 17.3888, longitude: 78.4659 },
];

export const HYDERABAD_HOSPITALS: DemoHospitalReference[] = [
  {
    name: 'Apollo Hospital Jubilee Hills',
    location: 'Road No. 72, Film Nagar, Emergency & Blood Bank Wing',
    city: 'Hyderabad',
    locality: 'Jubilee Hills',
    latitude: 17.4152,
    longitude: 78.4126,
  },
  {
    name: 'CARE Hospitals Banjara Hills',
    location: 'Road No. 1, Banjara Hills, Cardiac ICU Block',
    city: 'Hyderabad',
    locality: 'Banjara Hills',
    latitude: 17.4126,
    longitude: 78.4494,
  },
  {
    name: 'Yashoda Hospital Somajiguda',
    location: 'Raj Bhavan Road, Somajiguda, Surgical Trauma Unit',
    city: 'Hyderabad',
    locality: 'Somajiguda',
    latitude: 17.4237,
    longitude: 78.4583,
  },
  {
    name: 'KIMS Hospital Secunderabad',
    location: '1-8-31/1, Minister Road, Secunderabad, Transfusion Center',
    city: 'Hyderabad',
    locality: 'Secunderabad',
    latitude: 17.4357,
    longitude: 78.4857,
  },
  {
    name: 'AIG Hospitals Gachibowli',
    location: '1-66/AIG/2 to 5, Mindspace Road, Gachibowli, Critical Care',
    city: 'Hyderabad',
    locality: 'Gachibowli',
    latitude: 17.4437,
    longitude: 78.3666,
  },
];

export function findLocalityCoordinates(
  city: string,
  locality: string
): { latitude: number; longitude: number } | null {
  const match = HYDERABAD_LOCALITIES.find(
    (item) =>
      item.city.toLowerCase() === city.trim().toLowerCase() &&
      item.locality.toLowerCase() === locality.trim().toLowerCase()
  );
  return match ? { latitude: match.latitude, longitude: match.longitude } : null;
}
