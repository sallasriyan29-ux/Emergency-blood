# RedRelay — Emergency Blood Donor Coordination Platform

**RedRelay** is a full-stack emergency blood request and voluntary donor coordination platform built for the **LifeLine Hackathon**. It connects families and hospital coordinators with compatible, nearby voluntary donors in real time while preserving donor phone-number privacy, enforcing clinical ABO/Rh red-cell matching rules, and tracking every request across a four-stage lifecycle until confirmed fulfillment or automatic expiration.

> **Clinical Scope Notice:** RedRelay is a coordination platform, not a blood bank or clinical decision-making system. Final blood-group crossmatching, donor eligibility screening, blood collection, testing, and transfusion approval must be confirmed by qualified medical professionals and authorized blood banks.

---

## Key Features Implemented

### Core Features
1. **Emergency Blood SOS Request Form**: Validates all 10 required clinical/coordination fields, generates unique request codes (`REQ-HYD-...`), assigns default 24-hour expiration timestamps, and keeps new requests marked `Pending Verification` until an administrator verifies the doctor/blood-bank contact.
2. **ABO/Rh Red-Cell Compatibility Engine**: Exact lookup-table matching across all 8 blood groups (`A+`, `A-`, `B+`, `B-`, `AB+`, `AB-`, `O+`, `O-`) with zero approximate string matching.
3. **Four-Stage Live Request Lifecycle Stepper**: Tracks `Open / Broadcasted` → `Donors Responded` → `Fulfilled / In Transit` → `Closed`, with immutable `AuditLogs` timestamps and server-enforced transition rules.
4. **Voluntary Donor Registry with Privacy Masking**: Phone numbers are stored privately on the server and stripped from public feeds, donor matching results, and requester views (displaying only initials such as `K. R.`, blood group, locality, and availability). Includes an in-app privacy-masked relay chat.
5. **Geographic Locality & Haversine Proximity Filtering**: Matches by city, Hyderabad locality, and optional Haversine radius (`km`) when consented donor coordinates are available, without fabricating distances.
6. **Live Emergency Broadcast Feed (Socket.IO)**: Real-time updates on request creation, verification, donor commitments (`1/2 Units Committed`), and expiration sweeps, with multi-criteria filtering.

### Stretch Features
7. **SMS SOS Dispatch Simulator**: Clearly labeled simulated dispatch log (`delivery_mode = simulated_sms`, `SIMULATED_SENT`) showing compatible nearby donors targeted when a verified request is broadcast.
8. **Interactive Hospital & Donor Proximity Map**: Built with **Leaflet** + **OpenStreetMap**, displaying hospital markers and consented donor locality pins with straight-line Haversine distance (explicitly noting no external driving-routing API is configured).
9. **90-Day Donation Interval Tracker**: Automatically locks donors into `in_recovery` for 90 days after a confirmed fulfillment, displays next eligible date, and restores eligibility once the interval expires.
10. **Digital Donor Appreciation Certificate**: Downloadable SVG & printable certificate issued strictly upon confirmed blood delivery (`FulfillmentTransactions`), never solely for clicking "I Can Donate."

### Ghost Request Prevention & Security
- Automated 24-hour expiration sweep removes stale requests from the active feed while retaining historical & audit records.
- Prominent **Mark Blood Received** fulfillment flow + **Close / Cancel** controls.
- `bcryptjs` password hashing, JWT HTTP-only cookies + Bearer auth, backend RBAC (`requester`, `donor`, `admin`), rate limiting, and atomic SQLite transactions preventing duplicate commitments and unit over-allocation.

---

## Project Structure

```text
├── server.ts                  # Express + Socket.IO + Vite dev / production server entry point (Port 3000)
├── server/
│   ├── createApp.ts           # Reusable Express + Socket.IO + SQLite app factory
│   ├── db.ts                  # SQLite schema, indexes, audit logging, expiration sweep, masked mappers
│   ├── auth.ts                # bcryptjs hashing, JWT signing, RBAC middleware, rate limiting
│   ├── seed.ts                # Repeatable Hyderabad demo dataset (30 donors + 5 active requests)
│   ├── initDb.ts              # CLI DB schema initialization script
│   ├── seedCli.ts             # CLI repeatable DB seeding script
│   └── routes/
│       ├── auth.ts            # Register, login, logout, session, demo role switcher
│       ├── donors.ts          # Donor registration, private profile, availability, matching, history
│       ├── requests.ts        # SOS CRUD, verification, respond ("I Can Donate"), relay, SMS simulator
│       ├── responses.ts       # Commitment status updates / withdrawal
│       ├── fulfillment.ts     # Confirm blood received -> recovery lock + certificate issuance
│       ├── notifications.ts   # In-app & simulated SMS notification inbox
│       └── admin.ts           # Admin metrics, request/donor verification, expiration sweep, config
├── shared/
│   ├── types.ts               # Shared TypeScript interfaces & blood group enums
│   ├── bloodCompatibility.ts  # Reusable ABO/Rh matrix, Haversine, 90-day recovery & SOS validation
│   └── hyderabadData.ts       # Hyderabad metro localities & demonstration hospital references
├── src/
│   ├── App.tsx                # React Router routes & layout shell
│   ├── context/AuthContext.tsx# Session state, Socket.IO client, Demo Role Switcher
│   ├── services/api.ts        # Typed REST API client
│   ├── components/            # TopNav, DemoRoleBar, LifecycleStepper, RequestCard, Map, CertificateModal
│   └── pages/                 # BroadcastFeed, CreateSos, RequestDetail, DonorPortal, MapView, Admin, Auth
└── tests/
    └── redrelay.test.ts       # Automated unit + integration + end-to-end demo scenario tests
```

---

## Commands & Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Initialize & Seed SQLite Database (Hyderabad Demonstration Dataset)
```bash
npm run db:init
npm run db:seed
```
*(To reset and re-seed demonstration records cleanly: `npx tsx server/seedCli.ts --reset`)*

### 3. Run Automated Test Suite
```bash
npm test
```

### 4. Start Development Server (Backend + Frontend on Port 3000)
```bash
npm run dev
```
Open `http://localhost:3000`.

### 5. Production Build & Start
```bash
npm run build
NODE_ENV=production npm start
```

---

## Demonstration Walkthrough (Hackathon Scenario)

1. Use the **Demo Role Switcher** toolbar to select **Requester** (`requester@redrelay.demo`).
2. Navigate to **Post SOS** (`/sos/new`), click **Prefill Apollo Demo Scenario** (or enter `"Apollo Hospital Jubilee Hills"`, `2 Units`, `B+`, `+4h` deadline), and submit.
3. Switch to **Admin** (`admin@redrelay.demo`) on the request detail page and click **Verify Request** (confirming hospital contact & running the simulated SMS SOS dispatch).
4. Switch to **Donor (O+)** (`donor.oplus@redrelay.demo`), view the compatible B+ request, and click **I Can Donate**.
5. Observe the card update immediately to **`1/2 Units Committed`** and the lifecycle stepper advance to **Donors Responded**.
6. Switch back to **Requester** to view the masked donor commitment (`Donor K. R. · O+`) and coordinate via the **In-App Privacy-Masked Relay** without seeing any private phone number.
7. Click **Mark Blood Received** to record fulfillment, trigger the donor's 90-day recovery lock, advance the lifecycle to **Closed**, and unlock the downloadable **Digital Donor Appreciation Certificate**.
